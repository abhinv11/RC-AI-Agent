Special Ad-Hoc Group for Revision of IS 456

# Convener 

Dr H.C. Visvesvarya
'Chundrika' at 15th Cross,
63-64, Malleswaram, Bangalore 560003

Members
Sidi S.A. Reddi
Dr C. Rajkumar

Representing
Gammon India Ltd, Mumbai
National Council for Cement and Building Materials, Ballahgarh

# Bureau of Indian Standards

BIS is a statutory institution established under the *Bureau of Indian Standards Act, 1986* to promote harmonious development of the activities of standardization, marking and quality certification of goods and attending to connected matters in the country.

# Copyright

BIS has the copyright of all its publications. No part of these publications may be reproduced in any form without the prior permission in writing of BIS. This does not preclude the free use, in the course of implementing the standard, of necessary details, such as symbols and sizes, type or grade designations. Enquiries relating to copyright be addressed to the Director (Publications), BIS.

# Review of Indian Standards

Amendments are issued to standards as the need arises on the basis of comments. Standards are also reviewed periodically; a standard along with amendments is reaffirmed when such review indicates that no changes are needed; if the review indicates that changes are needed, it is taken up for revision. Users of Indian Standards should ascertain that they are in possession of the latest amendments or edition by referring to the latest issue of 'BIS Catalogue' and 'Standards: Monthly Additions'.

This Indian Standard has been developed from Doc No.: CED 2(5525).

# Amendments Issued Since Publication

|  Amend No. | Date of Issue | Text Affected  |
| --- | --- | --- |
|  |   |   |
|  |   |   |
|  |   |   |
|  |   |   |
|  |   |   |

# BUREAU OF INDIAN STANDARDS

## Headquarters:

Manak Bhavan, 9 Bahadur Shah Zafar Marg, New Delhi 110002 Telephones: 2323 0131, 2323 3375, 2323 9402 Website: www.bis.org.in

## Regional Offices:

|  |   |   |
| --- | --- | --- |
|  Central | Manak Bhavan, 9 Bahadur Shah Zafar Marg | 2323 7617  |
|   | NEW DELHI 110002 | 2323 3841  |
|  Eastern | 1/14 C.I.T. Scheme VII M, V. I. P. Road, Kankurgachi | 2337 8499, 2337 8561  |
|   | KOLKATA 700054 | 2337 8626, 2337 9120  |
|  Northern | SCO 335-336, Sector 34-A, CHANDIGARH 160022 | 60 3843  |
|   |  | 60 9285  |
|  Southern | C.I.T. Campus, IV Cross Road, CHENNAI 600113 | 2254 1216, 2254 1442  |
|   |  | 2254 2519, 2254 2315  |
|  Western | Manakalaya, E9 MIDC, Maroi, Andheri (East) | 2832 9295, 2832 7858  |
|   | MUMBAI 400093 | 2832 7891, 2832 7892  |

## Branches:

AHMEDABAD. BANGALORE. BHOPAL. BHUBANESHWAR. COIMBATORE. DEHRADUN. FARIDABAD. GHAZIABAD. GUWAHATI. HYDERABAD. JAIPUR. KOCHI. LUCKNOW. NAGPUR. PARWANOO. PATNA. PUNE. RAJKOT. VISAKHAPATNAM.

Published by BIS, New Delhi

Printed at: Bengal Offset Works, Karol Bagh, New Delhi.

# (Fourth Revision) 

( Page 2; Foreword, last but one line ) — Substitute 'ACI 318 : 1995' for 'ACI 319 : 1989'.
( Page 11, clause 4 ) - Delete the matter ' $L_{\mathrm{w}}$ - Horizontal distance between centres of lateral restraint'.
( Page 15, clause 5.5, Title ) — Substitute 'Chemical Admixtures' for 'Admixtures'.
( Page 17, clause 7.1 ) - Substitute the following for the existing informal table:

| Placing Conditions | Degree of Workability | Slump <br> (mm) |
| :--: | :--: | :--: |
| (1) | (2) | (3) |
| Blinding concrete; <br> Shallow sections; <br> Pavements using pavers | Very low | See 7.1.1 |
| Mass concrete; <br> Lightly reinforced sections in slabs, beams, walls, columns; Floors; Hand placed pavements; Canal lining; Strip footings | Low | $25-75$ |
| Heavily reinforced sections in slabs, beams, walls, columns; | Medium | $50-100$ |
| Slipform work; <br> Pumped concrete | Medium | $75-100$ |
| Trench fill; In-situ piling | High | $100-150$ |
| Tremic concrete | Very high | See 7.1.2 |

NOTE - For most of the placing conditions, internal vibrators (needle vibrators) are suitable. The diameter of the needle shall be determined based on the density and spacing of reinforcement bars and thickness of sections. For tremie concrete, vibrators are not required to be used (see also 13.3).
(Page 19, Table 4, column 8, sub-heading) — Substitute 'Free' for 'Face'.
(Page 27, clause 13.5.3) — Delete.
(Page 29, clause 15.3):
a) Substitute 'specimens' for 'samples' in lines 2, 6 and 7.
b) Substitute 'IS 9013' for 'IS 9103'.
(Page 29, clause 16.1) - Substitute 'conditions' for 'condition' in line 3 and the following matter for the existing matter against 'a)':
'a) The mean strength determined from any group of four non-overlapping consecutive test results complies with the appropriate limits in column 2 of Table 11.'
(Page 29, clause 16.3, para 2 ) — Substitute 'col 3' for 'col 2'.
(Page 29, clause 16.4, line 2 ) — Substitute ' 16.1 or 16.2 as the case may be' for '16.3'.
(Page 30, Table 11, column 3 ) — Substitute ' $\geq f_{\mathrm{ck}}-3$ ' for ' $\geq f_{\mathrm{ck}}{ }^{-3}$ ' and ' $\geq f_{\mathrm{ck}}-4$ ' for ' $\geq f_{\mathrm{ck}}{ }^{-4}$ '

Amead No. 1 to IS $456: 2000$
(Page 33, clause 21.3, line 2 ) — Substitute 'action' for 'section'.
[Page 37, clause 23.1.2(c)] — Substitute ' $b_{1}$ ' for ' $b_{2}$ ', ' $l_{0}$ ' for ' $l_{0}$ ', ' $b$ ' for ' $b$ ' and ' $b_{w}$ ' for ' $b_{w}$ ' in the formulae.
(Page 46, clause 26.4.2) — Substitute '8.2.2' for '8.2.3'.
[Page 49, clause 26.5.3.2 (c) (2), last line] — Substitute ' 6 mm ' for ' 16 mm '.
(Page 62, clause 32.2.5) — Substitute ' $H_{w w}^{2}$ ' for ' $H_{w w}$ ' in the explanation of $e_{4}$.
(Page 62, clause 32.3.1, line 4) — Substitute '32.4' for '32.3'.
[Page 62, clause 32.4.3 (b), line 6] - Insert ' $\tau_{w w}$ ' between the words 'but' and 'shall'.
[Page 65, clause 34.2.4.1(a), last line] - Insert the following after the words 'depth of footing':
'in case of footings on soils, and at a distance equal to half the effective depth of footing'.
(Page 68, Table 18, col 4) — Substitute '-' for '1.0' against the Load Combination $D L+I L$.
(Page 72, clause 40.1) — Substitute 'bd' for ' $b_{d}$ ' in the formula.
(Page 83, clause B-4.3, line 2) — Delete the word 'and'.
(Page 85, clause B-5.5.1, para 2, line 6) — Substitute 'Table 24' for 'Table 23'.
(Page 85, clause B-5.5.2) - Substitute the following for the existing formula:
$A_{a}=a_{c} b\left(\tau_{c}-2 d \tau_{c} / a_{c}\right) / \sigma_{c v} \geq 0.4 a_{c} b / 0.87 f_{y}$ '
(Page 90, clause D-1.11, line 1) — Substitute 'Where' for 'Torsion'.
(Page 93, Fig. 27) — Substitute ' $l_{c f} / l$ ' for ' $1 / L$ '.
(Page 95, Annex F):
a) The reference to Fig. 28 given in column 1 of the text along with the explanation of the symbols used in the Fig. 28 given thereafter may be read just before the formula given for the rectangular tension zone.
b) Substitute 'compression' for 'campression' in the explanation of symbol ' $a$ '.
(Pages 98 to 100, Annex H) —Substitute the following for the existing Annex :

# ANNEX H <br> (Foreword) <br> COMMITTEE COMPOSITION 

Cement and Concrete Sectional Committee, CED 2
Chairman
De H. C. Vievosvaraya
'Chandrika', at $15^{\text {th }}$ Cross, 63-64 East Park Road, Malleswaram, Bangalore-560003

Members
De S. C. Ahluwalia
Shri V. Balasubramanian
Shri R. F. Singh (Alternate)
Shri G. R. Bhartikar
Shri A. K. Chadda
Shri J. R. Se. (Alternate)
Chief Engineer (Design)
Superintending Engineer (S\&S) (Alternate)
Chief Engineer (Naygam Dam)
Superintending Engineer (QCC) (Alternate)
Chief Engineer (Research-cum-Director
Research Officer (Concrete Technology)
(Alternate)

Representing
OCL India Ltd, New Delhi
Directorate General of Supplies and Disposals, New Delhi
B. G. Shirke Construction Technology Ltd, Pune

Hindustan Prefab Limited, New Delhi
Central Public Works Department, New Delhi
Sardar Sarovar Narmada Nigam Ltd, Gandhinagar
Irrigation and Power Research Institute, Amritsar

(Continued from page 2)

| Members | Representing |
| :--: | :--: |
| SHRIJ. P. DESAI | Gujarat Ambuja Cements Lid, Ahmedabad |
| SHRIB. K. JAGHTIA (Alternate) | A.P. Engineering Research Laboratories, Hyderabad |
| DIRECTOR <br> JOINT DIRECTOR (Alternate) | Central Water Commission, New Delhi |
| DIRECTOR (CMDD) (N\&W) <br> DEPUTY DIRECTOR (CMDD) (NW\&S) (Alternate) | Hyderabad Industries Lid, Hyderabad |
| SHRIK. H. GANOWAL SHRI V. PATTAIHE (Alternate) | The India Cements Lid, Chennai |
| SHRI V. K. GHANEKAR | Gannon Dunkerley and Company Lid, Mumbai |
| SHRI S. GOHNATH <br> SHRI R. TAMILAKARAN (Alternate) | Central Building Research Institute (CSIR), Roorkee |
| SHRI S. K. GUHA THAKURTA <br> SHRI S. SANKARANARAYANAN (Alternate) | University of Roorkee, Roorkee |
| SHRI N. S. IBAL <br> DR IRSHAD MASOOD (Alternate) | Cement Corporation of India Lid, New Delhi |
| PROF A. K. JAIN | Research, Designs \& Standards Organization (Ministry of Railways), Lucknow |
| SHRI N. C. JAIN | The Indian Hume Pipe Company Lid, Mumbai |
| JoINT DIRECTOR (STANDARDS) (B\&S) (CB-I) <br> JOINT DIRECTOR (STANDARDS) (B\&S) (CB-II) <br> (Alternate) | National Test House, Calcutta |
| SHRI N. G. JOSHI <br> SHRI P. D. KELKAR (Alternate) | Larsen \& Tubeo Lid, Mumbai |
| SHRI D. K. KANUNGO <br> SHRI B. R. MEENA (Alternate) | Structural Engineering Research Centre (CSIR), Chennai |
| SHRI P. KREHNAMURTHY <br> SHRI S. CHOWDHURY (Alternate) | Hospital Services Consultancy Corporation (India) Lid, New Delhi |
| DE A. G. MADHAVA RAO <br> SHRI K. MANI (Alternate) | Housing and Urban Development Corporation Lid, New Delhi |
| SHRI J. SARUP | Ministry of Surface Transport, Department of Surface Transport (Roade Wing), New Delhi |
| SHRI V. SURESH <br> SHRI D. P. SIRGH (Alternate) | Central Board of Irrigation \& Power, New Delhi |
| SHRI PRAFOLA KUMAR <br> SHRI P. P. NAIR (Alternate) | Engineer-in-Chief's Branch, Army Headquarters, New Delhi |
| MEMBER SECRETARY <br> DIRECTOR (CIVIL) (Alternate) | Central Road Research Institute (CSIR), New Delhi |
| SHRI S. K. NATHANI <br> DR A. S. GOEL (Alternate) | Indian Roads Congress, New Delhi |
| SHRI S. S. SEEHRA <br> SHRI SATANDER KUMAR (Alternate) | National Council for Cement and Building Materials, Ballabgarh |
| SHRI Y. R. PHULL <br> SHRI A. K. SHARMA (Alternate) | Gammam India Lid, Mumbai |
| DR C. RANJUMAR <br> DR K. MOHAN (Alternate) | Builder's Association of India, Mumbai |
| SHRI S. A. REDDI | Geological Survey of India, Calcutta |
| REPRISENTATIVE | Public Works Department, Government of Tamil Nadu, Chennai |
| SHRI J. S. SANGANISHA <br> SHRI L. N. AGARWAL (Alternate) | Indian Rayon and Industries Lid, Pune |
| SUPERINTENDING ENGINEER (DESIGN) <br> EXECUTIVE ENGINEER (SMR DIVISION) (Alternate) | The Associated Cement Companies Lid, Mumbai |
| SHRI K. K. TAPARIA <br> SHRI A. K. JAIN (Alternate) | Central Soil and Materials Research Station, New Delhi |
| SHRI T. N. TIWARI <br> DR D. GHOSH (Alternate) | The Associated Cement Companies Lid, Mumbai |
| DR K. VENKATACHALAM <br> SHRI N. CHANDRASEKARAN (Alternate) | Central Soil and Materials Research Station, New Delhi |

Amend No. 1 to IS 456 : 2000

(Continued from page 3)

Members

Dr H. C. Visvesvaraya
SHRI D. C. CHATURVEH (Alternate)

SHRI VINOD KUMAR
DIRECTOR (Civ Engg)

The Institution of Engineers (India), Calcutta

Director General, BIS (Ex-officio Member)

Member-Secretaries

SHRI J. K. PRAFAD
Additional Director (Civ Engg), BIS

SHRI SANJAY PANT
Deputy Director (Civ Engg), BIS

Concrete Subcommittee, CED 2:2

Representing

National Council for Cement and Building Materials, Ballabgarh

Chief C. R. ALINCHANDANI
SHRI S. RANGARAJAN (Alternate)

Dr P. C. CHOWDHURY
DR C. S. VISHWANATHA (Alternate)

SHRI J. P. DESAI
SHRI B. K. JAGETIA (Alternate)

DIRECTOR
SHRI N. CHANDRASEKARAN (Alternate)

DIRECTOR (C&MDD)
DEPUTY DIRECTOR (C&MDD) (Alternate)

JOINT DIRECTOR STANDARDS (B&S)/CB-II
JOINT DIRECTOR STANDARDS (B&S)/CB-I (Alternate)

SUPERINTENDING ENGINEER (DESIGNS)
EXECUTIVE ENGINEER (DESIGNS)-III (Alternate)

SHRI V. K. GHANSKAR
SHRI D. S. PRARASH RAO (Alternate)

SHRI S. K. GUHA THAKURTA
SHRI S. P. SANKARANARAYANAN (Alternate)

SHRI J. S. HINDORANI

SHRI L. K. JAIN

SHRI M. P. JASINOH
DR B. KAMESWARA RAO (Alternate)

CHIEF ENGINEER & JOINT SECRETARY
SUPERINTENDING ENGINEER (Alternate)

PROF S. KEISHNA MOORTHY
SHRI K. K. NAYAR (Alternate)

DR S. C. MAITI

MANAGING DIRECTOR
SHRI M. KUNDU (Alternate)

SHRI S. K. NAITHANI
LY-COL K. S. CHARAK (Alternate)

SHRI B. V. B. PAI
SHRI M. G. DANDVATR (Alternate)

SHRI A. B. PHADKE
SHRI D. M. SAVUR (Alternate)

SHRI Y. R. PHULL
SHRI S. S. SEEHRA (Alternate I)
SHRI SATANDEK KUMAR (Alternate II)

Stap Consultants Ltd, Mumbai

Torsteel Research Foundation in India, Calcutta

Gujarat Ambuja Cements Ltd, Ahmedabad

Central Soil and Materials Research Station, New Delhi

Central Water Commission, New Delhi

Research, Designs and Standards Organization (Ministry of Railways), Lucknow

Central Public Works Department, New Delhi

Structural Engineering Research Centre (CSIR), Ghaziabad

Gannoa Dunkerley and Co Ltd, Mumbai

Associated Consulting Services, Mumbai
In personal capacity

Central Building Research Institute (CSIR), Roorkee

Public Works Department, Mumbai

Indian Institute of Technology, New Delhi

National Council for Cement and Building Materials, Ballabgarh
Hindustan Prefab Limited, New Delhi

Engineer-in-Chief's Branch, Army Headquarters, New Delhi

The Associated Cement Companies Ltd, Mumbai

The Hindustan Construction Co Ltd, Mumbai

Central Road Research Institute (CSIR), New Delhi

(Continued on page 5)

(Continued from page 4)
Members
Shri A. S. Prasad Rao
Shri K. Mani (Alternate)
Shri K. L. Pruthe
Shri J. R. Gabriel (Alternate)
Shri B. D. Ranalker
Shri U. S. P. Verma (Alternate)
Shri Hanumantra Rao
Shri G. Ramakrishnan (Alternate)
Shri S. A. Reddi
Dr N. K. Nayak (Alternate)
Shri S. C. Sawhney
Shri R. P. Mehrotra (Alternate)
Prof M. S. Shetty
Shri N. K. Sinha
Shri B. T. Unwalla

## Conveuer

Dr C. Rajkumar

Members
Dr Anil Kumar
Shri V. K. Ghanekar
Prof A. K. Jain
Shri L. K. Jain
Shri Jose Kurian
Dr S. C. Marti
Dr A. K. Mittal
Shri S. A. Reddi
Dr V. Thiruvendram

## Representing

Structural Engineering Research Centre (CSIR), Chennai
National Building Construction Corporation Ltd, New Delhi
Nuclear Power Corporation, Mumbai
A.P. Engineering Research Laboratories, Hyderabad

Gammon India Ltd, Mumbai
Engineers India Ltd, New Delhi
Indian Concrete Institute, Chennai
Ministry of Surface Transport (Roads Wing), New Delhi
In personal capacity

Panel for Revision of IS 456, CED 2:2/P

## Representing

National Council for Cement and Building Materials, Ballabgarh

National Council for Cement and Building Materials, Ballabgarh
Structural Engineering Research Centre (CSIR), Ghaziabad
University of Roorkee, Roorkee
In personal capacity
Central Public Works Department, New Delhi
National Council for Cement and Building Materials, Ballabgarh
Central Public Works Department, New Delhi
Gammon India Ltd, Mumbai
School of Planning and Architecture, New Delhi

Special Ad-Hoc Group for Revision of IS 456
Conveuer
Dr H. C. Visvesvaraya
'Chandrika', at $15^{\text {th }}$ Cross, 63-64 East Park Road, Malleswaram, Bangalore-560 003

## Representing

National Council for Cement and Building Materials, Ballabgarh
Gammon India Ltd, Mumbai

.

# AMENDMENT NO. 2 SEPTEMBER 2005 TO 

## IS 456: 2000 PLAIN AND REINFORCED CONCRETE CODE OF PRACTICE

## (Fourth Revision)

( Page 13, clause 5.2.1.1, line 1 ) - Substitute 'IS 3812 (Part 1)' for 'Grade 1 of IS 3812'.
( Page 13, clause 5.2.1.2 and corresponding Note ) - Substitute the following for the existing:
-Silica fume conforming to IS 15388 may be used as part replacement of cement provided uniform blending with the cement is ensured.

NOTE - Silica fume is usually used in proportion of 5 to 10 percent of the cement content of a mix.'
( Page 13, Note under clause 5.2.1.3, line 5 ) - Substitute 'be' for 'range from being'.
( Page 25, clause 10.3.3, line 4 ) - Delete the word 'and'.
( Page 65, clause 34.2.4.2, line 1 )-Substitute 'on' for 'or'.
[ Page 65, clause 34.3.1(a), line 2 ] - Delete the words 'extending in each direction'.
( Page 66, clause 34.4.3, line 5 ) - Substitute 'not' for 'no'.
( Page 78, Annex A) - Substitute the following for the existing entries for IS $3812: 1981$ :
'IS No. Title
IS 3812 (Part 1) : 2003 Specification for pulverized fuel ash : Part 1 For use as pozzolana in cement, cement mortar and concrete (second revision)'
(Page 79, Annex A) - Add the following at the end:
'IS No. Title
IS $15388: 2003 \quad$ Specification for silica fume'

# Amend No. 2 to IS $456: 2000$ 

( Page 80, B-2.1.1, informal table ) - Insert the following in the table:

| ' $\frac{\text { M55 }}{5.6}$ |  |  |
| :--: | :--: | :--: |
| ( Page 81, Table 21 )-Insert the following row after the last row: |  |  |
| '(1) | (2) | (3) |
| M55 | 17.5 | 13.0 |

( Page 91, Table 26, Case No. 2, col 2 ) - Substitute 'One Short Edge Discontinuous' for 'One Short Edge Continuous'.
[Page 96, G-1.1(c), formula ] — Substitute ' $M_{\mathrm{n} \text {,lin }}$ ' for ' $M_{\mathrm{n} \text { 'lin }}$ '.
[Page 96, G-1.1(d), last line] — Substitute '38.1' for '39.1'.

# AMENDMENT NO. 3 AUGUST 2007 TO IS 456 : 2000 PLAIN AND REINFORCED CONCRETE - CODE OF PRACTICE 

## (Fourth Revision)

(Page 2, Foreword) - Insert the following after para 8:
'The provisions for Self Compacting Concrete have been included for guidance (see Annex J).'
(Page 10) - Add the following at the end:
'ANNEX J SELF COMPACTING CONCRETE'
(Page 15, clause 5.4.4, last sentence) - Delete.
(Page 15, clause 5.6.2) - Add the following at the end:
'Reduction in design bond strength of coated bars shall be looked into.'
(Page 15, clause 5.6.3) - Add the following after the clause and renumber the existing clause ' 5.7 ' as ' 5.8 '.

## '5.7 Fibres

Fibres may be added to concrete for special applications to enhance properties, for which specialist literature may be referred to.
(Page 15, clause 6.1.3) - Substitute the following for the existing clause:
'Concrete of grades lower than those given in Table 5 may be used for lean concrete, foundation for masonry walls or temporary reinforced concrete construction.'
[Page 17, clause 7.1 (see also Amendment No. 1)] - In the informal table, delete the words 'In-situ piling' in column 1.

Amend No. 3 to IS $456: 2000$
(Page 23, Table 9) - Number the existing note as 'NOTE 1' and add the following 'NOTE 2':
'NOTE 2 - Quantity of water required from durability point of view may be less than the value given above.'
(Page 29, clause 15.1.1, last line) - Add 'in accordance with 16' at the end.
(Page 30, Table 11, col 2) - Substitute ' $f_{\mathrm{ck}}+3 \mathrm{~N} / \mathrm{mm}^{2}$ ' for ' $f_{\mathrm{ck}}+4 \mathrm{~N} / \mathrm{mm}^{2}$ ' against ' M 20 or above'.
[Page 30, Table 11, col 3 (see also Amendment No. 1)] - Substitute ' $f_{\mathrm{ck}}-3$ $\mathrm{N} / \mathrm{mm}^{2}$ ' for ' $f_{\mathrm{ck}}-4 \mathrm{~N} / \mathrm{mm}^{2}$ ' against ' M 20 or above'.
(Page 42, clause 26.1.1) - Add the following at the end:
'Congestion of reinforcement should be avoided during detailing. Various methods such as choosing the diameter and grade of steel carefully and bundling of reinforcement, if required, are available.'
[Page 45, clause 26.2.5.1(a)] - Substitute the following for the existing:
'Lap splices shall not be used for bars larger than 32 mm . Bars larger than 32 mm shall be welded (see 12.4) or mechanically spliced.'
[Page 46, clause 26.3.3(b)(2), last line] - Substitute ' 300 mm ' for ' 450 mm '.
[Page 47, clause 26.5.1.1(b)] - Add the following note at the end:
'NOTE - The use of 4 percent reinforcement may involve practical difficulty in placing and compacting concrete; hence lower percentage is recommended.'
(Page 47, clause 26.5.1.2) - Add the following note at the end:
'NOTE - The use of 4 percent reinforcement may involve practical difficulty in placing and compacting of concrete; hence lower percentage is recommended.'
(Page 52, clause 29.3.4, last line) - Substitute '32.5' for '32.4'.
(Page 100, Annex H) - Add the following annex:

# ANNEX J <br> (Foreword) 

## SELF COMPACTING CONCRETE

## J-1 GENERAL

Self compacting concrete is a concrete that fills uniformly and completely every corner of formwork by its own weight without application of any vibration, without segregation, whilst maintaining homogeneity.

## J-2 APPLICATION AREA

Self compacting concrete may be used in precast concrete applications or for concrete placed on site. It may be manufactured in a site batching plant or in a ready-mixed concrete plant and delivered to site by truck mixer. It may then be placed either by pumping or pouring into horizontal or vertical forms.

## J-3 FEATURES OF FRESH SELF COMPACTING CONCRETE

The following are some of the features of self compacting concrete:
a) Slump flow: 600 mm , Min.
b) Sufficient amount of fines ( $<0.125 \mathrm{~mm}$ ) preferably in the range of $400 \mathrm{~kg} / \mathrm{m}^{3}$ to $600 \mathrm{~kg} / \mathrm{m}^{3}$. This can be achieved by having sand content more than 38 percent and using mineral admixture to the order of 25 percent to 50 percent by mass of cementitious materials.
c) Use of high range water reducing (HRWR) admixture and viscosity modifying agent (VMA) in appropriate dosages.

.

# AMENDMENT NO. 4 MAY 2013

TO

## IS 456 : 2000 PLAIN AND REINFORCED CONCRETE — CODE OF PRACTICE

### (Fourth Revision)

(Page 14, clause 5.3, second sentence) — Delete.

(Page 14, clause 5.3.4, second sentence) — Delete.

(Page 14, clause 5.4, line 1) — Substitute 'Water, natural or treated,' for 'Water'.

(Page 14, clause 5.4.3, first sentence) — Substitute the following for the existing sentence:

'Sea water shall not be used for mixing or curing of concrete because of presence of harmful salts.'

(Page 15, clause 5.5.6) — Insert the following new clause:

'5.5.7 The amount of admixture added to a mix shall be recorded in the production record. Redosing of admixtures is not normally permitted. In special circumstances, if necessary, additional dose of admixture may be added at project site and mixed adequately in mixer itself to regain the workability of concrete with the mutual agreement between the producer/supplier and the purchaser/user of concrete. However, the producer/supplier shall assure the ultimate quality of concrete supplied by him and maintain record of quantity and time of addition.'

(Page 16, Table 2) — Substitute the following table for the existing table:

**Table 2 Grades of Concrete**

(Clauses 6.1, 9.2.2, 15.1.1 and 36.1)

|  Group | Grade Designation | Specified Characteristic Compressive Strength of 150 mm Cube at 28 days  |
| --- | --- | --- |
|  Ordinary Concrete | - (2) | 10  |
|   | M 10 | 15  |
|   | M 15 | 20  |
|   | M 20 | 25  |
|   | M 25 | 30  |
|   | M 30 | 35  |
|   | M 35 | 40  |
|   | M 40 | 45  |
|   | M 45 | 50  |
|   | M 50 | 55  |
|   | M 55 | 60  |
|   | M 60 | 65  |
|  High Strength Concrete | M 65 | 70  |
|   | M 70 | 75  |
|   | M 75 | 80  |
|   | M 80 | 85  |
|   | M 85 | 90  |
|   | M 90 | 95  |
|   | M 95 | 100  |

**NOTES**

1. In the designation of concrete mix M refers to the mix and the number to the specified characteristic compressive strength of 150 mm size cube at 28 days, expressed, in N/mm².
2. For concrete of grades above M 60, design parameters given in the standard may not be applicable and the values may be obtained from specialized literatures and experimental results.

Price Group 3

Amendment No. 4 to IS 456 : 2000
(Page 17, clause 8.1, line 3) - Insert the word 'life' after 'service'.
(Page 20, Table 5, Note 1) - Substitute the following for the existing note:
'1 Cement content prescribed in this table is irrespective of grades and types of cement and is inclusive of mineral admixtures mentioned in 5.2. The mineral admixtures such as fly ash or ground granulated blast furnace slag shall be taken into account in the concrete composition with respect to the cement content and water-cement ratio not exceeding the limit of fly ash and slag specified in IS 1489 (Part 1) and IS 455 respectively, beyond which these additions, though permitted, shall not be considered for these purposes.'
(Page 20, Table 5, Note 2) - Insert the following new note:
'3 The minimum cement content, maximum free water-cement ratio and minimum grade of concrete are individually related to exposure.'
[Page 21, clause 8.2.5.4 (b), para 2] - Substitute 'fly ash conforming to IS 3812 (Part 1) or ground granulated' for 'fly ash (Grade 1) conforming to IS 3812 or granulated' and ' 25 percent' for ' 20 percent'.
(Page 21, clause 8.2.6.2, para 2) - Substitute the following for the existing para:
'Additional protection may be obtained by the use of suitable impermeable barriers.'
(Page 22, clause 9.2.1) - Insert the following at the end:
'If so desired, the employer shall be provided with supporting data including graphs showing strength versus water-cement ratio for range of proportions, complete trial mix proportioning details to substantiate the choice of cement content, fine and coarse aggregate content, water, mineral admixtures, chemical admixtures, etc.'
(Page 22, clause 9.2.2, first sentence) - Insert the following after first sentence:
'Proportion/grading of aggregates shall be made by trial in such a way as to make densest possible concrete.'
(Page 23, Table 8) - Substitute the following for the existing table:
Table 8 Assumed Standard Deviation
(Clause 9.2.4.2 and Table 11)
![chunk-0-img-0.jpeg](chunk-0-img-0.jpeg)

NOTES
1 The above values correspond to the site control having proper storage of cement; weigh batching of all materials; controlled addition of water; regular checking of all materials, aggregate grading and moisture content; and periodical checking of workability and strength. Where there is deviation from the above, the values given in the above table shall be increased by $1 \mathrm{~N} / \mathrm{mm}^{2}$.
2 For grades above M 60, the standard deviation shall be established by actual trials based on assumed proportions, before finalizing the mix.

Amendment No. 4 to IS 456 : 2000

(Page 24, clause 10.2, para 2) — Substitute the following for the existing para:

'For large and medium project sites, the concrete shall be sourced from ready-mixed concrete plants or from captive on-site or off-site automatic batching and mixing plants. The concrete produced and supplied by ready-mixed concrete plants shall be in accordance with IS 4926. In case of concrete from captive on-site or off-site automatic batching and mixing plants, similar quality control shall be followed.'

(Page 24, clause 10.2.1, first sentence) — Substitute the following for the existing sentence:

'The grading of aggregate shall be controlled by obtaining the coarse aggregate in different sizes and blending them in right proportions, the different sizes being stocked in separate stock-piles.'

(Page 24, clause 10.2.2) — Substitute the following for the existing clause:

'10.2.2 The accuracy of the measuring equipment shall be within ±2 percent of the quantity of cement and mineral admixtures being measured and within ±3 percent of the quantity of aggregate, chemical admixtures and water being measured. In a batching plant, the concrete production equipment shall be calibrated initially at the time of installation or reconditioning of the equipment and subsequently at the following intervals:

a) Mechanical/knife edge systems: At least once every two months

b) Electrical/load cell systems: At least once every three months'

(Page 24, clause 10.2.3) — Substitute the following for the existing clause:

'10.2.3 All ingredients of concrete shall be used by mass except water and chemical admixtures, which may be by volume.'

(Page 24, clause 10.2.5, fourth sentence) — Insert the following after fourth sentence:

'Where batching plants are used, it is recommended to determine moisture content by moisture probes fitted to the batching plants.'

(Page 24, clause 10.3, first and second sentence) — Substitute the following for the existing sentences:

'Concrete shall be mixed in a mechanical mixer (see also IS 1791 and IS 12119). It shall be ensured that stationary or central mixers and truck mixers shall comply with the performance criteria of mixing efficiency as per IS 4634. Mixing efficiency test shall be performed at least once in a year.'

(Page 25, clause 10.3.1) — Substitute the following for the existing clause:

'10.3.1 As a guidance, the mixing time shall be at least 2 min for conventional free fall (drum) batch type concrete mixers. For other types of more efficient mixers, manufacturers' recommendations shall be followed.'

(Page 25, clause 10.3.3) — Substitute the following for the existing clause:

'10.3.3 Dosages of retarders, plasticizers and superplasticizers shall be restricted to 0.5, 1.0 and 2.0 percent respectively by mass of cementitious materials; however, the dosages of polycarboxylate based admixtures shall not exceed 1.0 percent. A higher value of above admixtures may be used, if agreed upon between the manufacturer and the constructor based on performance tests relating to workability, setting time and early age strength.'

(Page 25, clause 11.1, informal table) - Substitute the following for the existing table:
a) Deviation from specified dimensions of cross-section of columns and beams
b) Deviation from dimensions of footings:

1) Dimensions in plan
2) Eccentricity
3) Thickness
$+50$
$-10 \mathrm{~mm}$
0.02 times the width of the footing in the direction of deviation but not more than 50 mm
$+50$
$-10 \mathrm{~mm}$
or
$\pm 0.05$ times the specified thickness, whichever is less
(Page 27, clause 13.4, para 1, fourth sentence) - Delete.
[Page 30, Table 11 (see also Amendments No. 1 and 3)] - Substitute the following for the existing Table 11:

Table 11 Characteristic Compressive Strength Compliance Requirement
(Clauses 16.1 and 16.3)

| Specified <br> Grade | Mean of the Group of 4 Non-Overlapping Consecutive Test <br> Results in $\mathrm{N} / \mathrm{mm}^{2}$ | Individual Test <br> Results in $\mathrm{N} / \mathrm{mm}^{2}$ |
| :--: | :--: | :--: |
|  | Min | Min |
| (1) | (2) | (3) |

M 15 and
above
above
(rounded off to nearest $0.5 \mathrm{~N} / \mathrm{mm}^{2}$ )
or
$f_{i k}+3 \mathrm{~N} / \mathrm{mm}^{2}$,
whichever is greater

# NOTES 

1 In the absence of established value of standard deviation, the values given in Table 8 may be assumed, and attempt should be made to obtain results of 30 samples as early as possible to establish the value of standard deviation.
2 For concrete of quantity up to $30 \mathrm{~m}^{3}$ (where the number of samples to be taken is less than four as per the frequency of sampling given in 15.2 .2 ), the mean of test results of all such samples shall be $f_{i k}+4 \mathrm{~N} / \mathrm{mm}^{2}$, minimum and the requirement of minimum individual test results shall be $f_{i k}=2 \mathrm{~N} / \mathrm{mm}^{2}$, minimum. However, when the number of sample is only one as per 15.2 .2 , the requirement shall be $f_{i k}+4 \mathrm{~N} / \mathrm{mm}^{2}$, minimum.
[Page 41, clause 24.4.1 (a)] - Substitute the following for the existing:
'a) Calculate the sum of the midspan moment and the average of the support moments (neglecting signs) for each panel.'
(Page 42, clause 26.2.1, Note 2) - Insert the following new note:
'3 For plain cement concrete of M15 grade with nominal reinforcement, the design bond stress may be taken as $1.0 \mathrm{~N} / \mathrm{mm}^{2}$.

(Page 43, clause 26.2.1.1, para 2) - Insert the following at the end of para: 'For fusion bonded epoxy coated deformed bars, design bond stress values shall be taken as 80 percent of the values given in the above table.' (Page 67, clause 35.3.2, last para, third sentence) - Substitute the following for the existing sentence: 'For particularly aggressive environment, such as 'very severe' and 'extreme' categories given in Table 3, the assessed surface width of cracks should not in general, exceed 0.1 mm .' (Page 74, clause 40.5.2, formula) - Substitute, ' $\Sigma A_{w}$ ' for ' $A_{s}$ ' in the formula. [Page 80, clause B-2.1.1, informal table (see also Amendment No. 2)] - Substitute

| M 50 and above | for | M 50 M 55 |  |
| :--: | :--: | :--: | :--: |
| 5.2 |  | 5.2 | 5.6 |

[Page 81, Table 21 (see also Amendment No.2)] - Substitute the entries against M 55 and insert new row for M 60, as follows:

| Grade of <br> Concrete | Permissible Stress in Compression <br> Bending |  | Permissible Stress in <br> Bond (Average) for <br> Plain Bars in Tension |
| :--: | :--: | :--: | :--: |
| (1) | (2) | (3) | (4) |
| M 55 | 18.0 | 13.5 | 1.5 |
| M 60 | 20.0 | 15.0 | 1.6 |

(Page 92, clause E-1, line 5) - Substitute 'Fig. 27' for 'Fig. 26'.

.



