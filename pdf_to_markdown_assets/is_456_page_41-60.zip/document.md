capable of free rotation, or as members of a continuous framework with the supports, taking into account the stiffness of such supports. If such supports are formed due to beams which justify fixity at the support of slabs, then the effects on the supporting beam, such as, the bending of the web in the transverse direction of the beam and the torsion in the longitudinal direction of the beam, wherever applicable, shall also be considered in the design of the beam.
24.3.1 For the purpose of calculation of moments in slabs in a monolithic structure, it will generally be sufficiently accurate to assume that members connected to the ends of such slabs are fixed in position and direction at the ends remote from their connections with the slabs.

### 24.3.2 Slabs Carrying Concentrated Load

24.3.2.1 If a solid slab supported on two opposite edges, carries concentrated loads the maximum bending moment caused by the concentrated loads shall be assumed to be resisted by an effective width of slab (measured parallel to the supporting edges) as follows:
a) For a single concentrated load, the effective width shall be calculated in accordance with the following equation provided that it shall not exceed the actual width of the slab:

$$
b_{\mathrm{ef}}=k x\left(1-\frac{x}{l_{\mathrm{ef}}}\right)+a
$$

where

$$
\begin{aligned}
b_{\mathrm{ef}}= & \text { effective width of slab, } \\
k= & \text { constant having the vahies given in Table } \\
& 14 \text { depending upon the ratio of the width } \\
& \text { of the slab }(t) \text { to the effective span } l_{\mathrm{ef}}, \\
x= & \text { distance of the centroid of the } \\
& \text { concentrated load from nearer support, } \\
l_{\mathrm{ef}}= & \text { effective span, and } \\
a= & \text { width of the contact area of the } \\
& \text { concentrated load from nearer support } \\
& \text { measured parallel to the supported edge. }
\end{aligned}
$$

And provided further that in case of a load near the unsupported edge of a slab, the effective width shall not exceed the above value nor half the above value plus the distance of the load from the unsupported edge.
b) For two or more concentrated loads placed in a line in the direction of the span, the bending moment per metre width of slab shall be calculated separately for each load according to its appropriate effective width of slab calculated as in (a) above and added together for design calculations.
c) For two or more loads not in a line in the direction of the span, if the effective width of slab for one load does not overlap the effective width of slab for another load, both calculated as in (a) above, then the slab for each load can be designed separately. If the effective width of slab for one load overlaps the effective width of slab for an adjacent load, the overlapping portion of the slab shall be designed for the combined effect of the two loads.

Table 14 Values of $k$ for Simply Supported and Continuous Slabs
(Clause 24.3.2.1)

| $l / l_{\text {ef }}$ | $k$ for Simply <br> Supported Slabs | $k$ for Continuous <br> Slabs |
| :-- | :--: | :--: |
| 0.1 | 0.4 | 0.4 |
| 0.2 | 0.8 | 0.8 |
| 0.3 | 1.16 | 1.16 |
| 0.4 | 1.48 | 1.44 |
| 0.5 | 1.72 | 1.68 |
| 0.6 | 1.96 | 1.84 |
| 0.7 | 2.12 | 1.96 |
| 0.8 | 2.24 | 2.08 |
| 0.9 | 2.36 | 2.16 |
| 1.0 and above | 2.48 | 2.24 |

d) For cantilever solid slabs, the effective width shall be calculated in accordance with the following equation:

$$
b_{\mathrm{ef}}=1.2 a_{1}+a
$$

where

$$
\begin{aligned}
& b_{\mathrm{ef}}=\text { effective width, } \\
& a_{1}=\text { distance of the concentrated load from the } \\
& \text { face of the cantilever support, and } \\
& a=\text { width of contact area of the concentrated } \\
& \text { load measured parallel to the supporting } \\
& \text { edge. }
\end{aligned}
$$

Provided that the effective width of the cantilever slab shall not exceed one-third the length of the cantilever slab measured parallel to the fixed edge.
And provided further that when the concentrated load is placed near the extreme ends of the length of cantilever slab in the direction parallel to the fixed edge, the effective width shall not exceed the above value, nor shall it exceed half the above value plus the distance of the concentrated load from the extreme end measured in the direction parallel to the fixed edge.
24.3.2.2 For slabs other than solid slabs, the effective width shall depend on the ratio of the transverse and longitudinal flexural rigidities of the slab. Where this ratio is one, that is, where the transverse and longitudinal flexural rigidities are approximately equal, the value of effective width as found for solid slabs may be used. But as the ratio decreases, proportionately smaller value shall be taken.

24.3.2.3 Any other recognized method of analysis for cases of slabs covered by 24.3.2.1 and 24.3.2.2 and for all other cases of slabs may be used with the approval of the engineer-in-charge.
24.3.2.4 The critical section for checking shear shall be as given in 34.2.4.1.

### 24.4 Slabs Spanning in Two Directions at Right Angles

The slabs spanning in two directions at right angles and carrying uniformly distributed load may be designed by any acceptable theory or by using coefficients given in Annex D. For determining bending moments in slabs spanning in two directions at right angles and carrying concentrated load, any accepted method approved by the engineer-in-charge may be adopted.

NOTE-The most commonly used elastic methods are based on Pigeaud's or Wester-gaard's theory and the most commonly used limit state of collapse method is based on Johansen's yieldline theory.

### 24.4.1 Restrained Slab with Unequal Conditions at Adjacent Panels

In some cases the support moments calculated from Table 26 for adjacent panels may differ significantly. The following procedure may be adopted to adjust them:
a) Calculate the sum of moments at midspan and supports (neglecting signs).
b) Treat the values from Table 26 as fixed end moments.
c) According to the relative stiffness of adjacent spans, distribute the fixed end moments across the supports, giving new support moments.
d) Adjust midspan moment such that, when added to the support moments from (c) (neglecting
signs), the total should be equal to that from (a). If the resulting support moments are significantly greater than the value from Table 26, the tension steel over the supports will need to be extended further. The procedure should be as follows:

1) Take the span moment as parabolic between supports: its maximum value is as found from (d).
2) Determine the points of contraflexure of the new support moments [from (c)] with the span moment [from (1)].
3) Extend half the support tension steel at each end to at least an effective depth or 12 bar diameters beyond the nearest point of contraflexure.
4) Extend the full area of the support tension steel at each end to half the distance from (3).

### 24.5 Loads on Supporting Beams

The loads on beams supporting solid slabs spanning in two directions at right angles and supporting uniformly distributed loads, may be assumed to be in accordance with Fig. 7.

## 25 COMPRESSION MEMBERS

### 25.1 Definitions

25.1.1 Column or strut is a compression member, the effective length of which exceeds three times the least lateral dimension.

### 25.1.2 Short and Slender Compression Members

A compression member may be considered as short when both the slenderness ratios $\frac{l_{\mathrm{cy}}}{D}$ and $\frac{l_{\mathrm{cy}}}{b}$ are less than 12:
![chunk-0-img-0.jpeg](chunk-0-img-0.jpeg)

Fig. 7 Load Carried by Supporting Beams

where
$l_{\mathrm{ex}}=$ effective length in respect of the major axis,
$D=$ depth in respect of the major axis,
$l_{\text {sy }}=$ effective length in respect of the minor axis, and
$b=$ width of the member.
It shall otherwise be considered as a slender compression member.

### 25.1.3 Unsupported Length

The unsupported length, $l$, of a compression member shall be taken as the clear distance between end restraints except that:
a) in flat slab construction, it shall be clear distance between the floor and the lower extremity of the capital, the drop panel or slab whichever is the least.
b) in beam and slab construction, it shall be the clear distance between the floor and the underside of the shallower beam framing into the columns in each direction at the next higher floor level.
c) in columns restrained laterally by struts, it shall be the clear distance between consecutive struts in each vertical plane, provided that to be an adequate support, two such struts shall meet the columns at approximately the same level and the angle between vertical planes through the struts shall not vary more than $30^{\circ}$ from a right angle. Such struts shall be of adequate dimensions and shall have sufficient anchorage to restrain the member against lateral deflection.
d) in columns restrained laterally by struts or beams, with brackets used at the junction, it shall be the clear distance between the floor and the lower edge of the bracket, provided that the bracket width equals that of the beam strut and is at least half that of the column.

### 25.2 Effective Length of Compression Members

In the absence of more exact analysis, the effective length $l_{e f}$ of columns may be obtained as described in Annex $\overline{\mathrm{E}}$.

### 25.3 Slenderness Limits for Columns

25.3.1 The unsupported length between end restraints shall not exceed 60 times the least lateral dimension of a column.
25.3.2 If, in any given plane, one end of a column is unrestrained, its unsupported length, $l$, shall not exceed $\frac{100 b^{2}}{D}$.
where
$b=$ width of that cross-section, and
$D=$ depth of the cross-section measured in the plane under consideration.

### 25.4 Minimum Eccentricity

All columns shall be designed for minimum eccentricity, equal to the unsupported length of column/ 500 plus lateral dimensions/30, subject to a minimum of 20 mm . Where bi-axial bending is considered, it is sufficient to ensure that eccentricity exceeds the minimum about one axis at a time.

## 26 REQUIREMENTS GOVERNING REINFORCEMENT AND DETAILING

### 26.1 General

Reinforcing steel of same type and grade shall be used as main reinforcement in a structural member. However, simultaneous use of two different types or grades of steel for main and secondary reinforcement respectively is permissible.
26.1.1 Bars may be arranged singly, or in pairs in contact, or in groups of three or four bars bundled in contact. Bundled bars shall be enclosed within stirrups or ties. Bundled bars shall be tied together to ensure the bars remaining together. Bars larger than 32 mm diameter shall not be bundled, except in columns.
26.1.2 The recommendations for detailing for earthquake-resistant construction given in IS 13920 should be taken into consideration, where applicable (see also IS 4326).

### 26.2 Development of Stress in Reinforcement

The calculated tension or compression in any bar at any section shall be developed on each side of the section by an appropriate development length or end anchorage or by a combination thereof.

### 26.2.1 Development Length of Bars

The development length $L_{d}$ is given by

$$
L_{\mathrm{d}}=\frac{\phi}{\sqrt{4} \tau_{\mathrm{bd}}}
$$

where
$\phi=$ nominal diameter of the bar,
$\sigma_{s}=$ stress in bar at the section considered at design load, and
$\tau_{\text {bd }}=$ design bond stress given in 26.2.1.1.
NOTES
1 The development length includes anchorage values of hooks in tension reinforcement.
2 For bars of sections other than circular, the development length should be sufficient to develop the stress in the bar by bond.

26.2.1.1 Design bond stress in limit state method for plain bars in tension shall be as below:

| Grade of concrete | M 20 | M 25 | M 30 | M 35 | M 40 and above |
| :-- | :--: | :--: | :--: | :--: | :--: |
| Design bond stress, <br> $\tau_{\mathrm{bs}} \mathrm{N} / \mathrm{mm}^{2}$ | 1.2 | 1.4 | 1.5 | 1.7 | 1.9 |

For deformed bars conforming to IS 1786 these values shall be increased by 60 percent.
For bars in compression, the values of bond stress for bars in tension shall be increased by 25 percent.
The values of bond stress in working stress design, are given in B-2.1.

### 26.2.1.2 Bars bundled in contact

The development length of each bar of bundled bars shall be that for the individual bar, increased by 10 percent for two bars in contact, 20 percent for three bars in contact and 33 percent for four bars in contact.

### 26.2.2 Anchoring Reinforcing Bars

### 26.2.2.1 Anchoring bars in tension

a) Deformed bars may be used without end anchorages provided development length requirement is satisfied. Hooks should normally be provided for plain bars in tension.
b) Bends and hooks - Bends and hooks shall conform to IS 2502

1) Bends-The anchorage value of bend shall be taken as 4 times the diameter of the bar for each $45^{\circ}$ bend subject to a maximum of 16 times the diameter of the bar.
2) Hooks-The anchorage value of a standard U-type hook shall be equal to 16 times the diameter of the bar.

### 26.2.2.2 Anchoring bars in compression

The anchorage length of straight bar in compression shall be equal to the development length of bars in compression as specified in 26.2.1. The projected length of hooks, bends and straight lengths beyond bends if provided for a bar in compression, shall only be considered for development length.

### 26.2.2.3 Mechanical devices for anchorage

Any mechanical or other device capable of developing the strength of the bar without damage to concrete may be used as anchorage with the approval of the engineer-in-charge.

### 26.2.2.4 Anchoring shear reinforcement

a) Inclined bars - The development length shall be as for bars in tension; this length shall be measured as under:

1) In tension zone, from the end of the sloping or inclined portion of the bar, and
2) In the compression zone, from the mid depth of the beam.
b) Stirrups-Notwithstanding any of the provisions of this standard, in case of secondary reinforcement, such as stirrups and transverse ties, complete development lengths and anchorage shall be deemed to have been provided when the bar is bent through an angle of at least $90^{\circ}$ round a bar of at least its own diameter and is continued beyond the end of the curve for a length of at least eight diameters, or when the bar is bent through an angle of $135^{\circ}$ and is continued beyond the end of the curve for a length of at least six bar diameters or when the bar is bent through an angle of $180^{\circ}$ and is continued beyond the end of the curve for a length of at least four bar diameters.

### 26.2.2.5 Bearing stresses at bends

The bearing stress in concrete for bends and hooks described in IS 2502 need not be checked. The bearing stress inside a bend in any other bend shall be calculated as given below:

$$
\text { Bearing stress }=\frac{F_{\mathrm{bt}}}{r \phi}
$$

where
$F_{\mathrm{bt}}=$ tensile force due to design loads in a bar or group of bars,
$r=$ internal radius of the bend, and
$\phi=$ size of the bar or, in bundle, the size of bar of equivalent area.
For limit state method of design, this stress shall not. exceed $\frac{1.5 f_{\mathrm{db}}}{1+2 \phi / a}$ where $f_{\mathrm{db}}$ is the characteristic cube strength of concrete and $a$, for a particular bar or group of bars in contact shall be taken as the centre to centre distance between bars or groups of bars perpendicular to the plane of the bend; for a bar or group of bars adjacent to the face of the member $a$ shall be taken as the cover plus size of bar ( $\phi$ ). For working stress method of design, the bearing stress shall not exceed $\frac{f_{\mathrm{ob}}}{1+2 \phi / a}$.
26.2.2.6 If a change in direction of tension or compression reinforcement induces a resultant force acting outward tending to split the concrete, such force

should be taken up by additional links or stirrups. Bent tension bar at a re-entrant angle should be avoided.

### 26.2.3 Curtailment of Tension Reinforcement in Flexural Members

26.2.3.1 For curtailment, reinforcement shall extend beyond the point at which it is no longer required to resist flexure for a distance equal to the effective depth of the member or 12 times the bar diameter, whichever is greater except at simple support or end of cantilever. In addition 26.2.3.2 to 26.2.3.5 shall also be satisfied.

NOTE-A point at which reinforcement is no longer required to resist flexure is where the resistance moment of the section, considering only the continuing bars, is equal to the design moment.
26.2.3.2 Flexural reinforcement shall not be terminated in a tension zone unless any one of the following conditions is satisfied:
a) The shear at the cut-off point does not exceed two-thirds that permitted, including the shear strength of web reinforcement provided.
b) Stirrup area in excess of that required for shear and torsion is provided along each terminated bar over a distance from the cut-off point equal to three-fourths the effective depth of the member. The excess stirrup area shall be not less than $0.4 \mathrm{bs} / f_{g}$, where $b$ is the breadth of beam, $s$ is the spacing and $f_{g}$ is the characteristic strength of reinforcement in $\mathrm{N} / \mathrm{mm}^{2}$. The resulting spacing shall not exceed $d / 8 \beta_{h}$ where $\beta_{h}$ is the ratio of the area of bars cut-off to the total area of bars at the section, and $d$ is the effective depth.
c) For 36 mm and smaller bars, the continuing bars provide double the area required for flexure at the cut-off point and the shear does not exceed three-fourths that permitted.

### 26.2.3.3 Positive moment reinforcement

a) At least one-third the positive moment reinforcement in simple members and onefourth the positive moment reinforcement in continuous members shall extend along the same face of the member into the support, to a length equal to $L_{d} / 3$.
b) When a flexural member is part of the primary lateral load resisting system; the positive reinforcement required to be extended into the support as described in (a) shall be anchored to develop its design stress in tension at the face of the support.
c) At simple supports and at points of inflection, positive moment tension reinforcement shall be limited to a diameter such that $L_{d}$ computed for $f_{g}$ by 26.2 .1 does not exceed

$$
\frac{M_{1}}{V}+L_{0}
$$

where
$M_{1}=$ moment of resistance of the section assuming all reinforcement at the section to be stressed to $f_{g}$;
$f_{g}=0.87 f_{g}$ in the case of limit state design and the permissible stress $\sigma_{m}$ in the case of working stress design;
$V=$ shear force at the section due to design loads;
$L_{0}=$ sum of the anchorage beyond the centre of the support and the equivalent anchorage value of any hook or mechanical anchorage at simple support; and at a point of inflection, $L_{0}$ is limited to the effective depth of the members or $12 \phi$, whichever is greater; and
$\phi=$ diameter of bar.
The value of $M_{1} / V$ in the above expression may be increased by 30 percent when the ends of the reinforcement are confined by a compressive reaction.

### 26.2.3.4 Negative moment reinforcement

At least one-third of the total reinforcement provided for negative moment at the support shall extend beyond the point of inflection for a distance not less than the effective depth of the member of $12 \phi$ or one-sixteenth of the clear span whichever is greater.

### 26.2.3.5 Curtailment of bundled bars

Bars in a bundle shall terminate at different points spaced apart by not less than 40 times the bar diameter except for bundles stopping at a support.

### 26.2.4 Special Members

Adequate end anchorage shall be provided for tension reinforcement in flexural members where reinforcement stress is not directly proportional to moment, such as sloped, stepped, or tapered footings; brackets; deep beams; and members in which the tension reinforcement is not parallel to the compression face.

### 26.2.5 Reinforcement Splicing

Where splices are provided in the reinforcing bars, they shall as far as possible be away from the sections of maximum stress and be staggered. It is recommended that splices in flexural members should not be at sections where the bending moment is more than 50 percent of the moment of resistance; and not more than half the bars shall be spliced at a section.
Where more than one-half of the bars are spliced at a section or where splices are made at points of maximum stress, special precautions shall be taken,

such as increasing the length of lap and/or using spirals or closely-spaced stirrups around the length of the splice.

### 26.2.5.1 Lap splices

a) Lap splices shall not be used for bars larger than 36 mm ; for larger diameters, bars may be welded (see 12.4); in cases where welding is not practicable, lapping of bars larger than 36 mm may be permitted, in which case additional spirals should be provided around the lapped bars.
b) Lap splices shall be considered as staggered if the centre to centre distance of the splices is not less than 1.3 times the lap length calculated as described in (c).
c) Lap length including anchorage value of hooks for bars in flexural tension shall be $L_{A}$ (see 26.2.1) or $30 \phi$ whichever is greater and for direct tension shall be $2 L_{d}$ or $30 \phi$ whichever is greater. The straight length of the lap shall not be less than $15 \phi$ or 200 mm . The following provisions shall also apply:
Where lap occurs for a tension bar located at:

1) top of a section as cast and the minimum cover is less than twice the diameter of the lapped bar, the lap length shall be increased by a factor of 1.4 .
2) corner of a section and the minimum cover to either face is less than twice the diameter of the lapped bar or where the clear distance between adjacent laps is less than 75 mm or 6 times the diameter of lapped bar, whichever is greater, the lap length should be increased by a factor of 1.4 .
Where both condition (1) and (2) apply, the lap length should be increased by a factor of 2.0 .
NOTE-Splices in tension members shall be enclosed in spirals made of bars not less than 6 mm diameter with pitch not more than 100 mm .
d) The lap length in compression shall be equal to the development length in compression, calculated as described in 26.2 .1 , but not less than $24 \phi$.
e) When bars of two different diameters are to be spliced, the lap length shall be calculated on the basis of diameter of the smaller bar.
f) When splicing of welded wire fabric is to be carried out, lap splices of wires shall be made so that overlap measured between the extreme cross wires shall be not less than the spacing of cross wires plus 100 mm .
g) In case of bundled bars, lapped splices of bundled bars shall be made by splicing one bar
at a time; such individual splices within a bundle shall be staggered.

### 26.2.5.2 Strength of welds

The following values may be used where the strength of the weld has been proved by tests to be at least as great as that of the parent bar.
a) Splices in compression - For welded splices and mechanical connection, 100 percent of the design strength of joined bars.
b) Splices in tension

1) 80 percent of the design strength of welded bars ( 100 percent if welding is strictly supervised and if at any cross-section of the member not more than 20 percent of the tensile reinforcement is welded).
2) 100 percent of design strength of mechanical connection.

### 26.2.5.3 End-bearing splices

End-bearing splices shall be used only for bars in compression. The ends of the bars shall be square cut and concentric bearing ensured by suitable devices.

### 26.3 Spacing of Reinforcement

26.3.1 For the purpose of this clause, the diameter of a round bar shall be its nominal diameter, and in the case of bars which are not round or in the case of deformed bars or crimped bars, the diameter shall be taken as the diameter of a circle giving an equivalent effective area. Where spacing limitations and minimum concrete cover (see 26.4) are based on bar diameter, a group of bars bundled in contact shall be treated as a single bar of diameter derived from the total equivalent area.

### 26.3.2 Minimum Distance Between Individual Bars

The following shall apply for spacing of bars:
a) The horizontal distance between two parallel main reinforcing bars shall usually be not less than the greatest of the following:

1) The diameter of the bar if the diameters are equal,
2) The diameter of the larger bar if the diameters are unequal, and
3) 5 mm more than the nominal maximum size of coarse aggregate.
NOTE-This does not preclude the use of larger size of aggregates beyond the congested reinforcement in the same member; the size of aggregates may be reduced around congested reinforcement to comply with this provision.
b) Greater horizontal distance than the minimum specified in (a) should be provided wherever possible. However when needle vibrators are

used the horizontal distance between bars of a group may be reduced to two-thirds the nominal maximum size of the coarse aggregate, provided that sufficient space is left between groups of bars to enable the vibrator to be immersed.
c) Where there are two or more rows of bars, the bars shall be vertically in line and the minimum vertical distance between the bars shall be 15 mm , two-thirds the nominal maximum size of aggregate or the maximum size of bars, whichever is greater.

### 26.3.3 Maximum Distance Between Bars in Tension

Unless the calculation of crack widths shows that a greater spacing is acceptable, the following rules shall be applied to flexural members in normal internal or external conditions of exposure.
a) Beams - The horizontal distance between parallel reinforcement bars, or groups, near the tension face of a beam shall not be greater than the value given in Table 15 depending on the amount of redistribution carried out in analysis and the characteristic strength of the reinforcement.
b) Slabs

1) The horizontal distance between parallel main reinforcement bars shall not be more than three times the effective depth of solid slab or 300 mm whichever is smaller.
2) The horizontal distance between parallel reinforcement bars provided against shrinkage and temperature shall not be more than five times the effective depth of a solid slab or 450 mm whichever is smaller.

### 26.4 Nominal Cover to Reinforcement

### 26.4.1 Nominal Cover

Nominal cover is the design depth of concrete cover to all steel reinforcements, including links. It is the dimension used in design and indicated in the drawings. It shall be not less than the diameter of the bar.

### 26.4.2 Nominal Cover to Meet Durability Requirement

Minimum values for the nominal cover of normalweight aggregate concrete which should be provided to all reinforcement, including links depending on the condition of exposure described in 8.2 .3 shall be as given in Table 16.
26.4.2.1 However for a longitudinal reinforcing bar in a column nominal cover shall in any case not be less than 40 mm , or less than the diameter of such bar. In the case of columns of minimum dimension of 200 mm or under, whose reinforcing bars do not exceed 12 mm , a nominal cover of 25 mm may be used.
26.4.2.2 For footings minimum cover shall be 50 mm .

### 26.4.3 Nominal Cover to Meet Specified Period of Fire Resistance

Minimum values of nominal cover of normal-weight aggregate concrete to be provided to all reinforcement including links to meet specified period of fire resistance shall be given in Table 16A.

### 26.5 Requirements of Reinforcement for Structural Members

### 26.5.1 Beams

### 26.5.1.1 Tension reinforcement

a) Minimum reinforcement-The minimum area of tension reinforcement shall be not less than that

Table 15 Clear Distance Between Bars
(Clause 26.3.3)

| $f_{s}$ | Percentage Redistribution to or from Section Considered |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | -30 | -15 | 0 | +15 |  | $+30$ |
|  | Clear Distance Between Bars |  |  |  |  |  |
| $\mathrm{N} / \mathrm{mm}^{2}$ | mm | mm | mm | mm |  | mm |
| 250 | 215 | 260 | 300 | 300 |  | 300 |
| 415 | 125 | 155 | 180 | 210 |  | 235 |
| 500 | 105 | 130 | 150 | 175 |  | 195 |

NOTE - The spacings given in the table are not applicable to members subjected to particularly aggressive environments unless in the calculation of the moment of resistance, $f_{s}$ has been limited to $300 \mathrm{~N} / \mathrm{mm}^{2}$ in limit state design and $\sigma_{w}$ limited to $165 \mathrm{~N} / \mathrm{mm}^{2}$ in working stress design.

Table 16 Nominal Cover to Meet Durability Requirements
(Clause 26.4.2)

|  | Exposure | Nominal Concrete Cover in mm not Less Than |
| :-- | :-- | :--: |
|  | Mild | 20 |
|  | Moderate | 30 |
|  | Severe | 45 |
|  | Very severe | 50 |
|  | Extreme | 75 |

# NOTES 

1 For main reinforcement up to 12 mm diameter bar for mild exposure the nominal cover may be reduced by 5 mm .
2 Unless specified otherwise, actual concrete cover should not deviate from the required nominal cover by $+10 \mathrm{~mm}$
3 For exposure condition 'severe' and 'very severe', reduction of 5 mm may be made, where concrete grade is M35 and above.

Table 16A
Nominal Cover to Meet Specified Period of Fire Resistance
(Clauses 21.4 and 26.4.3 and Fig. 1)

| Fire <br> Resis- <br> tance |  | Nominal Cover |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Beams |  | Slabs |  | Ribs |  | Columns |
|  | Simply supported | Continuous | Simply supported | Continuous | Simply supported | Continuous |  |
| h | mm | mm | mm | mm | mm | mm | mm |
| 0.5 | 20 | 20 | 20 | 20 | 20 | 20 | 40 |
| 1 | 20 | 20 | 20 | 20 | 20 | 20 | 40 |
| 1.5 | 20 | 20 | 25 | 20 | 35 | 20 | 40 |
| 2 | 40 | 30 | 35 | 25 | 45 | 35 | 40 |
| 3 | 60 | 40 | 45 | 35 | 55 | 45 | 40 |
| 4 | 70 | 50 | 55 | 45 | 65 | 55 | 40 |
| NOTES |  |  |  |  |  |  |  |

1 The nominal covers given relate specifically to the minimum member dimensions given in Fig. 1.
2 Cases that lie below the bold line require attention to the additional measures necessary to reduce the risks of spalling (see 21.3.1).
given by the following:

$$
\frac{A_{s}}{b d}=\frac{0.85}{f_{y}}
$$

where
$A_{s}=$ minimum area of tension reinforcement,
$b=$ breadth of beam or the breadth of the web of T-beam,
$d=$ effective depth, and
$f_{y}=$ characteristic strength of reinforcement in $\mathrm{N} / \mathrm{mm}^{2}$.
b) Maximum reinforcement-The maximum area of tension reinforcement shall not exceed 0.04 bD .

### 26.5.1.2 Compression reinforcement

The maximum area of compression reinforcement shall not exceed 0.04 bD . Compression reinforcement in beams shall be enclosed by stirrups for effective lateral restraint. The arrangement of stirrups shall be as specified in 26.5.3.2.

### 26.5.1.3 Side face reinforcement

Where the depth of the web in a beam exceeds 750 mm , side face reinforcement shall be provided along the two faces. The total area of such reinforcement shall be not less than 0.1 percent of the web area and shall be distributed equally on two faces at a spacing not exceeding 300 mm or web thickness whichever is less.
26.5.1.4 Transverse reinforcement in beams for shear and torsion

The transverse reinforcement in beams shall be taken around the outer-most tension and compression bars. In T-beams and I-beams, such reinforcement shall pass around longitudinal bars located close to the outer face of the flange.

### 26.5.1.5 Maximum spacing of shear reinforcement

The maximum spacing of shear reinforcement measured along the axis of the member shall not exceed $0.75 d$ for vertical stirrups and $d$ for inclined stirrups at $45^{\circ}$, where $d$ is the effective depth of the section

under consideration. In no case shall the spacing exceed 300 mm .

### 26.5.1.6 Minimum shear reinforcement

Minimum shear reinforcement in the form of stirrups shall be provided such that:

$$
\frac{A_{y v}}{b s_{v}} \geq \frac{0.4}{0.87 f_{y}}
$$

where

$$
\begin{aligned}
A_{y v}= & \text { total cross-sectional area of stirrup legs } \\
& \text { effective in shear, } \\
s_{v}= & \text { stirrup spacing along the length of the } \\
& \text { member, } \\
b= & \text { breadth of the beam or breadth of the } \\
& \text { web of flanged beam, and } \\
f_{y}= & \text { characteristic strength of the stirrup } \\
& \text { reinforcement in } \mathrm{N} / \mathrm{mm}^{2} \text { which shall not } \\
& \text { be taken greater than } 415 \mathrm{~N} / \mathrm{mm}^{2} .
\end{aligned}
$$

Where the maximum shear stress calculated is less than half the permissible value and in members of minor structural importance such as lintels, this provision need not be complied with.

### 26.5.1.7 Distribution of torsion reinforcement

When a member is designed for torsion (see 41 or B-6) torsion reinforcement shall be provided as below:
a) The transverse reinforcement for torsion shall be rectangular closed stirrups placed perpendicular to the axis of the member. The spacing of the stirrups shall not exceed the least of
$x_{1}, \frac{x_{1}+y_{1}}{4}$ and 300 mm , where $x_{1}$ and $y_{1}$ are respectively the short and long dimensions of the stirrup.
b) Longitudinal reinforcement shall be placed as close as is practicable to the corners of the crosssection and in all cases, there shall be at least one longitudinal bar in each corner of the ties. When the cross-sectional dimension of the member exceeds 450 mm , additional longitudinal bars shall be provided to satisfy the requirements of minimum reinforcement and spacing given in 26.5.1.3.
26.5.1.8 Reinforcement in flanges of T-and L-beams shall satisfy the requirements in 23.1.1(b). Where flanges are in tension, a part of the main tension reinforcement shall be distributed over the effective flange width or a width equal to one-tenth of the span, whichever is smaller. If the effective flange width exceeds one-tenth of the span, nominal longitudinal reinforcement shall be provided in the outer portions of the flange.

### 26.5.2 Slabs

The rules given in 26.5.2.1 and 26.5.2.2 shall apply to slabs in addition to those given in the appropriate clauses.

### 26.5.2.1 Minimum reinforcement

The mild steel reinforcement in either direction in slabs shall not be less than 0.15 percent of the total crosssectional area. However, this value can be reduced to 0.12 percent when high strength deformed bars or welded wire fabric are used.

### 26.5.2.2 Maximum diameter

The diameter of reinforcing bars shall not exceed oneeight of the total thickness of the slab.

### 26.5.3 Columns

### 26.5.3.1 Longitudinal reinforcement

a) The cross-sectional area of longitudinal reinforcement, shall be not less than 0.8 percent nor more than 6 percent of the gross crosssectional area of the column.
NOTE - The use of 6 percent reinforcement may involve practical difficulties in placing and compacting of concrete; hence lower percentage is recommended. Where bars from the columns below have to be lapped with those in the column under consideration, the percentage of steel shall usually not exceed 4 percent.
b) In any column that has a larger cross-sectional area than that required to support the load, the minimum percentage of steel shall be based upon the area of concrete required to resist the direct stress and not upon the actual area.
c) The minimum number of longitudinal bars provided in a column shall be four in rectangular columns and six in circular columns.
d) The bars shall not be less than 12 mm in diameter.
e) A reinforced concrete column having helical reinforcement shall have at least six bars of longitudinal reinforcement within the helical reinforcement.
f) In a helically reinforced column, the longitudinal bars shall be in contact with the helical reinforcement and equidistant around its inner circumference.
g) Spacing of longitudinal bars measured along the periphery of the column shall not exceed 300 mm .
h) In case of pedestals in which the longitudinal reinforcement is not taken in account in strength calculations, nominal longitudinal reinforcement not less than 0.15 percent of the cross-sectional area shall be provided.

NOTE - Pedestal is a compression member, the effective length of which does not exceed three times the least lateral dimension.

### 26.5.3.2 Transverse reinforcement

a) General-A reinforced concrete compression member shall have transverse or helical reinforcement so disposed that every longitudinal bar nearest to the compression face has effective lateral support against buckling subject to provisions in (b). The effective lateral support is given by transverse reinforcement either in the form of circular rings capable of taking up circumferential tension or by polygonal links (lateral ties) with internal angles not exceeding $135^{\circ}$. The ends of the transverse reinforcement shall be properly anchored [see 26.2.2.4 (b)].
b) Arrangement of transverse reinforcement

1) If the longitudinal bars are not spaced more than 75 mm on either side, transverse reinforcement need only to go round corner and alternate bars for the purpose of providing effective lateral supports (see Fig. 8).
2) If the longitudinal bars spaced at a distance of not exceeding 48 times the diameter of the tie are effectively tied in two directions, additional longitudinal bars in between these bars need to be tied in one direction by open ties (see Fig. 9).
3) Where the longitudinal reinforcing bars in a compression member are placed in more than one row, effective lateral support to the longitudinal bars in the inner rows may be assumed to have been provided if:
i) transverse reinforcement is provided for the outer-most row in accordance with 26.5.3.2, and
ii) no bar of the inner row is closer to the nearest compression face than three times the diameter of the largest bar in the inner row (see Fig. 10).
4) Where the longitudinal bars in a compression member are grouped (not in contact) and each group adequately tied with transverse reinforcement in accordance with 26.5.3.2, the transverse reinforcement for the compression member as a whole may be provided on the assumption that each group is a single longitudinal bar for purpose of determining the pitch and diameter of the transverse reinforcement in accordance with 26.5.3.2. The diameter of such transverse
reinforcement need not, however, exceed 20 mm (see Fig. 11).
c) Pitch and diameter of lateral ties
5) Pitch-The pitch of transverse reinforcement shall be not more than the least of the following distances:
i) The least lateral dimension of the compression members;
ii) Sixteen times the smallest diameter of the longitudinal reinforcement bar to be tied; and
iii) 300 mm .
6) Diameter-The diameter of the polygonal links or lateral ties shall be not less than onefourth of the diameter of the largest longitudinal bar, and in no case less than 16 mm .
d) Helical reinforcement
7) Pitch-Helical reinforcement shall be of regular formation with the turns of the helix spaced evenly and its ends shall be anchored properly by providing one and a half extra turns of the spiral bar. Where an increased load on the column on the strength of the helical reinforcement is allowed for, the pitch of helical turns shall be not more than 75 mm , nor more than one-sixth of the core diameter of the column, nor less than 25 mm , nor less than three times the diameter of the steel bar forming the helix. In other cases, the requirements of 26.5.3.2 shall be complied with.
8) The diameter of the helical reinforcement shall be in accordance with 26.5.3.2 (c) (2).
26.5.3.3 In columns where longitudinal bars are offset at a splice, the slope of the inclined portion of the bar with the axis of the column shall not exceed 1 in 6 , and the portions of the bar above and below the offset shall be parallel to the axis of the column. Adequate horizontal support at the offset bends shall be treated as a matter of design, and shall be provided by metal ties, spirals, or parts of the floor construction. Metal ties or spirals so designed shall be placed near (not more than eight-bar diameters from) the point of bend. The horizontal thrust to be resisted shall be assumed as one and half times the horizontal components of the nominal stress in the inclined portion of the bar. Offset bars shall be bent before they are placed in the forms. Where column faces are offset 75 mm or more, splices of vertical bars adjacent to the offset face shall be made by separate dowels overlapped as specified in 26.2.5.1.

## 27 EXPANSION JOINTS

27.1 Structures in which marked changes in plan dimensions take place abruptly shall be provided with expansion on joints at the section where such changes occur. Expansion joints shall be so provided that the necessary movement occurs with a minimum resistance at the joint. The structures adjacent to the joint should preferably be supported on separate columns or walls but not necessarily on separate foundations. Reinforcement shall not extend across an expansion joint and the break between the sections shall be complete.
![chunk-0-img-1.jpeg](chunk-0-img-1.jpeg)

All dimensions in millimetres.
Fig. 8
![chunk-0-img-2.jpeg](chunk-0-img-2.jpeg)

All dimensions in millimetres.
Fig. 10
27.2 The details as to the length of a structure where expansion joints have to be provided can be determined after taking into consideration various factors, such as temperature, exposure to weather, the time and season of the laying of the concrete, etc. Normally structures exceeding 45 m in length are designed with one or more expansion joints. However in view of the large number of factors involved in deciding the location, spacing and nature of expansion joints, the provision of expansion joint in reinforced cement concrete structures should be left to the discretion of the designer. IS 3414 gives the design considerations, which need to be examined and provided for.
![chunk-0-img-3.jpeg](chunk-0-img-3.jpeg)

All dimensions in millimetres.
Fig. 9
![chunk-0-img-4.jpeg](chunk-0-img-4.jpeg)

Fig. 11

# SECTION 4 SPECIAL DESIGN REQUIREMENTS FOR STRUCTURAL MEMBERS AND SYSTEMS 

## 28 CONCRETE CORBELS

### 28.1 General

A corbel is a short cantilever projection which supports a load bearing member and where:
a) the distance $a_{v}$ between the line of the reaction to the supported load and the root of the corbel is less than $d$ (the effective depth of the root of the corbel); and
b) the depth at the outer edge of the contact area of the supported load is not less than one-half of the depth at the root of the corbel.

The depth of the corbel at the face of the support is determined in accordance with 40.5.1.

### 28.2 Design

### 28.2.1 Simplifying Assumptions

The concrete and reinforcement may be assumed to act as elements of a simple strut-and-tie system, with the following guidelines:
a) The magnitude of the resistance provided to horizontal force should be not less than one-half of the design vertical load on the corbel (see also 28.2.4).
b) Compatibility of strains between the strut-andtie at the corbel root should be ensured.
It should be noted that the horizontal link requirement described in 28.2 .3 will ensure satisfactory serviceability performance.

### 28.2.2 Reinforcement Anchorage

At the front face of the corbel, the reinforcement should be anchored either by:
a) welding to a transverse bar of equal strength in this case the bearing area of the load should stop short of the face of the support by a distance equal to the cover of the tie reinforcement, or
b) bending back the bars to form a loop - in this case the bearing area of the load should not project beyond the straight portion of the bars forming the main tension reinforcement.

### 28.2.3 Shear Reinforcement

Shear reinforcement should be provided in the form of horizontal links distributed in the upper two-third of the effective depth of root of the corbel; this reinforcement should be not less than one-half of the area of the main tension reinforcement and should be adequately anchored.

### 28.2.4 Resistance to Applied Horizontal Force

Additional reinforcement connected to the supported member should be provided to transmit this force in its entirety.

## 29 DEEP BEAMS

### 29.1 General

a) A beam shall be deemed to be a deep beam when the ratio of effective span to overall depth, $\frac{l}{D}$ is less than:

1) 2.0 for a simply supported beam; and
2) 2.5 for a continuous beam.
b) A deep beam complying with the requirements of 29.2 and 29.3 shall be deemed to satisfy the provisions for shear.

### 29.2 Lever Arm

The lever arm $z$ for a deep beam shall be detemined as below:
a) For simply supported beams:

$$
\begin{array}{ll}
z=0.2(l+2 D) & \text { when } 1 \leq \frac{l}{D} \leq 2 \\
\text { or } & \\
z=0.6 l & \text { when } \frac{l}{D}<1
\end{array}
$$

b) For continuous beams:

$$
\begin{array}{ll}
z=0.2(l+1.5 D) & \text { when } 1 \leq \frac{l}{D} \leq 2.5 \\
\text { or } & \\
z=0.5 l & \text { when } \frac{l}{D}<1
\end{array}
$$

where $l$ is the effective span taken as centre to centre distance between supports or 1.15 times the clear span, whichever is smaller, and $D$ is the overall depth.

### 29.3 Reinforcement

### 29.3.1 Positive Reinforcement

The tensile reinforcement required to resist positive bending moment in any span of a deep beam shall:
a) extend without curtailment between supports;
b) be embedded beyond the face of each support, so that at the face of the support it shall have a development length not less than $0.8 L_{y}$; where $L_{y}$ is the development length (see 26.2.1), for the design stress in the reinforcement; and

c) be placed within a zone of depth equal to $0.25 D-0.05 l$ adjacent to the tension face of the beam where $D$ is the overall depth and $l$ is the effective span.

### 29.3.2 Negative Reinforcement

a) Termination of reinforcement - For tensile reinforcement required to resist negative bending moment over a support of a deep beam:

1) It shall be permissible to terminate not more than half of the reinforcement at a distance of 0.5 D from the face of the support where $D$ is as defined in 29.2; and
2) The remainder shall extend over the full span.
b) Distribution-When ratio of clear span to overall depth is in the range 1.0 to 2.5 , tensile reinforcement over a support of a deep beam shall be placed in two zones comprising:
3) a zone of depth 0.2 D , adjacent to the tension face, which shall contain a proportion of the tension steel given by

$$
0.5\left(\frac{l}{D}-0.5\right)
$$

where

$$
\begin{aligned}
& l=\text { clear span, and } \\
& D=\text { overall depth. }
\end{aligned}
$$

2) a zone measuring 0.3 D on either side of the mid-depth of the beam, which shall contain the remainder of the tension steel, evenly distributed.
For span to depth ratios less than unity, the steel shall be evenly distributed over a depth of 0.8 D measured from the tension face.

### 29.3.3 Vertical Reinforcement

If forces are applied to a deep beam in such a way that hanging action is required, bars or suspension stirrups shall be provided to carry all the forces concerned.

### 29.3.4 Side Face Reinforcement

Side face reinforcement shall comply with requirements of minimum reinforcement of walls (see 32.4).

## 30 RIBBED, HOLLOWBLOCK OR VOIDED SLAB

### 30.1 General

This covers the slabs constructed in one of the ways described below:
a) As a series of concrete ribs with topping cast on forms which may be removed after the concrete has set;
b) As a series of concrete ribs between precast blocks which remain part of the completed
structure; the top of the ribs may be connected by a topping of concrete of the same strength as that used in the ribs; and
c) With a continuous top and bottom face but containing voids of rectangular, oval or other shape.

### 30.2 Analysis of Structure

The moments and forces due to design loads on continuous slabs may be obtained by the methods given in Section 3 for solid slabs. Alternatively, the slabs may be designed as a series of simply supported spans provided they are not exposed to weather or corrosive conditions; wide cracks may develop at the supports and the engineer shall satisfy himself that these will not impair finishes or lead to corrosion of the reinforcement.

### 30.3 Shear

Where hollow blocks are used, for the purpose of calculating shear stress, the rib width may be increased to take account of the wall thickness of the block on one side of the rib; with narrow precast units, the width of the jointing mortar or concrete may be included.

### 30.4 Deflection

The recommendations for deflection in respect of solid slabs may be applied to ribbed, hollow block or voided construction. The span to effective depth ratios given in 23.2 for a flanged beam are applicable but when calculating the final reduction factor for web width, the rib width for hollow block slabs may be assumed to include the walls of the blocks on both sides of the rib. For voided slabs and slabs constructed of box or I-section units, an effective rib width shall be calculated assuming all material below the upper flange of the unit to be concentrated in a rectangular rib having the same cross-sectional area and depth.

### 30.5 Size and Position of Ribs

In-situ ribs shall be not less than 65 mm wide. They shall be spaced at centres not greater than 1.5 m apart and their depth, excluding any topping, shall be not more than four times their width. Generally ribs shall be formed along each edge parallel to the span of one way slabs. When the edge is built into a wall or rests on a beam, a rib at least as wide as the bearing shall be formed along the edge.

### 30.6 Hollow Blocks and Formers

Blocks and formers may be of any suitable material. Hollow clay tiles for the filler type shall conform to IS 3951 (Part 1). When required to contribute to the

structural strength of a slab they shall:
a) be made of concrete or burnt clay; and
b) have a crushing strength of at least $14 \mathrm{~N} / \mathrm{mm}^{2}$ measured on the net section when axially loaded in the direction of compressive stress in the slab.

### 30.7 Arrangement of Reinforcement

The recommendations given in 26.3 regarding maximum distance between bars apply to areas of solid concrete in this form of construction. The curtailment, anchorage and cover to reinforcement shall be as described below:
a) At least 50 percent of the total main reinforcement shall be carried through at the bottom on to the bearing and anchored in accordance with 26.2.3.3.
b) Where a slab, which is continuous over supports, has been designed as simply supported, reinforcement shall be provided over the support to control cracking. This reinforcement shall have a cross-sectional area of not less than onequarter that required in the middle of the adjoining spans and shall extend at least onetenth of the clear span into adjoining spans.
c) In slabs with permanent blocks, the side cover to the reinforcement shall not be less than 10 mm . In all other cases, cover shall be provided according to 26.4 .

### 30.8 Precasts Joists and Hollow Filler Blocks

The construction with precast joists and hollow concrete filler blocks shall conform to IS 6061 (Part 1) and precast joist and hollow clay filler blocks shall conform to IS 6061 (Part 2).

## 31 FLAT SLABS

### 31.1 General

The term flat slab means a reinforced concrete slab with or without drops, supported generally without beams, by columns with or without flared column heads (see Fig. 12). A flat slab may be solid slab or may have recesses formed on the soffit so that the soffit comprises a series of ribs in two directions. The recesses may be formed by removable or permanent filler blocks.
31.1.1 For the purpose of this clause, the following definitions shall apply:
a) Column strip - Column strip means a design strip having a width of $0.25 l_{1}$, but not greater than $0.25 l_{1}$ on each side of the column centreline, where $l_{1}$ is the span in the direction moments are being determined, measured centre to centre of supports and $l_{2}$ is the span transverse
to $l_{1}$, measured centre to centre of supports.
b) Middle strip-Middle strip means a design strip bounded on each of its opposite sides by the column strip.
c) Panel-Panel means that part of a slab bounded on each of its four sides by the centre-line of a column or centre-lines of adjacent spans.

### 31.2 Proportioning

### 31.2.1 Thickness of Flat Slab

The thickness of the flat slab shall be generally controlled by considerations of span to effective depth ratios given in 23.2 .
For slabs with drops conforming to 31.2 .2 , span to effective depth ratios given in 23.2 shall be applied directly; otherwise the span to effective depth ratios obtained in accordance with provisions in 23.2 shall be multiplied by 0.9 . For this purpose, the longer span shall be considered. The minimum thickness of slab shall be 125 mm .

### 31.2.2 Drop

The drops when provided shall be rectangular in plan, and have a length in each direction not less than onethird of the panel length in that direction. For exterior panels, the width of drops at right angles to the noncontinuous edge and measured from the centre-line of the columns shall be equal to one-half the width of drop for interior panels.

### 31.2.3 Column Heads

Where column heads are provided, that portion of a column head which lies within the largest right circular cone or pyramid that has a vertex angle of $90^{\circ}$ and can be included entirely within the outlines of the column and the column head, shall be considered for design purposes (see Fig.12).

### 31.3 Determination of Bending Moment

### 31.3.1 Methods of Analysis and Design

It shall be permissible to design the slab system by one of the following methods:
a) The direct design method as specified in 31.4, and
b) The equivalent frame method as specified in 31.5 .
In each case the applicable limitations given in 31.4 and 31.5 shall be met.

### 31.3.2 Bending Moments in Panels with Marginal Beams or Walls

Where the slab is supported by a marginal beam with a depth greater than 1.5 times the thickness of the slab, or by a wall, then:

![chunk-0-img-5.jpeg](chunk-0-img-5.jpeg)

NOTE $-D_{s}$ is the diameter of column or column head to be considered for design and $d$ is effective depth of slab or drop as appropriate.

Fig. 12 Critical Sections for Shear in Flat Slabs
a) the total load to be carried by the beam or wall shall comprise those loads directly on the wall or beam plus a uniformly distributed load equal to one-quarter of the total load on the slab, and
b) the bending moments on the half-column strip adjacent to the beam or wall shall be one-quarter of the bending moments for the first interior column strip.

### 31.3.3 Transfer of Bending Moments to Columns

When unbalanced gravity load, wind, earthquake, or other lateral loads cause transfer of bending moment between slab and column, the flexural stresses shall be investigated using a fraction, $\alpha$ of the moment given by:

$$
\alpha=\frac{1}{1+\frac{2}{3} \sqrt{a_{1} / a_{2}}}
$$

where
$a_{1}=$ overall dimension of the critical section for shear in the direction in which moment acts, and
$a_{2}=$ overall dimension of the critical section for shear transverse to the direction in which moment acts.

A slab width between lines that are one and one-half slab or drop panel thickness; $1.5 D$, on each side of the column or capital may be considered effective, $D$ being the size of the column.
Concentration of reinforcement over column head by closer spacing or additional reinforcement may be used to resist the moment on this section:

### 31.4 Direct Design Method

### 31.4.1 Limitations

Slab system designed by the direct design method shall fulfil the following conditions:
a) There shall be minimum of three continuous spans in each direction,
b) The panels shall be rectangular, and the ratio of the longer span to the shorter span within a panel shall not be greater than 2.0 ,
c) It shall be permissible to offset columns to a maximum of 10 percent of the span in the direction of the offset notwithstanding the provision in (b),
d) The successive span lengths in each direction shall not differ by more than one-third of the longer span. The end spans may be shorter but not longer than the interior spans, and

e) The design live load shall not exceed three times the design dead load.

### 31.4.2 Total Design Moment for a Span

31.4.2.1 In the direct design method, the total design moment for a span shall be determined for a strip bounded laterally by the centre-line of the panel on each side of the centre-line of the supports.
31.4.2.2 The absolute sum of the positive and average negative bending moments in each direction shall be taken as:

$$
M_{o}=\frac{W l_{0}}{8}
$$

where
$M_{o}=$ total moment;
$W=$ design load on an area $l_{2} l_{3}$;
$l_{o}=$ clear span extending from face to face of columns, capitals, brackets or walls, but not less than $0.65 l_{1}$;
$l_{1}=$ length of span in the direction of $M_{o}$; and
$l_{2}=$ length of span transverse to $l_{1}$.
31.4.2.3 Circular supports shall be treated as square supports having the same area.
31.4.2.4 When the transverse span of the panels on either side of the centre-line of supports varies, $l_{2}$ shall be taken as the average of the transverse spans.
31.4.2.5 When the span adjacent and parallel to an edge is being considered, the distance from the edge to the centre-line of the panel shall be substituted for $l_{2}$ in 31.4.2.2.

### 31.4.3 Negative and Positive Design Moments

31.4.3.1 The negative design moment shall be located at the face of rectangular supports, circular supports being treated as square supports having the same area.
31.4.3.2 In an interior span, the total design moment $M_{o}$ shall be distributed in the following proportions:

Negative design moment
0.65

Positive design moment
0.35
31.4.3.3 In an end span, the total design moment $M_{o}$ shall be distributed in the following proportions:
Interior negative design moment:

$$
0.75-\frac{0.10}{1+\frac{1}{\alpha_{c}}}
$$

Positive design moment:

$$
0.63-\frac{0.28}{1+\frac{1}{\alpha_{c}}}
$$

Exterior negative design moment:

$$
\frac{0.65}{1+\frac{1}{\alpha_{c}}}
$$

$\alpha_{c}$ is the ratio of flexural stiffness of the exterior columns to the flexural stiffness of the slab at a joint taken in the direction moments are being determined and is given by

$$
\alpha_{c}=\frac{\Sigma K_{c}}{K_{s}}
$$

where
$K_{s}=$ sum of the flexural stiffness of the columns meeting at the joint; and
$K_{s}=$ flexural stiffness of the slab, expressed as moment per unit rotation.
31.4.3.4 It shall be permissible to modify these design moments by up to 10 percent, so long as the total design moment, $M_{o}$ for the panel in the direction considered is not less than that required by 31.4.2.2.
31.4.3.5 The negative moment section shall be designed to resist the larger of the two interior negative design moments determined for the spans framing into a common support unless an analysis is made to distribute the unbalanced moment in accordance with the stiffness of the adjoining parts.

### 31.4.4 Distribution of Bending Moments Across the Panel Width

Bending moments at critical cross-section shall be distributed to the column strips and middle strips as specified in 31.5 .5 as applicable.

### 31.4.5 Moments in Columns

31.4.5.1 Columns built integrally with the slab system shall be designed to resist moments arising from loads on the slab system.
31.4.5.2 At an interior support, the supporting members above and below the slab shall be designed to resist the moment $M$ given by the following equation, in direct proportion to their stiffnesses unless a general analysis is made:

$$
M=0.08 \frac{\left(w_{d}+0.5 w_{1}\right) l_{2} l_{2}^{2}-w_{d}^{\prime} l_{2}^{\prime} l_{2}^{\prime 2}}{1+\frac{1}{\alpha_{c}}}
$$

where
$w_{d}, w_{1}=$ design dead and live loads respectively, per unit area;
$l_{2} \quad=$ length of span transverse to the direction of $M$;

$l_{n}=$ length of the clear span in the direction of $M$, measured face to face of supports;
$\alpha_{c}=\frac{\sum K_{c}}{\sum K_{s}}$ where $K_{c}$ and $K_{s}$ are as defined in 31.4.3.3; and
$w_{d}^{\prime}, l_{s}^{\prime}$ and $l_{s}^{\prime}$, refer to the shorter span.

### 31.4.6 Effects of Pattern Loading

In the direct design method, when the ratio of live load to dead load exceeds 0.5 :
a) the sum of the flexural stiffnesses of the columns above and below the slab, $\Sigma K_{c}$, shall be such that $\alpha_{c}$ is not less than the appropriate minimum value $\alpha_{c \text { min }}$ specified in Table 17, or
b) if the sum of the flexural stiffnesses of the columns, $\Sigma K_{c}$, does not satisfy (a), the positive design moments for the panel shall be multiplied by the coefficient $\beta_{s}$ given by the following equation:

$$
\beta_{s}=1+\left(\frac{2-\frac{w_{d}}{w_{1}}}{4+\frac{w_{d}}{w_{1}}}\right)\left(1-\frac{\alpha_{c}}{\alpha_{c \min }}\right)
$$

$\alpha_{c}$ is the ratio of flexural stiffness of the columns above and below the slab to the flexural stiffness of the slabs at a joint taken in the direction moments are being determined and is given by:

$$
\alpha_{c}=\frac{\sum K_{c}}{\sum K_{s}}
$$

where $K_{c}$ and $K_{s}$ are flexural stiffnesses of column and slab respectively.

### 31.5 Equivalent Frame Method

### 31.5.1 Assumptions

The bending moments and shear forces may be determined by an analysis of the structure as a continuous frame and the following assumptions may be made:
a) The structure shall be considered to be made up of equivalent frames on column lines taken longitudinally and transversely through the building. Each frame consists of a row of equivalent columns or supports, bounded laterally by the centre-line of the panel on each side of the centre-line of the columns or supports. Frames adjacent and parallel to an edge shall be bounded by the edge and the centreline of the adjacent panel.
b) Each such frame may be analyzed in its entirety, or, for vertical loading, each floor thereof and the roof may be analyzed separately with its columns being assumed fixed at their remote ends. Where slabs are thus analyzed separately, it may be assumed in determining the bending moment at a given support that the slab is fixed at any support two panels distant therefrom provided the slab continues beyond the point.
c) For the purpose of determining relative stiffness of members, the moment of inertia of any slab or column may be assumed to be that of the gross cross-section of the concrete alone.
d) Variations of moment of inertia along the axis of the slab on account of provision of drops shall be taken into account. In the case of recessed or coffered slab which is made solid in the region of the columns, the stiffening effect may be ignored provided the solid part of the slab does not extend more than $0.15 l_{c}$, into the span measured from the centre-line of the columns. The stiffening effect of flared column heads may be ignored.

### 31.5.2 Loading Pattern

31.5.2.1 When the loading pattern is known, the structure shall be analyzed for the load concerned.

Table 17 Minimum Permissible Values of $\alpha_{c}$
(Clause 31.4.6)

| Imposed Load/Dead Load | Ratio $\frac{l_{s}}{l_{i}}$ | Value of $\alpha_{c}$ min |
| :--: | :--: | :--: |
| (1) | (2) | (3) |
| 0.5 | 0.5 to 2.0 | 0 |
| 1.0 | 0.5 | 0.6 |
| 1.0 | 0.8 | 0.7 |
| 1.0 | 1.0 | 0.7 |
| 1.0 | 1.25 | 0.8 |
| 1.0 | 2.0 | 1.2 |
| 2.0 | 0.5 | 1.3 |
| 2.0 | 0.8 | 1.5 |
| 2.0 | 1.0 | 1.6 |
| 2.0 | 1.25 | 1.9 |
| 2.0 | 2.0 | 4.9 |
| 3.0 | 0.5 | 1.8 |
| 3.0 | 0.8 | 2.0 |
| 3.0 | 1.0 | 2.3 |
| 3.0 | 1.25 | 2.8 |
| 3.0 | 2.0 | 13.0 |

31.5.2.2 When the live load is variable but does not exceed three-quarters of the dead load, or the nature of the live load is such that all panels will be loaded simultaneously, the maximum moments may be assumed to occur at all sections when full design live load is on the entire slab system.

31.5.2.3 For other conditions of live load/dead load ratio and when all panels are not loaded simultaneously:
a) maximum positive moment near midspan of a panel may be assumed to occur when threequarters of the full design live load is on the panel and on alternate panels; and
b) maximum negative moment in the slab at a support may be assumed to occur when threequarters of the full design live load is on the adjacent panels only.
31.5.2.4 In no case shall design moments be taken to be less than those occurring with full design live load on all panels.

### 31.5.3 Negative Design Moment

31.5.3.1 At interior supports, the critical section for negative moment, in both the column strip and middle strip, shall be taken at the face of rectilinear supports, but in no case at a distance greater than $0.175 l_{1}$ from the centre of the column where $l_{1}$ is the length of the span in the direction moments are being determined, measured centre-to-centre of supports.
31.5.3.2 At exterior supports provided with brackets or capitals, the critical section for negative moment in the direction perpendicular to the edge shall be taken at a distance from the face of the supporting element not greater than one-half the projection of the bracket or capital beyond the face of the supporting element.
31.5.3.3 Circular or regular polygon shaped supports shall be treated as square supports having the same area.

### 31.5.4 Modification of Maximum Moment

Moments determined by means of the equivalent frame method, for slabs which fulfil the limitations of 31.4 may be reduced in such proportion that the numerical sum of the positive and average negative moments is not less than the value of total design moment $M_{n}$ specified in 31.4.2.2.
31.5.5 Distribution of Bending Moment Across the Panel Width
31.5.5.1 Column strip : Negative moment at an interior support
At an interior support, the column strip shall be designed to resist 75 percent of the total negative moment in the panel at that support.
31.5.5.2 Column strip : Negative moment at an exterior support
a) At an exterior support, the column strip shall be designed to resist the total negative moment in the panel at that support.
b) Where the exterior support consists of a column or a wall extending for a distance equal to or
greater than three-quarters of the value of $l_{2}$, the length of span transverse to the direction moments are being determined, the exterior negative moment shall be considered to be uniformly distributed across the length $l_{2}$.
31.5.5.3 Column strip : Positive moment for each span

For each span, the column strip shall be designed to resist 60 percent of the total positive moment in the panel.

### 31.5.5.4 Moments in the middle strip

The middle strip shall be designed on the following bases:
a) That portion of the design moment not resisted by the column strip shall be assigned to the adjacent middle strips.
b) Each middle strip shall be proportioned to resist the sum of the moments assigned to its two half middle strips.
c) The middle strip adjacent and parallel to an edge supported by a wall shall be proportioned to resist twice the moment assigned to half the middle strip corresponding to the first row of interior columns.

### 31.6 Shear in Flat Slab

31.6.1 The critical section for shear shall be at a distance $d / 2$ from the periphery of the column/capital/ drop panel, perpendicular to the plane of the slab where $d$ is the effective depth of the section (see Fig. 12). The shape in plan is geometrically similar to the support immediately below the slab (see Fig. 13A and 13B).

NOTE-For column sections with re-entrant angles, the critical section shall be taken as indicated in Fig. 13C and 13D.
31.6.1.1 In the case of columns near the free edge of a slab, the critical section shall be taken as shown in Fig. 14.
31.6.1.2 When openings in flat slabs are located at a distance less than ten times the thickness of the slab from a concentrated reaction or when the openings are located within the column strips, the critical sections specified in 31.6 .1 shall be modified so that the part of the periphery of the critical section which is enclosed by radial projections of the openings to the centroid of the reaction area shall be considered ineffective (see Fig. 15), and openings shall not encroach upon column head.

### 31.6.2 Calculation of Shear Stress

The shear stress $\tau_{y}$ shall be the sum of the values calculated according to 31.6.2.1 and 31.6.2.2.
31.6.2.1 The nominal shear stress in flat slabs shall be taken as $V / b_{o} d$ where $V$ is the shear force due to design load, $b_{o}$ is the periphery of the critical section and $d$ is the effective depth.

![chunk-0-img-6.jpeg](chunk-0-img-6.jpeg)

NOTE $-d$ is the effective depth of the flat slab/drop.
Fig. 13 Critical Sections in Plan for Shear in Flat Slabs
![chunk-0-img-7.jpeg](chunk-0-img-7.jpeg)

14 A
![chunk-0-img-8.jpeg](chunk-0-img-8.jpeg)

Fig. 14 Eppict of Free Edges on Critical Section for Shear
31.6.2.2 When unbalanced gravity load, wind, earthquake or other forces cause transfer of bending moment between slab and column, a fraction ( $1-\alpha$ ) of the moment shall be considered transferred by eccentricity of the shear about the centroid of the critical section. Shear stresses shall be taken as varying linearly about the centroid of the critical section. The
value of $\alpha$ shall be obtained from the equation given in 31.3.3.

### 31.6.3 Permissible Shear Stress

31.6.3.1 When shear reinforcement is not provided, the calculated shear stress at the critical section shall not exceed $k_{s} \tau_{c}$.

![chunk-0-img-9.jpeg](chunk-0-img-9.jpeg)

Fig. 15 EFFECT of OPENINGS on Critical. SECTION POR SHEAR
where
$k_{\mathrm{s}}=\left(0.5+\beta_{\mathrm{s}}\right)$ but not greater than $1, \beta_{\mathrm{s}}$ being the ratio of short side to long side of the column/ capital; and
$\tau_{\mathrm{c}}=0.25 \sqrt{f_{\mathrm{ck}}}$ in limit state method of design, and $0.16 \sqrt{f_{\mathrm{ck}}}$ in working stress method of design.
31.6.3.2 When the shear stress at the critical section exceeds the value given in 31.6.3.1, but less than $1.5 \tau_{\mathrm{c}}$ shear reinforcement shall be provided. If the shear stress exceeds $1.5 \tau_{\mathrm{c}}$, the flat slab shall be redesigned. Shear stresses shall be investigated at successive sections more distant from the support and shear reinforcement shall be provided up to a section where the shear stress does not exceed $0.5 \tau_{\mathrm{c}}$. While designing the shear reinforcement, the shear stress carried by the concrete shall be assumed to be $0.5 \tau_{\mathrm{c}}$ and reinforcement shall carry the remaining shear.

### 31.7 Slab Reinforcement

### 31.7.1 Spacing

The spacing of bars in a flat slab, shall not exceed

2 times the slab thickness, except where a slab is of cellular or ribbed construction.

### 31.7.2 Area of Reinforcement

When drop panels are used, the thickness of drop panel for determination of area of reinforcement shall be the lesser of the following:
a) Thickness of drop, and
b) Thickness of slab plus one quarter the distance between edge of drop and edge of capital.

### 31.7.3 Minimum Length of Reinforcement

a) Reinforcement in flat slabs shall have the minimum lengths specified in Fig.16. Larger lengths of reinforcement shall be provided when required by analysis.
b) Where adjacent spans are unequal, the extension of negative reinforcement beyond each face of the common column shall be based on the longer span.
c) The length of reinforcement for slabs in frames not braced against sideways and for slabs resisting lateral loads shall be determined by analysis but shall not be less than those prescribed in Fig. 16.



