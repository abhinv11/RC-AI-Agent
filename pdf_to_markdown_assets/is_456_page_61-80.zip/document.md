![chunk-0-img-0.jpeg](chunk-0-img-0.jpeg)
![chunk-0-img-1.jpeg](chunk-0-img-1.jpeg)

* Bent bars at exterior supports may be used if a general analysis is made.
NOTE - $D$ is the diameter of the column and the dimension of the rectangular column in the direction under consideration.

Fig. 16 Minimum Bend Joint Locations and Extensions for Reinforcement in Plat Slabs

### 31.7.4 Anchoring Reinforcement

a) All slab reinforcement perpendicular to a discontinuous edge shall have an anchorage (straight, bent or otherwise anchored) past the internal face of the spandrel beam, wall or column, of an amount:

1) For positive reinforcement - not less than 150 mm except that with fabric reinforcement having a fully welded transverse wire directly over the support, it shall be permissible to reduce this length to one-half of the width of the support or 50 mm , whichever is greater; and
2) For negative reinforcement - such that the design stress is developed at the internal face, in accordance with Section 3,
b) Where the slab is not supported by a spandrel beam or wall, or where the slab cantilevers beyond the support, the anchorage shall be obtained within the slab.

### 31.8 Openings in Flat Slabs

Openings of any size may be provided in the flat slab if it is shown by analysis that the requirements of strength and serviceability are met. However, for openings conforming to the following, no special analysis is required.
a) Openings of any size may be placed within the middle half of the span in each direction, provided the total amount of reinforcement required for the panel without the opening is maintained.
b) In the area common to two column strips, not more than one-eighth of the width of strip in either span shall be interrupted by the openings. The equivalent of reinforcement interrupted shall be added on all sides of the openings.
c) In the area common to one column strip and one middle strip, not more than one-quarter of the reinforcement in either strip shall be interrupted by the openings. The equivalent of reinforcement interrupted shall be added on all sides of the openings.
d) The shear requirements of 31.6 shall be satisfied.

## 32 WALLS

### 32.1 General

Reinforced concrete walls subjected to direct compression or combined flexure and direct compression should be designed in accordance with Section 5 or Annex B provided the vertical reinforcement is provided in each face. Braced walls subjected to only vertical compression may be designed
as per empirical procedure given in 32.2 . The minimum thickness of walls shall be 100 mm .
32.1.1 Guidelines or design of walls subjected to horizontal and vertical loads are given in 32.3.

### 32.2 Empirical Design Method for Walls Subjected to Inplane Vertical Loads

### 32.2.1 Braced Walls

Walls shall be assumed to be braced if they are laterally supported by a structure in which all the following apply:
a) Walls or vertical braced elements are arranged in two directions so as to provide lateral stability to the structure as a whole.
b) Lateral forces are resisted by shear in the planes of these walls or by braced elements.
c) Floor and roof systems are designed to transfer lateral forces.
d) Connections between the wall and the lateral supports are designed to resist a horizontal force not less than

1) the simple static reactions to the total applied horizontal forces at the level of lateral support; and
2) 2.5 percent of the total vertical load that the wall is designed to carry at the level of lateral support.

### 32.2.2 Eccentricity of Vertical Load

The design of a wall shall take account of the actual eccentricity of the vertical force subject to a minimum value of 0.05 t .
The vertical load transmitted to a wall by a discontinuous concrete floor or roof shall be assumed to act at one-third the depth of the bearing area measured from the span face of the wall. Where there is an in-situ concrete floor continuous over the wall, the load shall be assumed to act at the centre of the wall.
The resultant eccentricity of the total vertical load on a braced wall at any level between horizontal lateral supports, shall be calculated on the assumption that the resultant eccentricity of all the vertical loads above the upper support is zero.

### 32.2.3 Maximum Effective Height to Thickness Ratio

The ratio of effective height to thickness, $H_{\mathrm{es}} / t$ shall not exceed 30.

### 32.2.4 Effective Height

The effective height of a braced wall shall be taken as follows:
a) Where restrained against rotation at both ends by

1) floors
$0.75 H_{w}$ or
2) intersecting walls or
$0.75 L_{1}$ similar members
whichever is the lesser.
b) Where not restrained against rotation at both ends by
3) floors
$1.0 H_{w}$ or
4) intersecting walls or
$1.0 L_{1}$ similar members
whichever is the lesser.
where
$H_{w}=$ the unsupported height of the wall.
$L_{1}=$ the horizontal distance between centres of lateral restraint.

### 32.2.5 Design Axial Strength of Wall

The design axial strength $P_{\text {ow }}$ per unit length of a braced wall in compression may be calculated from the following equation:

$$
P_{\mathrm{ow}}=0.3\left(t-1.2 e-2 e_{\mathrm{a}}\right) f_{\mathrm{ck}}
$$

where
$t=$ thickness of the wall,
$e=$ eccentricity of load measured at right angles to the plane of the wall determined in accordance with 32.2.2, and
$e_{\mathrm{a}}=$ additional eccentricity due to slenderness effect taken as $H_{\mathrm{we}} / 2500 t$.

### 32.3 Walls Subjected to Combined Horizontal and Vertical Forces

32.3.1 When horizontal forces are in the plane of the wall, it may be designed for vertical forces in accordance with 32.2 and for horizontal shear in accordance with 32.3. In plane bending may be neglected in case a horizontal cross-section of the wall is always under compression due to combined effect of horizontal and vertical loads.
32.3.2 Walls subjected to horizontal forces perpendicular to the wall and for which the design axial load does not exceed $0.04 f_{\mathrm{ck}} A_{g}$, shall be designed as slabs in accordance with the appropriate provisions under 24 , where $A_{g}$ is gross area of the section.

### 32.4 Design for Horizontal Shear

### 32.4.1 Critical Section for Shear

The critical section for maximum shear shall be taken at a distance from the base of $0.5 L_{w}$ or $0.5 H_{w}$ whichever is less.

### 32.4.2 Nominal Shear Stress

The nominal shear stress $\tau_{c w}$ in walls shall be obtained as follows:

$$
\tau_{c w}=V_{u} / t . d
$$

where

$$
\begin{aligned}
V_{u} & =\text { shear force due to design loads. } \\
t & =\text { wall thickness. } \\
d & =0.8 \times L_{w} \text { where } L_{w} \text { is the length of } \\
& \text { the wall. }
\end{aligned}
$$

32.4.2.1 Under no circumstances shall the nominal shear stress $\tau_{c w}$ in walls exceed $0.17 f_{\mathrm{ck}}$ in limit state method and $0.12 f_{\mathrm{ck}}$ in working stress method.

### 32.4.3 Design Shear Strength of Concrete

The design shear strength of concrete in walls, $\tau_{c w}$, without shear reinforcement shall be taken as below:
a) For $H_{w} / L_{w} \leq 1$

$$
\tau_{c w}=\left(3.0-H_{w} / L_{w}\right) K_{1} \sqrt{f_{c k}}
$$

where $K_{1}$ is 0.2 in limit state method and 0.13 in working stress method.
b) For $H_{w} / L_{w}>1$

Lesser of the values calculated from (a) above and from

$$
\tau_{c w}=K_{2} \sqrt{f_{c k}} \frac{\left(H_{w} / L_{w}+1\right)}{\left(H_{w} / L_{w}-1\right)}
$$

where $K_{2}$ is 0.045 in limit state method and 0.03 in working stress method, but shall be not less than $K_{2} \sqrt{f_{c k}}$ in any case, where $K_{3}$ is 0.15 in limit state method and 0,10 in working stress method.

### 32.4.4. Design of Shear Reinforcement

Shear reinforcement shall be provided to carry a shear equal to $V_{u}-\tau_{c w} t\left(0.8 L_{w}\right)$. In case of working stress method $V_{u}$ is replaced by $V$. The strength of shear reinforcement shall be calculated as per 40.4 or B-5.4 with $A_{g v}$ defined as below:

$$
A_{g v}=P_{w}\left(0.8 L_{w}\right) t
$$

where $P_{w}$ is determined as follows:
a) For walls where $H_{w} / L_{w} \leq 1, P_{w}$ shall be the lesser of the ratios of either the vertical reinforcement area or the horizontal reinforcement area to the cross-sectional area of wall in the respective direction.
b) For walls where $H_{w} / L_{w}>1, P_{w}$ shall be the ratio of the horizontal reinforcement area to the cross-sectional area of wall per vertical metre.

### 32.5 Minimum Requirements for Reinforcement in Walls

The reinforcement for.walls shall be provided as below:

a) the minimum ratio of vertical reinforcement to gross concrete area shall be:

1) 0.0012 for deformed bars not larger than 16 mm in diameter and with a characteristic strength of $415 \mathrm{~N} / \mathrm{mm}^{2}$ or greater.
2) 0.0015 for other types of bars.
3) 0.0012 for welded wire fabric not larger than 16 mm in diameter.
b) Vertical reinforcement shall be spaced not farther apart than three times the wall thickness nor 450 mm .
c) The minimum ratio of horizontal reinforcement to gross concrete area shall be:
4) 0.0020 for deformed bars not larger than 16 mm in diameter and with a characteristic strength of $415 \mathrm{~N} / \mathrm{mm}^{2}$ or greater.
5) 0.0025 for other types of bars.
6) 0.0020 for welded wire fabric not larger than 16 mm in diameter.
d) Horizontal reinforcement shall be spaced not farther apart than three times the wall thickness nor 450 mm .

NOTE - The minimum reinforcement may not always be sufficient to provide adequate resistance to the effects of shrinkage and temperature.
32.5.1 For walls having thickness more than 200 mm , the vertical and horizontal reinforcement shall be provided in two grids, one near each face of the wall.
32.5.2 Vertical reinforcement need not be enclosed by transverse reinforcement as given in 26.5.3.2 for column, if the vertical reinforcement is not greater than 0.01 times the gross sectional area or where the vertical reinforcement is not required for compression.

## 33 STAIRS

### 33.1 Effective Span of Stairs

The effective span of stairs without stringer beams shall
be taken as the following horizontal distances:
a) Where supported at top and bottom risers by beams spanning parallel with the risers, the distance centre-to-centre of beams;
b) Where spanning on to the edge of a landing slab, which spans parallel, with the risers (see Fig. 17), a distance equal to the going of the stairs plus at each end either half the width of the landing or one metre, whichever is smaller; and
c) Where the landing slab spans in the same direction as the stairs, they shall be considered as acting together to form a single slab and the span determined as the distance centre-to-centre of the supporting beams or walls, the going being measured horizontally.

### 33.2 Distribution of Loading on Stairs

In the case of stairs with open wells, where spans partly crossing at right angles occur, the load on areas common to any two such spans may be taken as onehalf in each direction as shown in Fig. 18. Where flights or landings are embedded into walls for a length of not less than 110 mm and are designed to span in the direction of the flight, a 150 mm strip may be deducted from the loaded area and the effective breadth of the section increased by 75 mm for purposes of design (see Fig. 19).

### 33.3 Depth of Section

The depth of section shall be taken as the minimum thickness perpendicular to the soffit of the staircase.

## 34 FOOTINGS

### 34.1 General

Footings shall be designed to sustain the applied loads, moments and forces and the induced reactions and to ensure that any settlement which may occur shall be as nearly uniform as possible, and the safe bearing capacity of the soil is not exceeded (see IS 1904).
34.1.1 In sloped or stepped footings the effective
![chunk-0-img-2.jpeg](chunk-0-img-2.jpeg)

| $x$ | $Y$ | SPAN IN METRES |
| :--: | :--: | :--: |
| $<1 m$ | $<1 m$ | $0 \cdot X \cdot Y$ |
| $<1 m$ | $>1 m$ | $0 \cdot X \cdot 1$ |
| $>1 m$ | $<1 m$ | $0 \cdot Y \cdot 1$ |
| $>1 m$ | $>1 m$ | $0 \cdot 1 \cdot 1$ |

Fig. 17 Effective Span for Stairs Supported at Each End by
Landings Spanning Parallel with the Risers

![chunk-0-img-3.jpeg](chunk-0-img-3.jpeg)

Fig. 18 Loading on Stairs with Open Wells

Fig. 19 Loading on Stairs Built into Walls
cross-section in compression shall be limited by the area above the neutral plane, and the angle of slope or depth and location of steps shall be such that the design requirements are satisfied at every section. Sloped and stepped footings that are designed as a unit shall be constructed to assure action as a unit.

### 34.1.2 Thickness at the Edge of Footing

In reinforced and plain concrete footings, the thicknėss ${ }^{1}$ at the edge shall be not less than 150 mm for footings on soils, nor less than 300 mm above the tops of piles for footings on piles.
34.1.3 In the case of plain concrete pedestals, the angle ${ }^{(i)}$ between the plane passing through the bottom edge of the pedestal and the corresponding junction edge of the column with pedestal and the horizontal plane (see Fig. 20) shall be governed by the expression:

$$
\tan \alpha \leq 0.9 \sqrt{\frac{100 q_{0}}{f_{i k}}+1}
$$

where
$q_{0}=$ calculated maximum bearing pressure at the base of the pedestal in $\mathrm{N} / \mathrm{mm}^{2}$, and
$f_{i k}=$ characteristic strength of concrete at 28 days in $\mathrm{N} / \mathrm{mm}^{2}$.

### 34.2 Moments and Forces ${ }^{\text {till }}$

34.2.1 In the case of footings on piles, computation for moments and shears may be based on the assumption that the reaction from any pile is ${ }_{0}^{0}$ concentrated at the centre of the pile.
34.2.2 For the purpose of computing stresses in footings which support a round or octagonal concrete column or pedestal, the face of the column or pedestal shall be taken as the side of a square inscribed within the perimeter of the round or octagonal column or pedestal.

### 34.2.3 Bending Moment

34.2.3.1 The bending moment at any section shall be determined by passing through the section a vertical
![chunk-0-img-4.jpeg](chunk-0-img-4.jpeg)

Fig. 20

plane which extends completely across the footing, and computing the moment of the forces acting over the entire area of the footing on one side of the said plane.
34.2.3.2 The greatest bending moment to be used in the design of an isolated concrete footing which supports a column, pedestal or wall; shall be the moment computed in the manner prescribed in 34.2.3.1 at sections located as follows:
a) At the face of the column, pedestal or wall, for footings supporting a concrete column, pedestal or wall;
b) Halfway between the centre-line and the edge of the wall, for footings under masonry walls; and
c) Halfway between the face of the column or pedestal and the edge of the gussetted base, for footings under gussetted bases.

### 34.2.4 Shear and Bond

34.2.4.1 The shear strength of footings is governed by the more severe of the following two conditions:
a) The footing acting essentially as a wide beam, with a potential diagonal crack extending in a plane across the entire width; the critical section for this condition shall be assumed as a vertical section located from the face of the column, pedestal or wall at a distance equal to the effective depth of footing for footings on piles.
b) Two-way action of the footing, with potential diagonal cracking along the surface of truncated cone or pyramid around the concentrated load; in this case, the footing shall be designed for shear in accordance with appropriate provisions specified in 31.6 .
34.2.4.2 In computing the external shear or any section through a footing supported on piles, the entire reaction from any pile of diameter $D_{p}$ whose centre is located $D_{p} / 2$ or more outside the section shall be assumed as producing shear on the section; the reaction from any pile whose centre is located $D_{p} / 2$ or more inside the section shall be assumed as producing no shear on the section. For intermediate positions of the pile centre, the portion of the pile reaction to be assumed as producing shear on the section shall be based on straight line interpolation between full value at $D_{p} / 2$ outside the section and zero value at $D_{p} / 2$ inside the section.
34.2.4.3 The critical section for checking the development length in a footing shall be assumed at the same planes as those described for bending moment in 34.2 .3 and also at all other vertical planes where abrupt changes of section occur. If reinforcement is curtailed, the anchorage requirements shall be checked in accordance with 26.2.3.

### 34.3 Tensile Reinforcement

The total tensile reinforcement at any section shall provide a moment of resistance at least equal to the bending moment on the section calculated in accordance with 34.2.3.
34.3.1 Total tensile reinforcement shall be distributed across the corresponding resisting section as given below:
a) In one-way reinforced footing, the reinforcement extending in each direction shall be distributed uniformly across the full width of the footing;
b) In two-way reinforced square footing, the reinforcement extending in each direction shall be distributed uniformly across the full width of the footing; and
c) In two-way reinforced rectangular footing, the reinforcement in the long direction shall be distributed uniformly across the full width of the footing. For reinforcement in the short direction, a central band equal to the width of the footing shall be marked along the length of the footing and portion of the reinforcement determined in accordance with the equation given below shall be uniformly distributed across the central band:
$\frac{\text { Reinforcement in central band width }}{\text { Total reinforcement in short direction }}=\frac{2}{\beta+1}$
where $\beta$ is the ratio of the long side to the short side of the footing. The remainder of the reinforcement shall be uniformly distributed in the outer portions of the footing.

### 34.4 Transfer of Load at the Base of Column

The compressive stress in concrete at the base of a column or pedestal shall be considered as being transferred by bearing to the top of the supporting pedestal or footing. The bearing pressure on the loaded area shall not exceed the permissible bearing stress in direct compression multiplied by a value equal to
$\sqrt{\frac{A_{1}}{A_{2}}}$ but not greater than 2 ;
where
$A_{1}=$ supporting area for bearing of footing, which in sloped or stepped footing may be taken as the area of the lower base of the largest frustum of a pyramid or cone contained wholly within the footing and having for its upper base, the area actually loaded and having side slope of one vertical to two horizontal; and
$A_{2}=$ loaded area at the column base.

For working stress method of design the permissible bearing stress on full area of concrete shall be taken as $0.25 f_{c k}$; for limit state method of design the permissible bearing stress shall be $0.45 f_{c k}$.
34.4.1 Where the permissible bearing stress on the concrete in the supporting or supported member would be exceeded, reinforcement shall be provided for developing the excess force, either by extending the longitudinal bars into the supporting member, or by dowels (see 34.4.3).
34.4.2 Where transfer of force is accomplished by reinforcement, the development length of the reinforcement shall be sufficient to transfer the compression or tension to the supporting member in accordance with 26.2.
34.4.3 Extended longitudinal reinforcement or dowels of at least 0.5 percent of the cross-sectional area of the supported column or pedestal and a minimum of four bars shall be provided. Where dowels are used, their
diameter shall no exceed the diameter of the column bars by more than 3 mm .
34.4.4 Column bars of diameters larger than 36 mm , in compression only can be dowelled at the footings with bars of smaller size of the necessary area. The dowel shall extend into the column, a distance equal to the development length of the column bar and into the footing, a distance equal to the development length of the dowel.

### 34.5 Nominal Reinforcement

34.5.1 Minimum reinforcement and spacing shall be as per the requirements of solid slab.
34.5.2 The nominal reinforcement for concrete sections of thickness greater than 1 m shall be $360 \mathrm{~mm}^{2}$ per metre length in each direction on each face. This provision does not supersede the requirement of minimum tensile reinforcement based on the depth of the section.

# SECTION 5 STRUCTURAL DESIGN (LIMIT STATE METHOD) 

## 35 SAFETY AND SERVICEABILITY REQUIREMENTS

### 35.1 General

In the method of design based on limit state concept, the structure shall be designed to withstand safely all loads liable to act on it throughout its life; it shall also satisfy the serviceability requirements, such as limitations on deflection and cracking. The acceptable limit for the safety and serviceability requirements before failure occurs is called a 'limit state'. The aim of design is to achieve acceptable probabilities that the structure will not become unfit for the use for which it is intended, that is, that it will not reach a limit state.
35.1.1 All relevant limit states shall be considered in design to ensure an adequate degree of safety and serviceability. In general, the structure shall be designed on the basis of the most critical limit state and shall be checked for other limit states.
35.1.2 For ensuring the above objective, the design should be based on characteristic values for material strengths and applied loads, which take into account the variations in the material strengths and in the loads to be supported. The characteristic values should be based on statistical data if available; where such data are not available they should be based on experience. The 'design values' are derived from the characteristic values through the use of partial safety factors, one for material strengths and the other for loads. In the absence of special considerations these factors should have the values given in 36 according to the material, the type of loading and the limit state being considered.

### 35.2 Limit State of Collapse

The limit state of collapse of the structure or part of the structure could be assessed from rupture of one or more critical sections and from buckling due to elastic or plastic instability (including the effects of sway where appropriate) or overturning. The resistance to bending, shear, torsion and axial loads at every section shall not be less than the appropriate value at that section produced by the probable most unfavourable combination of loads on the structure using the appropriate partial safety factors.

### 35.3 Limit States of Serviceability

### 35.3.1 Deflection

Limiting values of deflections are given in 23.2.

### 35.3.2 Cracking

Cracking of concrete should not adversely affect the appearance or durability of the structure; the acceptable
limits of cracking would vary with the type of structure and environment. Where specific attention is required to limit the designed crack width to a particular value, crack width calculation may be done using formula given in Annex F.
The practical objective of calculating crack width is merely to give guidance to the designer in making appropriate structural arrangements and in avoiding gross errors in design, which might result in concentration and excessive width of flexural crack.
The surface width of the cracks should not, in general, exceed 0.3 mm in members where cracking is not harmful and does not have any serious adverse effects upon the preservation of reinforcing steel nor upon the durability of the structures. In members where cracking in the tensile zone is harmful either because they are exposed to the effects of the weather or continuously exposed to moisture or in contact soil or ground water, an upper limit of 0.2 mm is suggested for the maximum width of cracks. For particularly aggressive environment, such as the 'severe' category in Table 3, the assessed surface width of cracks should not in general, exceed 0.1 mm .

### 35.4 Other Limit States

Structures designed for unusual or special functions shall comply with any relevant additional limit state considered appropriate to that structure.

## 36 CHARACTERISTIC AND DESIGN VALUES AND PARTIAL SAFETY FACTORS

### 36.1 Characteristic Strength of Materials

The term 'characteristic strength' means that value of the strength of the material below which not more than 5 percent of the test results are expected to fall. The characteristic strength for concrete shall be in accordance with Table 2. Until the relevant Indian Standard Specifications for reinforcing steel are modified to include the concept of characteristic strength, the characteristic value shall be assumed as the minimum yield stress $/ 0.2$ percent proof stress specified in the relevant Indian Standard Specifications.

### 36.2 Characteristic Loads

The term 'characteristic load' means that value of load which has a 95 percent probability of not being exceeded during the life of the structure. Since data are not available to express loads in statistical terms, for the purpose of this standard, dead loads given in IS 875 (Part 1), imposed loads given in IS 875 (Part 2), wind loads given in IS 875 (Part 3), snow load as given in IS 875 (Part 4) and seismic forces given in IS 1893 shall be assumed as the characteristic loads.

### 36.3 Design Values

### 36.3.1 Materials

The design strength of the materials, $f_{\mathrm{d}}$ is given by

$$
f_{\mathrm{d}}=\frac{f}{\gamma_{\mathrm{m}}}
$$

where
$f=$ characteristic strength of the material (see 36.1), and
$\gamma_{\mathrm{m}}=$ partial safety factor appropriate to the material and the limit state being considered.

### 36.3.2 Loads

The design load, $F_{\mathrm{d}}$ is given by

$$
F_{\mathrm{d}}=F \gamma_{\mathrm{f}}
$$

where
$F=$ characteristic load (see 36.2), and
$\gamma_{\mathrm{f}}=$ partial safety factor appropriate to the nature of loading and the limit state being considered.

### 36.3.3 Consequences of Attaining Limit State

Where the consequences of a structure attaining a limit state are of a serious nature such as huge loss of life and disruption of the economy, higher values for $\gamma_{\mathrm{f}}$ and $\gamma_{\mathrm{m}}$ than those given under 36.4 .1 and 36.4 .2 may be applied.

### 36.4 Partial Safety Factors

### 36.4.1 Partial Safety Factor $\gamma_{\mathrm{f}}$ for Loads

The values of $\gamma_{\mathrm{f}}$ given in Table 18 shall normally be used.

### 36.4.2 Partial Safety Factor $\gamma_{\mathrm{m}}$ for Mateiral Strength

36.4.2.1 When assessing the strength of a structure or structural member for the limit state of collapse, the values of partial safety factor, $\gamma_{m}$ should be taken as 1.5 for concrete and 1.15 for steel.

NOTE $-\gamma_{m}$ values are already incorporated in the equations and tables given in this standard for limit state design.
36.4.2.2 When assessing the deflection, the material properties such as modulus of elasticity should be taken as those associated with the characteristic strength of the material.

## 37 ANALYSIS

### 37.1 Analysis of Structure

Methods of analysis as in 22 shall be used. The material strength to be assumed shall be characteristic values in the determination of elastic properties of members irrespective of the limit state being considered. Redistribution of the calculated moments may be made as given in 37.1.1.
37.1.1. Redistribution of Moments in Continuous Beams and Frames
The redistribution of moments may be carried out satisfying the following conditions:
a) Equilibirum between the interal forces and the external loads is maintained.
b) The ultimate moment of resistance provided at any section of a member is not less than 70 percent of the moment at that section obtained from an elastic maximum moment diagram covering all appropriate combinations of loads.
c) The elastic moment at any section in a member due to a particular combination of loads shall

Table 18 Values of Partial Safety Factor $\gamma_{f}$ for Loads
(Clauses 18.2.3.1, 36.4.1 and B-4.3)

| Load Combination | Limit State of Collapse |  |  |  | Limit States of Serviceability |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | DL | $I L$ | WL |  | DL | $I L$ | WL |
| (1) | (2) | (3) | (4) |  | (5) | (6) | (7) |
| $D L+I L$ | 1.5 |  | 1.0 |  | 1.0 | 1.0 | - |
| $D L+W L$ | 1.5 or | - | 1.5 |  | 1.0 | - | 1.0 |
| $D L+I L+W L$ | 0.90 |  |  |  |  |  |  |
| NOTES |  | 1.2 |  |  | 1.0 | 0.8 | 0.8 |

1 While considering earthquake effects, substitute $E L$ for $W L$.
2 For the limit states of serviceability, the values of $\gamma_{f}$ given in this table are applicable for short term effects. While assessing the long term effects due to creep the dead load and that part of the live load likely to be permanent may only be considered.
${ }^{11}$ This value is to be considered when stability against overturning or stress reversal is critical.

not be reduced by more than 30 percent of the numerically largest moment given anywhere by the elastic maximum moments diagram for the particular member, covering all appropriate combination of loads.
d) At sections where the moment capacity after redistribution is less than that from the elastic maximum moment diagram, the following relationship shall be satisfied:

$$
\frac{x_{\mathrm{u}}}{d}+\frac{\delta M}{100} \leq 0.6
$$

where
$x_{\mathrm{u}}=$ depth of neutral axis,
$d=$ effective depth, and
$\delta M=$ percentage reduction in moment.
e) In structures in which the structural frame provides the lateral stability, the reductions in moment allowed by condition 37.1 .1 (c) shall be restricted to 10 percent for structures over 4 storeys in height.
37.1.2 Analysis of Slabs Spanning in Two Directions at Right Angles

Yield line theory or any other acceptable method may be used. Alternatively the provisions given in Annex D may be followed.

## 38 LIMIT STATE OF COLLAPSE : FLEXURE

### 38.1 Assumptions

Design for the limit state of collapse in flexure shall be based on the assumptions given below:
a) Plane sections normal to the axis remain plane after bending.
![chunk-0-img-5.jpeg](chunk-0-img-5.jpeg)

Fig. 21 Stress-Strain Curve for Concrete
b) The maximum strain in concrete at the outermost compression fibre is taken as 0.0035 in bending.
c) The relationship between the compressive stress distribution in concrete and the strain in concrete may be assumed to be rectangle, trapezoid, parabola or any other shape which results in prediction of strength in substantial agreement with the results of test. An acceptable stressstrain curve is given in Fig. 21. For design purposes, the compressive strength of concrete in the structure shall be assumed to be 0.67 times the characteristic strength. The partial safety factor $\gamma_{\mathrm{m}}=1.5$ shall be applied in addition to this.
NOTE - For the stress-strain curve in Fig. 21 the design stress block parameters are as follows (see Fig. 22):

$$
\begin{aligned}
& \text { Area of stress block } \\
& =0.36 f_{\mathrm{ck}} \cdot x_{\mathrm{u}} \\
& =0.42 x_{\mathrm{u}} \\
& \text { Depth of centre of compressive force } \\
& =0.42 x_{\mathrm{u}} \\
& \text { from the extreme fibre in compression } \\
& \text { where } \\
& f_{\mathrm{ck}}=\text { characteristic compressive strength of concrete, and } \\
& x_{\mathrm{u}}=\text { depth of neutral axis. }
\end{aligned}
$$

d) The tensile strength of the concrete is ignored.
e) The stresses in the reinforcement are derived from representative stress-strain curve for the type of steel used. Typical curves are given in Fig. 23. For design purposes the partial safety factor $\gamma_{\mathrm{m}}$, equal to 1.15 shall be applied.
f) The maximum strain in the tension reinforcement in the section at failure shall not be less than:

$$
\frac{f_{\mathrm{y}}}{1.15 E_{\mathrm{s}}}+0.002
$$

where
$f_{y}=$ characteristic strength of steel, and
$E_{s}=$ modulus of elasticity of steel.
![chunk-0-img-6.jpeg](chunk-0-img-6.jpeg)

Fig. 22 Stress Block Parameters

![chunk-0-img-7.jpeg](chunk-0-img-7.jpeg)

23A Cold Worked Deformed Bar
![chunk-0-img-8.jpeg](chunk-0-img-8.jpeg)

23B Steel Bar with Definite Yield Point
Fig. 23 Represintative Stress-Strain Curves for Reinforcement

NOTE - The limiting values of the depth of neutral axis for different grades of steel based on the assumptions in 38.1 are as follows:

| $f_{y}$ | $x_{\text {o. min }} / d$ |
| :-- | :--: |
| 250 | 0.53 |
| 415 | 0.48 |
| 500 | 0.46 |

The expression for obtaining the moments of resistance for rectangular and T-Sections, based on the assumptions of 38.1, are given in Annex G.

## 39 LIMIT STATE OF COLLAPSE : COMPRESSION

### 39.1 Assumptions

In addition to the assumptions given in 38.1 (a) to
38.1 (e) for flexure, the following shall be assumed:
a) The maximum compressive strain in concrete in axial compression is taken as 0.002 .
b) The maximum compressive strain at the highly compressed extreme fibre in concrete subjected to axial compression and bending and when there is no tension on the section shall be 0.0035 minus 0.75 times the strain at the least compressed extreme fibre.

### 39.2 Minimum Eccentricity

All members in compression shall be designed for the minimum eccentricity in accordance with 25.4 . Where

calculated eccentricity is larger, the minimum eccentricity should be ignored.

### 39.3 Short Axially Loaded Members in Compression

The member shall be designed by considering the assumptions given in 39.1 and the minimum eccentricity. When the minimum eccentricity as per 25.4 does not exceed 0.05 times the lateral dimension, the members may be designed by the following equation:

$$
P_{\mathrm{u}}=0.4 f_{\mathrm{ck}} \cdot A_{\mathrm{c}}+0.67 f_{\mathrm{y}} \cdot A_{\mathrm{xc}}
$$

where

$$
\begin{aligned}
P_{\mathrm{u}}= & \text { axial load on the member, } \\
f_{\mathrm{ck}}= & \text { characteristic compressive strength of the } \\
& \text { concrete, } \\
A_{\mathrm{c}}= & \text { Area of concrete, } \\
f_{\mathrm{y}}= & \text { characteristic strength of the compression } \\
& \text { reinforcement, and } \\
A_{\mathrm{xc}}= & \text { area of longitudinal reinforcement for } \\
& \text { columns. }
\end{aligned}
$$

### 39.4 Compression Members with Helical Reinforcement

The strength of compression members with helical reinforcement satisfying the requirement of 39.4 .1 shall be taken as 1.05 times the strength of similar member with lateral ties.
39.4.1 The ratio of the volume of helical reinforcement to the volume of the core shall not be less than $0.36\left(A_{\mathrm{g}} / A_{\mathrm{c}}-1\right) f_{\mathrm{ck}} / f_{\mathrm{y}}$
where

$$
\begin{aligned}
A_{\mathrm{g}}= & \text { gross area of the section, } \\
A_{\mathrm{c}}= & \text { area of the core of the helically reinforced } \\
& \text { column measured to the outside diameter } \\
& \text { of the helix, }
\end{aligned}
$$

$f_{\mathrm{ck}}=$ characteristic compressive strength of the concrete, and
$f_{\mathrm{y}}=$ characteristic strength of the helical reinforcement but not exceeding $415 \mathrm{~N} / \mathrm{mm}^{2}$.

### 39.5 Members Subjected to Combined Axial Load and Uniaxial Bending

A member subjected to axial force and uniaxial bending shall be designed on the basis of 39.1 and 39.2 .

NOTE-The design of member subject to combined axial load and uniaxial bending will involve lengthy calculation by trial and error. In order to overcome these difficulties interaction diagrams may be used. These have been prepared and published by BIS in 'SP : 16 Design aids for reinforced concrete to IS $456^{\prime}$.

### 39.6 Members Subjected to Combined Axial Load and Biaxial Bending

The resistance of a member subjected to axial force and biaxial bending shall be obtained on the basis of assumptions given in 39.1 and 39.2 with neutral axis so chosen as to satisfy the equilibrium of load and moments about two axes. Alternatively such members may be designed by the following equation:

$$
\left[\frac{M_{\mathrm{ux}}}{M_{\mathrm{ux} 1}}\right]^{\alpha_{\mathrm{u}}}+\left[\frac{M_{\mathrm{uy}}}{M_{\mathrm{uy} 1}}\right]^{\alpha_{\mathrm{x}}} \leq 1.0
$$

where

$$
\begin{aligned}
M_{\mathrm{ux}}, M_{\mathrm{uy}}= & \text { moments about } x \text { and } y \text { axes } \\
& \text { due to design loads, } \\
M_{\mathrm{ux} 1}, M_{\mathrm{uy} 1}= & \text { maximum uniaxial moment } \\
& \text { capacity for an axial load of } P_{\mathrm{u}} \\
& \text { bending about } x \text { and } y \text { axes } \\
& \text { respectively, and } \\
& \alpha_{\mathrm{u}} \text { is related to } P_{\mathrm{u}} / P_{\mathrm{ux}}
\end{aligned}
$$

where $P_{\mathrm{ux}}=0.45 f_{\mathrm{ck}} \cdot A_{\mathrm{c}}+0.75 f_{\mathrm{y}} \cdot A_{\mathrm{xc}}$
For values of $P_{\mathrm{u}} / P_{\mathrm{ux}}=0.2$ to 0.8 , the values of $\alpha_{\mathrm{u}}$ vary linearly from 1.0 to 2.0 . For values less than $0.2, \alpha_{\mathrm{u}}$ is 1.0 ; for values greater than $0.8, \alpha_{\mathrm{u}}$ is 2.0 .

### 39.7 Slender Compression Members

The design of slender compression members (see 25.1.1) shall be based on the forces and the moments determined from an analysis of the structure, including the effect of deflections on moments and forces. When the effect of deflections are not taken into account in the analysis, additional moment given in 39.7.1 shall be taken into account in the appropriate direction.
39.7.1 The additional moments $M_{\mathrm{ux}}$ and $M_{\mathrm{uy}}$ shall be calculated by the following formulae:

$$
\begin{aligned}
& M_{\mathrm{ux}}=\frac{P_{\mathrm{u}} D}{2000}\left[\frac{l_{\mathrm{ux}}}{D}\right]^{2} \\
& M_{\mathrm{uy}}=\frac{P_{\mathrm{u}} b}{2000}\left[\frac{l_{\mathrm{uy}}}{b}\right]^{2}
\end{aligned}
$$

where

$$
\begin{aligned}
P_{\mathrm{u}}= & \text { axial load on the member, } \\
l_{\mathrm{ux}}= & \text { effective length in respect of the major } \\
& \text { axis, } \\
l_{\mathrm{uy}}= & \text { effective length in respect of the minor axis, } \\
D= & \text { depth of the cross-section at right angles } \\
& \text { to the major axis, and } \\
b= & \text { width of the member. }
\end{aligned}
$$

For design of section, 39.5 or 39.6 as appropriate shall apply.

## NOTES

1 A column may be considered braced in a given plane if lateral stability to the structure as a whole is provided by walls or bracing or buttressing designed to resist all lateral forces in that plane. It should otherwise be considered as unbraced.
2 In the case of a braced column without any transverse loads occurring in its height, the additional moment shall be added to an initial moment equal to sum of $0.4 M_{\mathrm{el}}$ and $0.6 M_{\mathrm{el}}$ where $M_{\mathrm{el}}$ is the larger end moment and $M_{\mathrm{el}}$ is the smaller end moment (assumed negative if the column is bent in double curvature). In no case shall the initial moment be less than $0.4 M_{\text {el }}$ nor the total moment including the initial moment be less than $M_{\text {el }}$. For unbraced columns, the additional moment shall be added to the end moments.
3 Unbraced compression members, at any given level or storey, subject to lateral load are usually constrained to deflect equally. In such cases slenderness ratio for each column may be taken as the average for all columns acting in the same direction.
39.7.1.1 The values given by equation 39.7 .1 may be multiplied by the following factor:

$$
k=\frac{P_{\mathrm{ic}}-P_{\mathrm{u}}}{P_{\mathrm{ic}}-P_{\mathrm{b}}} \leq 1
$$

where

$$
\begin{aligned}
& P_{\mathrm{c}}=\text { axial load on compression member, } \\
& P_{\mathrm{uc}}=\text { as defined in } 39.6, \text { and } \\
& P_{\mathrm{b}}=\text { axial load corresponding to the condition } \\
& \text { of maximum compressive strain of } \\
& 0.0035 \text { in concrete and tensile strain of } \\
& 0.002 \text { in outer most layer of tension steel. }
\end{aligned}
$$

## 40 LIMIT STATE OF COLLAPSE : SHEAR

### 40.1 Nominal Shear Stress

The nominal shear stress in beams of uniform depth shall be obtained by the following equation:

$$
\tau_{\mathrm{v}}=\frac{V_{\mathrm{u}}}{b_{\mathrm{d}}}
$$

where

$$
\begin{aligned}
V_{\mathrm{u}}= & \text { shear force due to design loads; } \\
b= & \text { breadth of the member, which for flanged } \\
& \text { section shall be taken as the breadth of } \\
& \text { the web, } b_{\mathrm{w}} \text {; and } \\
d= & \text { effective depth. }
\end{aligned}
$$

### 40.1.1 Beams of Varying Depth

In the case of beams of varying depth the equation shall be modified as:

$$
\tau_{\mathrm{v}}=\frac{V_{\mathrm{u}} \pm \frac{M_{\mathrm{u}}}{d} \tan \beta}{b d}
$$

where
$\tau_{v}, V_{u}, b$ and $d$ are the same as in 40.1 ,
$M_{\mathrm{u}}=$ bending moment at the section, and
$\beta=$ angle between the top and the bottom edges
of the beam.
The negative sign in the formula applies when the bending moment $M_{\mathrm{u}}$ increases numerically in the same direction as the effective depth $d$ increases, and the positive sign when the moment decreases numerically in this direction.

### 40.2 Design Shear Strength of Concrete

40.2.1 The design shear strength of concrete in beams without shear reinforcement is given in Table 19.
40.2.1.1 For solid slabs, the design shear strength for concrete shall be $\tau_{c} k$, where $k$ has the values given below:

| Overall Depth <br> of Slab, mm | 300 or <br> more | 275 | 250 | 225 | 200 | 175 | 150 or <br> less |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  | 1.00 | 1.05 | 1.10 | 1.15 | 1.20 | 1.25 |

NOTE- This provision shall not apply to flat slabs for which 31.6 shall apply.

### 40.2.2 Shear Strength of Members under Axial Compression

For members subjected to axial compression $P_{\mathrm{u}}$, the design shear strength of concrete, given in Table 19, shall be multiplied by the following factor :

$$
\delta=1+\frac{3 P_{\mathrm{u}}}{A_{\mathrm{g}} f_{\mathrm{ck}}} \text { but not exceeding } 1.5
$$

where

$$
\begin{aligned}
& P_{\mathrm{u}}=\text { axial compressive force in Newtons, } \\
& A_{\mathrm{g}}=\text { gross area of the concrete section in } \mathrm{mm}^{2} \text {, } \\
& f_{\mathrm{ck}}=\text { characteristic compressive strength of } \\
& \text { concrete. }
\end{aligned}
$$

### 40.2.3 With Shear Reinforcement

Under no circumstances, even with shear reinforcement, shall the nominal shear stress in beams $\tau_{\mathrm{v}}$ exceed $\tau_{\mathrm{vmax}}$ given in Table 20.
40.2.3.1 For solid slabs, the nominal shear stress shall not exceed half the appropriate values given in Table 20.

### 40.3 Minimum Shear Reinforcement

When $\tau_{\mathrm{v}}$ is less than $\tau_{\mathrm{c}}$ given in Table 19, minimum shear reinforcement shall be provided in accordance with 26.5.1.6.

### 40.4 Design of Shear Reinforcement

When $\tau_{\mathrm{v}}$ exceeds $\tau_{\mathrm{c}}$ given in Table 19, shear reinforcement shall be provided in any of the following forms:
a) Vertical stirrups,
b) Bent-up bars along with stirrups, and

Table 19 Design Shear Strength of Concrete, $\tau_{c}, \mathrm{~N} / \mathrm{mm}^{2}$
(Clauses 40.2.1, 40.2.2, 40.3, 40.4, 40.5.3, 41.3.2, 41.3.3 and 41.4.3)

| $180 \frac{A_{v}}{b d}$ | Concrete Grade |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | M 15 | M 20 | M 25 | M 30 | M 35 | M 40 and above |
| (1) | (2) | (3) | (4) | (5) | (6) | (7) |
| $\leq 0.15$ | 0.28 | 0.28 | 0.29 | 0.29 | 0.29 | 0.30 |
| 0.25 | 0.35 | 0.36 | 0.36 | 0.37 | 0.37 | 0.38 |
| 0.50 | 0.46 | 0.48 | 0.49 | 0.50 | 0.50 | 0.51 |
| 0.75 | 0.54 | 0.56 | 0.57 | 0.59 | 0.59 | 0.60 |
| 1.00 | 0.60 | 0.62 | 0.64 | 0.66 | 0.67 | 0.68 |
| 1.25 | 0.64 | 0.67 | 0.70 | 0.71 | 0.73 | 0.74 |
| 1.50 | 0.68 | 0.72 | 0.74 | 0.76 | 0.78 | 0.79 |
| 1.75 | 0.71 | 0.75 | 0.78 | 0.80 | 0.82 | 0.84 |
| 2.00 | 0.71 | 0.79 | 0.82 | 0.84 | 0.86 | 0.88 |
| 2.25 | 0.71 | 0.81 | 0.85 | 0.88 | 0.90 | 0.92 |
| 2.50 | 0.71 | 0.82 | 0.88 | 0.91 | 0.93 | 0.95 |
| 2.75 | 0.71 | 0.82 | 0.90 | 0.94 | 0.96 | 0.98 |
| 3.00 | 0.71 | 0.82 | 0.92 | 0.96 | 0.99 | 1.01 |
| and above |  |  |  |  |  |  |

NOTE - The term $A_{v}$ is the area of longitudinal tension reinforcement which continues at least one effective depth beyond the section being considered except at support where the fall area of tension reinforcement may be used provided the detailing conforms to 26.2 .2 and 26.2 .3

Table 20 Maximum Shear Stress, $\tau_{c \text { max }}, \mathrm{N} / \mathrm{mm}^{2}$ (Clauses 40.2.3, 40.2.3.1, 40.5.1 and 41.3.1)

| Concrete <br> Grade | M 15 | M 20 | M 25 | M 30 | M 35 | M 40 <br> and <br> above |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: |
| $\tau_{\mathrm{c} \text { max }}, \mathrm{N} / \mathrm{mm}^{2}$ | 2.5 | 2.8 | 3.1 | 3.5 | 3.7 | 4.0 |

c) Inclined stirrups.

Where bent-up bars are provided, their contribution towards shear resistance shall not be more than half that of the total shear reinforcement.
Shear reinforcement shall be provided to carry a shear equal to $V_{u}-\tau_{c} b d$ The strength of shear reinforcement $V_{\text {os }}$ shall be calculated as below:
a) For vertical stirrups:

$$
V_{\mathrm{os}}=\frac{0.87 f_{y} A_{v v} d}{s_{v}}
$$

b) For inclined stirrups or a series of bars bent-up at different cross-sections:

$$
V_{\mathrm{os}}=\frac{0.8 .7 f_{y} A_{v v} d}{s_{v}}(\sin \alpha+\cos \alpha)
$$

c) For single bar or single group of parallel bars, all bent-up at the same cross-section:

$$
V_{\mathrm{os}}=0.87 f_{y} A_{v v} \sin \alpha
$$

where
$A_{v v}=$ total cross-sectional area of stirrup legs or bent-up bars within a distance $s_{v}$.
$s_{v}=$ spacing of the stirrups or bent-up bars along the length of the member;
$\tau_{v}=$ nominal shear stress,
$\tau_{c}=$ design shear strength of the concrete,
$b=$ breadth of the member which for flanged beams, shall be taken as the breadth of the web $b_{w}$,
$f_{y}=$ characteristic strength of the stirrup or bent-up reinforcement which shall not be taken greater than $415 \mathrm{~N} / \mathrm{mm}^{2}$,
$\alpha=$ angle between the inclined stirrup or bent- up bar and the axis of the member, not less than $45^{\circ}$, and
$d=$ effective depth.

## NOTES

1 Where more than one type of shear reinforcement is used to reinforce the same portion of the beam, the total shear resistance shall be computed as the sum of the resistance for the various types separately.
2 The area of the stirrups shall not be less than the minimum specified in 26.5.1.6.

### 40.5 Enhanced Shear Strength of Sections Close to Supports

### 40.5.1 General

Shear failure at sections of beams and cantilevers without shear reinforcement will normally occur on plane inclined at an angle $30^{\circ}$ to the horizontal. If the angle of failure plane is forced to be inclined more steeply than this [because the section considered $(X-X)$ in Fig. 24 is close to a support or for other reasons], the shear force required to produce failure is increased.
The enhancement of shear strength may be taken into account in the design of sections near a support by increasing design shear strength of concrete to $2 d \tau_{c} / a_{v}$ provided that design shear stress at the face of the support remains less than the values given in Table 20. Account may be taken of the enhancement in any situation where the section considered is closer to the face of a support or concentrated load than twice the effective depth, $d$. To be effective, tension reinforcement should extend on each side of the point where it is intersected by a possible failure plane for a distance at least equal to the effective depth, or be provided with an equivalent anchorage.

### 40.5.2 Shear Reinforcement for Sections Close to Supports

If shear reinforcement is required, the total area of this
is given by:

$$
A_{s}=a_{v} b\left(\tau_{v}-2 d \tau_{c} / a_{v}\right) / 0.87 f_{y} \geq 0.4 a_{v} b / 0.87 f_{y}
$$

This reinforcement should be provided within the middle three quarters of $a_{v}$, where $a_{v}$ is less than $d$, horizontal shear reinforcement will be effective than vertical.

### 40.5.3 Enhanced Shear Strength Near Supports (Simplified Approach)

The procedure given in 40.5 .1 and 40.5 .2 may be used for all beams. However for beams carrying generally uniform load or where the principal load is located farther than $2 d$ from the face of support, the shear stress may be calculated at a section a distance $d$ from the face of support. The value of $\tau_{v}$ is calculated in accordance with Table 19 and appropriate shear reinforcement is provided at sections closer to the support, no further check for shear at such sections is required.

## 41 LIMIT STATE OF COLLAPSE : TORSION

### 41.1 General

In structures, where torsion is required to maintain equilibrium, members shall be designed for torsion in accordance with 41.2, 41.3 and 41.4. However, for such indeterminate structures where torsion can be eliminated by releasing redundant restraints, no specific design for torsion is necessary, provided torsional stiffness is neglected in the calculation of internal forces. Adequate control of any torsional cracking is provided by the shear reinforcement as per 40.

NOTE - The approach to design in this clause is as follows: Torsional reinforcement is not calculated separately from that required for bending and shear. Instead the total longitudinal reinforcement is determined for a fictitious bending moment which is a function of actual bending moment and torsion;
![chunk-0-img-9.jpeg](chunk-0-img-9.jpeg)

NOTE - The shear causing failure is that acting on section $X-X$.
Fig. 24 Shear Failure Near Supports

similarly web reinforcement is determined for a fictitious shear which is a function of actual shear and torsion.
41.1.1 The design rules laid down in 41.3 and 41.4 shall apply to beams of solid rectangular cross-section. However, these clauses may also be applied to flanged beams, by substituting $b_{w}$ for $b$ in which case they are generally conservative; therefore specialist literature may be referred to.

### 41.2 Critical Section

Sections located less than a distance $d_{1}$ from the face of the support may be designed for the same torsion as computed at a distance $d$, where $d$ is the effective depth.

### 41.3 Shear and Torsion

### 41.3.1 Equivalent Shear

Equivalent shear, $V_{0}$, shall be calculated from the formula:

$$
V_{0}=V_{0}+1.6 \frac{T_{0}}{b}
$$

where

$$
\begin{aligned}
V_{0} & =\text { equivalent shear, } \\
V_{0} & =\text { shear, } \\
T_{0} & =\text { torsional moment, and } \\
b & =\text { breadth of beam. }
\end{aligned}
$$

The equivalent nominal shear stress, $\tau_{n n}$ in this case shall be calculated as given in 40.1, except for substituting $V_{0}$ by $V_{0}$. The values of $\tau_{n n}$ shall not exceed the values of $\tau_{c \text { men }}$ given in Table 20.
41.3.2 If the equivalent nominal shear stress, $\tau_{v e}$ does not exceed $\tau_{v}$ given in Table 19, minimum shear reinforcement shall be provided as per 26.5.1.6.
41.3.3 If $\tau_{v a}$ exceeds $\tau_{v}$ given in Table 19, both longitudinal and transverse reinforcement shall be provided in accordance with 41.4.

### 41.4 Reinforcement in Members Subjected to Torsion

41.4.1 Reinforcement for torsion, when required, shall consist of longitudinal and transverse reinforcement.

### 41.4.2 Longitudinal Reinforcement

The longitudinal reinforcement shall be designed to resist an equivalent bending moment, $M_{\mathrm{el}}$, given by

$$
M_{\mathrm{el}}=M_{\mathrm{u}}+M_{\mathrm{t}}
$$

where

$$
\begin{aligned}
& M_{0}=\text { bending moment at the cross-section, and } \\
& M_{1}=T_{0}\left(\frac{1+D / b}{1.7}\right)
\end{aligned}
$$

where
$T_{0}$ is the torsional moment, $D$ is the overall depth of the beam and $b$ is the breadth of the beam.
41.4.2.1 If the numerical value of $M_{1}$ as defined in 41.4.2 exceeds the numerical value of the moment $M_{u}$, longitudinal reinforcement shall be provided on the flexural compression face, such that the beam can also withstand an equivalent $M_{02}$ given by $M_{02}=M_{1}-M_{u}$, the moment $M_{02}$ being taken as acting in the opposite sense to the moment $M_{u}$.

### 41.4.3 Transverse Reinforcement

Two legged closed hoops enclosing the corner longitudinal bars shall have an area of cross-section $A_{v v}$, given by

$$
A_{v v}=\frac{T_{0} s_{v}}{b_{1} d_{1}\left(0.87 f_{y}\right)}+\frac{V_{0} s_{v}}{2.5 d_{1}\left(0.87 f_{y}\right)}
$$

but the total transverse reinforcement shall not be less than

$$
\frac{\left(\tau_{v a}-\tau_{v}\right) b_{1} s_{v}}{0.87 f_{y}}
$$

where

$$
\begin{aligned}
T_{u} & =\text { torsional moment, } \\
V_{u} & =\text { shear force, } \\
s_{v} & =\text { spacing of the stirrup reinforcement, } \\
b_{1} & =\text { centre-to-centre distance between corner } \\
& \text { bars in the direction of the width, } \\
d_{1} & =\text { centre-to-centre distance between corner } \\
& \text { bars, } \\
b & =\text { breadth of the member, } \\
f_{y} & =\text { characteristic strength of the stirrup } \\
& \text { reinforcement, } \\
\tau_{v a} & =\text { equivalent shear stress as specified in } \\
& \text { 41.3.1, and } \\
\tau_{v} & =\text { shear strength of the concrete as per Table }
\end{aligned}
$$

19. 

## 42 LIMIT STATE OF SERVICEABILITY: DEFLECTION

### 42.1 Flexural Members

In all normal cases, the deflection of a flexural member will not be excessive if the ratio of its span to its effective depth is not greater than appropriate ratios given in 23.2.1. When deflections are calculated according to Annex C, they shall not exceed the permissible values given in 23.2.

## 43 LIMIT STATE OF SERVICEABILITY: CRACKING

### 43.1 Flexural Members

In general, compliance with the spacing requirements of reinforcement given in 26.3 .2 should be sufficient to control flexural cracking. If greater spacing are required, the expected crack width should be checked by formula given in Annex F.

### 43.2 Compression Members

Cracks due to bending in a compression member subjected to a design axial load greater than $0.2 f_{\text {ck }} A_{c}$, where $f_{\text {ck }}$ is the characteristic compressive strength of concrete and $A_{c}$ is the area of the gross section of the member, need not be checked. A member subjected to lesser load than $0.2 f_{\text {ck }} A_{c}$ may be considered as flexural member for the purpose of crack control (see 43.1).

# ANNEX A 

(Clause 2)

## LIST OF REFERRED INDIAN STANDARDS

| IS No. | Title | IS No. | Title |
| :--: | :--: | :--: | :--: |
| $269: 1989$ | Specification for ordinary Portland cement, 33 grade (fourth revision) | $1642: 1989$ | Code of practice for fire safety of buildings (general) : Details of construction (first revision) |
| $383: 1970$ | Specification for coarse and fine aggregates from natural sources for concrete (second revision) | $1786: 1985$ | Specification for high strength deformed steel bars and wires for concrete reinforcement (third revision) |
| 432 (Part 1): <br> 1982 | Specification for mild steel and medium tensile steel bars and hard-drawn steel wire for concrete reinforcement: Part 1 Mild steel and medium tensile steel bars (third revision) | $1791: 1968$ <br> $1893: 1984$ | Specification for batch type concrete mixers (second revision) Criteria for earthquake resistant design of structures (fourth revision) |
| $455: 1989$ | Specification for Portland slag cement (fourth revision) | $1904: 1986$ | Code of practice for design and construction of foundations in soils : General requirements (third revision) |
| $516: 1959$ | Method of test for strength of concrete |  |  |
| 875 | Code of practice for design loads (other than earthquake) for buildings and structures : | $2062: 1992$ | Steel for general structural purposes (fourth revision) |
| (Part 1) : 1987 | Dead loads - Unit weights of building material and stored materials (second revision) | 2386 (Part 3) : $1963$ | Methods of test for aggregates for concrete : Part 3 Specific gravity, density, voids, absorption and bulking |
| (Part 2) : 1987 | Imposed loads (second revision) | $2502: 1963$ | Code of practice for bending and fixing of bars for concrete reinforcement |
| (Part 3) : 1987 | Wind loads (second revision) |  |  |
| (Part 4) : 1987 | Snow loads (second revision) | $2505: 1980$ | Concrete vibrators -Immersion type - General requirements |
| (Part 5) : 1987 | Special loads and load combinations (second revision) | $2506: 1985$ | General requirements for screed board concrete vibrators (first revision) |
| $1199: 1959$ | Methods of sampling and analysis of concrete | $2514: 1963$ | Specification for concrete vibrating tables |
| $1343: 1980$ | Code of practice for prestressed concrete (first revision) | $2751: 1979$ | Recommended practice for welding of mild steel plain and deformed bars for reinforced construction (first revision) |
| 1489 | Specification for Portland pozzolana cement : | $2751: 1979$ |  |
| (Part 1) : 1991 | Fly ash based (third revision) |  |  |
| (Part 2) : 1991 | Calcined clay based (third revision) | 3025 | Methods of sampling and test (physical and chemical) for water and waste water : |
| $1566: 1982$ | Specification for hard-drawn steel wire fabric for concrete reinforcement (second revision) | (Part 17) : 1984 | Non-filterable residue (total suspended solids) (first revision) |
| $1641: 1988$ | Code of practice for fire safety of buildings (general): General principles of fire grading and classification (first revision) | (Part 18) : 1984 | Volatile and fixed residue (total filterable and non-filterable) (first revision) |

| IS No. | Title | IS No. | Title |
| :--: | :--: | :--: | :--: |
| (Part 22) : 1986 | Acidity (first revision) | (Part 3) : 1972 | Concrete reinforcement |
| (Part 23) : 1986 | Alkalinity (first revision) | (Part 4) : 1972 | Types of concrete |
| (Part 24) : 1986 | Sulphates (first revision) | (Part 5) : 1972 | Formwork for concrete |
| (Part 32) : 1988 | Chloride (first revision) | (Part 6) : 1972 | Equipment, tool and plant |
| $3414: 1968$ | Code of practice for design and installation of joints in buildings | (Part 7) : 1973 | Mixing, laying, compaction, curing and other construction aspect |
| $3812: 1981$ | Specification for fly ash for use as pozzolana and admixture (first revision) | (Part 8) : 1973 <br> (Part 9) : 1973 | Properties of concrete Structural aspects |
| 3951 (Part 1) : 1975 | Specification for hollow clay tiles for floors and roofs: Part 1 Filler type (first revision) | (Part 10) : 1973 <br> (Part 11) : 1973 | Tests and testing apparatus Prestressed concrete |
| 4031(Part 5) : 1988 | Methods of physical tests for hydraulic cement : Part 5 Determination of initial and final setting times (first revision) | (Part 12) : 1973 <br> 6909: 1990 | Miscellaneous <br> Specification for supersulphated cement |
| $4082: 1996$ | Recommendations on stacking and storage of construction materials and components at site (second revision) | 7861 | Code of practice for extreme weather concreting : |
| $4326: 1993$ | Code of practice for earthquake resistant design and construction of buildings (second revision) | (Part 1) : 1975 <br> (Part 2) : 1975 | Recommended practice for hot weather concreting <br> Recommended practice for cold weather concreting |
| $4656: 1968$ | Specification for form vibrators for concrete | 8041 : 1990 | Specification for rapid hardening Portland cement (second revision) |
| $4845: 1968$ | Definitions and terminology relating to hydraulic cement | $8043: 1991$ | Specification for hydrophobic Portland cement (second revision) |
| $4925: 1968$ | Specification for concrete batching and mixing plant | $8112: 1989$ | Specification for 43 grade ordinary Portland cement (first revision) |
| $4926: 1976$ | Specification for ready-mixed concrete (second revision) | $9013: 1978$ | Method of making, curing and determining compressive strength of accelerated cured |
| $5816: 1999$ | Method of test for splitting tensile strength of concrete (first revision) | $9103: 1999$ | concrete test specimens <br> Specification for admixtures for concrete (first revision) |
| 6061 | Code of practice for construction of floor and roof with joists and filler blocks : | $9417: 1989$ | Recommendations for welding cold worked bars for reinforced concrete construction (first revision) |
| (Part 1) : 1971 | With hollow concrete filler blocks | $11817: 1986$ | Classification of joints in buildings for accommodation of dimensional deviations during construction |
| (Part 2) : 1971 | With hollow clay filler blocks (first revision) |  |  |
| $6452: 1989$ | Specification for high alumina cement for structural use | $12089: 1987$ | Specification for granulated slag for manufacture of Portland slag cement |
| 6461 | Glossary of terms relating to cement: | $12119: 1987$ | General requirements for pan mixers for concrete |
| (Part 1) : 1972 | Concrete aggregates |  |  |
| (Part 2) : 1972 | Materials |  |  |

IS No.

| 12269: 1987 | Specification for 53 grade ordinary Portland cement | (Part 1) : 1992 <br> (Part 2) : 1992 | Ultrasonic pulse velocity <br> Rebound hammer |
| :--: | :--: | :--: | :--: |
| 12330: 1988 | Specification for sulphate resisting Portland cement | $13920: 1993$ | Code of practice for ductile detailing of reinforced concrete structures subjected to seesmic forces |
| 12600: 1989 | Specification for low heat Portland cement |  |  |
| 13311 | Methods of non-destructive testing of concrete : | 14687 : 1999 | Guidelines for falsework for concrete structures |



