### 8.2.5 Mix Constituents

### 8.2.5.1 General

For concrete to be durable, careful selection of the mix and materials is necessary, so that deleterious constituents do not exceed the limits.

### 8.2.5.2 Chlorides in concrete

Whenever there is chloride in concrete there is an increased risk of corrosion of embedded metal. The higher the chloride content, or if subsequently exposed to warm moist conditions, the greater the risk of corrosion. All constituents may contain chlorides and concrete may be contaminated by chlorides from the external environment. To minimize the chances of deterioration of concrete from harmful chemical salts, the levels of such harmful salts in concrete coming from concrete materials, that is, cement, aggregates water and admixtures, as well as by diffusion from the environment should be limited. The total amount of chloride content (as Cl ) in the concrete at the time of placing shall be as given in Table 7.
The total acid soluble chloride content should be calculated from the mix proportions and the measured chloride contents of each of the constituents. Wherever possible, the total chloride content of the concrete should be determined.

### 8.2.5.3 Sulphates in concrete

Sulphates are present in most cements and in some aggregates; excessive amounts of water-soluble sulphate from these or other mix constituents can cause
expansion and disruption of concrete. To prevent this, the total water-soluble sulphate content of the concrete mix, expressed as $\mathrm{SO}_{2}$, should not exceed 4 percent by mass of the cement in the mix. The sulphate content should be calculated as the total from the various constituents of the mix.

The 4 percent limit does not apply to concrete made with supersulphated cement complying with IS 6909.

### 8.2.5.4 Alkali-aggregate reaction

Some aggregates containing particular varieties of silica may be susceptible to attack by alkalis $\left(\mathrm{Na}_{2} \mathrm{O}\right.$ and $\mathrm{K}_{2} \mathrm{O}$ ) originating from cement or other sources, producing an expansive reaction which can cause cracking and disruption of concrete. Damage to concrete from this reaction will normally only occur when all the following are present together:
a) A high moisture level, within the concrete;
b) A cement with high alkali content, or another source of alkali;
c) Aggregate containing an alkali reactive constituent.
Where the service records of particular cement/ aggregate combination are well estabFshed, and do not include any instances of cracking due to alkaliaggregate reaction, no further precautions should be necessary. When the materials are unfamiliar, precautions should take one or more of the following forms:
a) Use of non-reactive aggregate from alternate sources.

Table 5 Minimum Cement Content, Maximum Water-Cement Ratio and Minimum Grade of Concrete . for Different Exposures with Normal Weight Aggregates of 20 mm Nominal Maximum Size
(Clauses 6.1.2, 8.2.4.1 and 9.1.2)

| Sl <br> No. | Exposure | Plain Concrete |  |  |  | Reinforced Concrete |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  | Minimum Cement Content $\mathrm{kg} / \mathrm{m}^{3}$ | Maximum Free WaterCement Ratio | Minimum Grade of Concrete |  | Minimum Cement Content $\mathrm{kg} / \mathrm{m}^{3}$ | Maximum Free WaterCement Ratio | Minimum Grade of Concrete |
| 1) | (2) | (3) | (4) | (5) |  | (6) | (7) | (8) |
| i) | Mild | 220 | 0.60 | - |  | 300 | $0.5 \%$ | M 20 |
| iii) | Moderate | 240 | 0.60 | M 15 |  | 300 | $0.50$ | M 25 |
| iii) | Severe | 250 | 0.50 | M 20 |  | 320 | 0.45 | M 30 |
| iv) | Very severe | 260 | 0.45 | M 20 |  | 340 | 0.45 | M 35 |
| v) | Extreme | 280 | 0.40 | M 25 |  | 360 | 0.40 | M 40 |
| NOTES |  |  |  |  |  |  |  |  |

1 Cement content prescribed in this table is irrespective of the grades of cement and it is inclusive of additions mentioned in 5.2. The additions such as fly ash or ground granulated blast furnace slag may be taken into account in the concrete composition with respect to the cement content and water-cement ratio if the suitability is established and as long as the maximum amounts taken into account do not exceed the limit of pozzolona and slag specified in IS 1489 (Part 1) and IS 455 respectively.
2 Minimum grade for plain concrete under mild exposure condition is not specified.

Table 6 Adjustments to Minimum Cement Contents for Aggregates Other Than 20 mm Nominal Maximum Size
(Clause 8.2.4.1)

| SI | Nominal Maximum | Adjustments to Minimum Cement |
| :-- | :--: | :--: |
| No. | Aggregate Size | Contents In Table 5 |
|  | mm | $\mathrm{kg} / \mathrm{m}^{3}$ |
| (1) | $(2)$ | $(3)$ |
| i) | 10 | +40 |
| ii) | 20 | 0 |
| iii) | 40 | -30 |

Table 7 Limits of Chloride Content of Concrete
(Clause 8.2.5.2)

| SI <br> No. | Type or Use of Concrete | Maximum Total <br> Acid Soluble <br> Chloride Content <br> Expressed as $\mathrm{kg} / \mathrm{m}^{3}$ of <br> Concrete |
| :--: | :--: | :--: |
| (1) | (2) | (3) |
| i) | Concrete containing metal and steam cured at elevated temperature and pre-stressed concrete | 0.4 |
| ii) | Reinforced concrete or plain concrete containing embedded metal | 0.6 |
| iii) | Concrete not containing embedded metal or any material requiring protection from chloride | 3.0 |

b) Use of low alkali ordinary Portland cement having total alkali content not more than 0.6 percent (as $\mathrm{Na}_{2} \mathrm{O}$ equivalent).
Further advantage can be obtained by use of fly ash (Grade 1) conforming to IS 3812 or granulated blastfurnace slag conforming to IS 12089 as part replacement of ordinary Portland cement (having total alkali content as $\mathrm{Na}_{2} \mathrm{O}$ equivalent not more than 0.6 percent), provided fly ash content is at least 20 percent or slag content is at least 50 percent.
c) Measures to reduce the degree of saturation of the concrete during service such as use of impermeable membranes.
d) Limiting the cement content in the concrete mix and thereby limiting total alkali content in the concrete mix. For more guidance specialist literatures may be referred.

### 8.2.6 Concrete in Aggressive Soils and Water

### 8.2.6.1 General

The destructive action of aggressive waters on concrete is progressive. The rate of deterioration decreases as the concrete is made stronger and more impermeable, and increases as the salt content of the water increases. Where structures are only partially immersed or are in contact with aggressive soils or waters on one side only,
evaporation may cause serious concentrations of salts with subsequent deterioration, even where the original salt content of the soil or water is not high.

NOTE-Guidance regarding requirements for concrete exposed to sulphate attack is given in 8.2.2.4.

### 8.2.6.2 Drainage

At sites where alkali concentrations are high or may become very high, the ground water should be lowered by drainage so that it will not come into direct contact with the concrete.
Additional protection may be obtained by the use of chemically resistant stone facing or a layer of plaster of Paris covered with suitable fabric, such as jute thoroughly impregnated with bituminous material.

### 8.2.7 Compaction, Finishing and Curing

Adequate compaction without segregation should be ensured by providing suitable workability and by employing appropriate placing and compacting equipment and procedures. Full compaction is particularly important in the vicinity of construction and movement joints and of embedded water bars and reinforcement.
Good finishing practices are essential for durable concrete.
Overworking the surface and the addition of water/ cement to aid in finishing should be avoided; the resulting laitance will have impaired strength and durability and will be particularly vulnerable to, freezing and thawing under wet conditions.
It is essential to use proper and adequate curing techniques to reduce the permeability of the concrete, and enhance its durability by extending the hydration of the cement, particularly in its surface zone (see 13.5).

### 8.2.8 Concrete in Sea-water

Concrete in sea-water or exposed directly along the sea-coast shall be at least M 20 Grade in the case of plain concrete and M 30 in case of reinforced concrete. The use of slag or pozzolana cement is advantageous under such conditions.
8.2.8.1 Special attention shall be given to the design of the mix to obtain the densest possible concrete; slag, broken brick, soft limestone, soft sandstone, or other porous or weak aggregates shall not be used.
8.2.8.2 As far as possible, preference shall be given to precast members unreinforced, well-cured and hardened, without sharp corners, and having trowelsmooth finished surfaces free from crazing, cracks or other defects; plastering should be avoided.
8.2.8.3 No construction joints shall be allowed within 600 mm below low water-level or within 600 mm of the upper and lower planes of wave action. Where

unusually severe conditions or abrasion are anticipated, such parts of the work shall be protected by bituminous or silico-fluoride coatings or stone facing bedded with bitumen.
8.2.8.4 In reinforced concrete structures, care shall be taken to protect the reinforcement from exposure to saline atmosphere during storage, fabrication and use. It may be achieved by treating the surface of reinforcement with cement wash or by suitable methods.

## 9 CONCRETE MIX PROPORTIONING

### 9.1 Mix Proportion

The mix proportions shall be selected to ensure the workability of the fresh concrete and when concrete is hardened, it shall have the required strength, durability and surface finish.
9.1.1 The determination of the proportions of cement, aggregates and water to attain the required strengths shall be made as follows:
a) By designing the concrete mix; such concrete shall be called 'Design mix concrete', or
b) By adopting nominal concrete mix; such concrete shall be called 'Nominal mix concrete'.
Design mix concrete is preferred to nominal mix. If design mix concrete cannot be used for any reason on the work for grades of M 20 or lower, nominal mixes may be used with the permission of engineer-in-charge, which, however, is likely to involve a higher cement content.

### 9.1.2 Information Required

In specifying a particular grade of concrete, the following information shall be included:
a) Type of mix, that is, design mix concrete or nominal mix concrete;
b) Grade designation;
c) Type of cement;
d) Maximum nominal size of aggregate;
e) Minimum cement content (for design mix concrete);
f) Maximum water-cement ratio;
g) Workability;
h) Mix proportion (for nominal mix concrete);
j) Exposure conditions as per Tables 4 and 5;
k) Maximum temperature of concrete at the time of placing;
m) Method of placing; and
n) Degree of supervision.
9.1.2.1 In appropriate circumstances, the following additional information may be specified:
a) Type of aggregate,
b) Maximum cement content, and
c) Whether an admixture shall or shall not be used and the type of admixture and the condition of use.

### 9.2 Design Mix Concrete

9.2.1 As the guarantor of quality of concrete used in the construction, the constructor shall carry out the mix design and the mix so designed (not the method of design) shall be approved by the employer within the limitations of parameters and other stipulations laid down by this standard.
9.2.2 The mix shall be designed to produce the grade of concrete having the required workability and a characteristic strength not less than appropriate values given in Table 2. The target mean strength of concrete mix should be equal to the characteristic strength plus 1.65 times the standard deviation.
9.2.3 Mix design done earlier not prior to one year may be considered adequate for later work provided there is no change in source and the quality of the materials.

### 9.2.4 Standard Deviation

The standard deviation for each grade of concrete shall be calculated, separately.
9.2.4.1 Standard deviation based on test strength of sample
a) Number of test results of samples-The total number of test strength of samples required to constitute an acceptable record for calculation of standard deviation shall be not less than 30. Attempts should be made to obtain the 30 samples, as early as possible, when a mix is used for the first time.
b) In case of significant changes in concreteWhen significant changes are made in the production of concrete batches (for example changes in the materials used, mix design, equipment or technical control), the standard deviation value shall be separately calculated for such batches of concrete.
c) Standard deviation to be brought up to dateThe calculation of the standard deviation shall be brought up to date after every change of mix design.

### 9.2.4.2 Assumed standard deviation

Where sufficient test results for a particular grade of concrete are not available, the value of standard deviation given in Table 8 may be assumed for design of mix in the first instance. As soon as the results of samples are available, actual calculated standard deviation shall be used and the mix designed properly.

However, when adequate past records for a similar grade exist and justify to the designer a value of standard deviation different from that shown in Table 8, it shall be permissible to use that value.

Table 8 Assumed Standard Deviation
(Clause 9.2.4.2 and Table 11)

| Grade of <br> Concrete | Assumed Standard <br> Deviation <br> $\mathrm{N} / \mathrm{mm}^{2}$ |
| :--: | :--: |
| M 10 <br> M 15 | 3.5 |
| M 20 <br> M 25 | 4.0 |
| M 30 <br> M 35 <br> M 40 <br> M 45 <br> M 50 | 5.0 |

NOTE-The above values correspond to the site control having proper storage of cement; weigh batching of all materials; controlled addition of water; regular checking of all materials, aggregate gradings and moisture content; and periodical checking of workability and strength. Where there is deviation from the above the values given in the above table shall be increased by $1 \mathrm{~N} / \mathrm{mm}^{2}$.

### 9.3 Nominal Mix Concrete

Nominal mix concrete may be used for concrete of M 20 or lower. The proportions of materials for nominal mix concrete shall be in accordance with Table 9.
9.3.1 The cement content of the mix specified in Table 9 for any nominal mix shall be proportionately increased if the quantity of water in a mix has to be increased to overcome the difficulties of placement and compaction, so that the water-cement ratio as specified is not exceeded.

## 10 PRODUCTION OF CONCRETE

### 10.1 Quality Assurance Measures

10.1.1 In order that the properties of the completed structure be consistent with the requirements and the assumptions made during the planning and the design, adequate quality assurance measures shall be taken. The construction should result in satisfactory strength, serviceability and long term durability so as to lower the overall life-cycle cost. Quality assurance in construction activity relates to proper design, use of adequate materials and components to be supplied by the producers, proper workmanship in the execution of works by the contractor and ultimately proper care during the use of structure including timely maintenance and repair by the owner.
10.1.2 Quality assurance measures are both technical and organizational. Some common cases should be specified in a general Quality Assurance Plan which shall identify the key elements necessary to provide fitness of the structure and the means by which they are to be provided and measured with the overall purpose to provide confidence that the realized project will work satisfactorily in service fulfilling intended needs. The job of quality control and quality assurance would involve quality audit of both the inputs as well as the outputs. Inputs are in the form of materials for concrete; workmanship in all stages of batching, mixing, transportation, placing, compaction and curing; and the related plant, machinery and equipments; resulting in the output in the form of concrete in place. To ensure proper performance, it is necessary that each step in concreting which will be covered by the next step is inspected as the work proceeds (see also 17).

Table 9 Proportions for Nominal Mix Concrete
(Clauses 9.3 and 9.3.1)

| Grade of Concrete | Total Quantity of Dry Aggregates by Mass per 50 kg of Cement, to be Taken as the Sum of the Individual Masses of Fine and Coarse Aggregates, $\mathbf{k g}$, Max | Proportion of Fine <br> Aggregate to Coarse <br> Aggregate (by Mass) | Quantity of Water per 50 kg of Cement, Max |
| :--: | :--: | :--: | :--: |
| (1) | (2) | (3) | (4) |
| M 5 | 800 | Generally 1:2 but subject to | 60 |
| M 7.5 | 625 | an upper limit of $1: 1 / 2$ and a | 45 |
| M 10 | 480 | lower limit of $1: 2 / 3$ | 34 |
| M 15 | 330 |  | 32 |
| M 20 | 250 |  | 30 |

NOTE-The proportion of the fine to coarse aggregates should be adjusted from upper limit to lower limit progressively as the grading of fine aggregates becomes finer and the maximum size of coarse aggregate becomes larger. Graded coarse aggregate shall be used.

## Example

For an average grading of fine aggregate (that is, Zone II of Table 4 of IS 383), the proportions shall be $1: 1 / 2,1: 2$ and $1: 2 / 3$, for maximum size of aggregates $10 \mathrm{~mm}, 20 \mathrm{~mm}$ and 40 mm respectively.

10.1.3 Each party involved in the realization of a project should establish and implement a Quality Assurance Plan, for its participation in the project. Supplier's and subcontractor's activities shall be covered in the plan. The individual Quality Assurance Plans shall fit into the general Quality Assurance Plan. A Quality Assurance Plan shall define the tasks and responsibilities of all persons involved, adequate control and checking procedures, and the organization and maintaining adequate documentation of the building process and its results. Such documentation should generally include:
a) test reports and manufacturer's certificate for materials, concrete mix design details;
b) pour cards for site organization and clearance for concrete placement;
c) record of site inspection of workmanship, field tests;
d) non-conformance reports, change orders;
e) quality control charts; and
f) statistical analysis.

NOTE-Quality control charts are recommended wherever the concrete is in continuous production over considerable period.

### 10.2 Batching

To avoid confusion and error in batching, consideration should be given to using the smallest practical number of different concrete mixes on any site or in any one plant. In batching concrete, the quantity of both cement and aggregate shall be determined by mass; admixture, if solid, by mass; liquid admixture may however be measured in volume or mass; water shall be weighed or measured by volume in a calibrated tank (see also IS 4925).
Ready-mixed concrete supplied by ready-mixed concrete plant shall be preferred. For large and medium project sites the concrete shall be sourced from readymixed concrete plants or from on site or off site batching and mixing plants (see IS 4926).
10.2.1 Except where it can be shown to the satisfaction of the engineer-in-charge that supply of properly graded aggregate of uniform quality can be maintained over a period of work, the grading of aggregate should be controlled by obtaining the coarse aggregate in different sizes and blending them in the right proportions when required, the different sizes being stocked in separate stock-piles. The material should be stock-piled for several hours preferably a day before use. The grading of coarse and fine aggregate should be checked as frequently as possible, the frequency for a given job being determined by the engineer-incharge to ensure that the specified grading is maintained.
10.2.2 The accuracy of the measuring equipment shall be within $\pm 2$ percent of the quantity of cement being
measured and within $\pm 3$ percent of the quantity of aggregate, admixtures and water being measured.
10.2.3 Proportion/Type and grading of aggregates shall be made by trial in such a way so as to obtain densest possible concrete. All ingredients of the concrete should be used by mass only.
10.2.4 Volume batching may be allowed only where weigh-batching is not practical and provided accurate bulk densities of materials to be actually used in concrete have earlier been established. Allowance for bulking shall be made in accordance with IS 2386 (Part 3). The mass volume relationship should be checked as frequently as necessary, the frequency for the given job being determined by engineer-in-charge to ensure that the specified grading is maintained.
10.2.5 It is important to maintain the water-cement ratio constant at its correct value. To this end, determination of moisture contents in both fine and coarse aggregates shall be made as frequently as possible, the frequency for a given job being determined by the engineer-in-charge according to weather conditions. The amount of the added water shall be adjusted to compensate for any observed variations in the moisture contents. For the determination of moisture content in the aggregates, IS 2386 (Part 3) may be referred to. To allow for the variation in mass of aggregate due to variation in their moisture content, suitable adjustments in the masses of aggregates shall also be made. In the absence of exact data, only in the case of nominal mixes, the amount of surface water may be estimated from the values given in Table 10.

Table 10 Surface Water Carried by Aggregate (Clause 10.2.5)

| SI <br> No. | Aggregate | Approximate Quantity of Surface Water |  |
| :--: | :--: | :--: | :--: |
|  |  | Percent by Mass | $1 / \mathrm{m}^{2}$ |
| (1) | (2) | (3) | (4) |
| i) | Very wet sand | 7.5 | 120 |
| ii) | Moderately wet sand | 5.0 | 80 |
| iii) | Moist sand | 2.5 | 40 |
| iv) | ${ }^{10}$ Moist gravel or crushed rock | $1.25-2.5$ | $20-40$ |

${ }^{1)}$ Coarser the aggregate, less the water it will carry.
10.2.6 No substitutions in materials used on the work or alterations in the established proportions, except as permitted in 10.2 .4 and 10.2 .5 shall be made without additional tests to show that the quality and strength of concrete are satisfactory.

### 10.3 Mixing

Concrete shall be mixed in a mechanical mixer. The mixer should comply with IS 1791 and IS 12119. The mixers shall be fitted with water measuring (metering) devices. The mixing shall be continued until there is a uniform distribution of the materials and the mass is

uniform in colour and consistency. If there is segregation after unloading from the mixer, the concrete should be remixed.
10.3.1 For guidance, the mixing time shall be at least 2 min . For other types of more efficient mixers, manufacturers recommendations shall be followed; for hydrophobic cement it may be decided by the engineer-in-charge.
10.3.2 Workability should be checked at frequent intervals (see IS 1199).
10.3.3 Dosages of retarders, plasticisers and superplasticisers shall be restricted to $0.5,1.0$ and 2.0 percent respectively by weight of cementitious materials and unless a higher value is agreed upon between the manufacturer and the constructor based on performance test.

## 11 FORMWORK

### 11.1 General

The formwork shall be designed and constructed so as to remain sufficiently rigid during placing and compaction of concrete, and shall be such as to prevent loss of slurry from the concrete. For further details regarding design, detailing, etc, reference may be made to IS 14687 . The tolerances on the shapes, lines and dimensions shown in the drawing shall be within the limits given below:

| a) Deviation from specified dimensions of cross-section of columns and beams | $+12$ <br> -6 mm |
| :--: | :--: |
| b) Deviation from dimensions of footings |  |
| 1) Dimensions in plan | $+50 \mathrm{~mm}$ |
| 2) Eccentricity | 0.02 times the width of the footing in the direction of deviation but not more than 50 mm |
| 3) Thickness | $\pm 0.05$ times the specified thickness |

These tolerances apply to concrete dimensions only, and not to positioning of vertical reinforcing steel or dowels.

### 11.2 Cleaning and Treatment of Formwork

All rubbish, particularly, chippings, shavings and sawdust shall be removed from the interior of the forms before the concrete is placed. The face of formwork in contact with the concrete shall be cleaned and treated with form release agent. Release agents should be applied so as to provide a thin uniform coating to the forms without coating the reinforcement.

### 11.3 Stripping Time

Forms shall not be released until the concrete has achieved a strength of at least twice the stress to which the concrete may be subjected at the time of removal of formwork. The strength referred to shall be that of concrete using the same cement and aggregates and admixture, if any, with the same proportions and cured under conditions of temperature and moisture similar to those existing on the work.
11.3.1 While the above criteria of strength shall be the guiding factor for removal of formwork, in normal circumstances where ambient temperature does not fall below $15^{\circ} \mathrm{C}$ and where ordinary Portland cement is used and adequate curing is done, following striking period may deem to satisfy the guideline given in 11.3:

| Type of Formwork | Minimum Period Before Striking Formwork |
| :--: | :--: |
| a) Vertical formwork to columns, walls, beams | $16-24 \mathrm{~h}$ |
| b) Soffit formwork to slabs (Props to be refixed immediately after removal of formwork) | 3 days |
| c) Soffit formwork to beams (Props to be refixed immediately after removal of formwork) | 7 days |
| d) Props to slabs: |  |
| 1) Spanning up to 4.5 m | 7 days |
| 2) Spanning over 4.5 m | 14 days |
| e) Props to beams and arches: |  |
| 1) Spanning up to 6 m | 14 days |
| 2) Spanning over 6 m | 21 days |

For other cements and lower temperature, the stripping time recommended above may be suitably modified.
11.3.2 The number of props left under, their sizes and disposition shall be such as to be able to safely carry the full dead load of the slab, beam or arch as the case may be together with any live load likely to occur during curing or further construction.
11.3.3 Where the shape of the element is such that the formwork has re-entrant angles, the formwork shall be removed as soon as possible after the concrete has set, to avoid shrinkage cracking occurring due to the restraint imposed.

## 12 ASSEMBLY OF REINFORCEMENT

12.1 Reinforcement shall be bent and fixed in accordance with procedure specified in IS 2502. The high strength deformed steel bars should not be re-bent

or straightened without the approval of engineer-incharge.
Bar bending schedules shall be prepared for all reinforcement work.
12.2 All reinforcement shall be placed and maintained in the position shown in the drawings by providing proper cover blocks, spacers, supporting bars, etc.
12.2.1 Crossing bars should not be tack-welded for assembly of reinforcement unless permitted by engineer-in-charge.

### 12.3 Placing of Reinforcement

Rough handling, shock loading (prior to embedment) and the dropping of reinforcement from a height should be avoided. Reinforcement should be secured against displacement outside the specified limits.

### 12.3.1 Tolerances on Placing of Reinforcement

Unless otherwise specified by engineer-in-charge, the reinforcement shall be placed within the following tolerances:
a) for effective depth 200 mm or less
b) for effective depth more than 200 mm
$\pm 10 \mathrm{~mm}$

### 12.3.2 Tolerance for Cover

Unless specified otherwise, actual concrete cover should not deviate from the required nominal cover by $\begin{aligned} & +10 \\ & 0 \mathrm{~mm}\end{aligned}$
Nominal cover as given in 26.4 .1 should be specified to all steel reinforcement including links. Spacers between the links (or the bars where no links exist) and the formwork should be of the same nominal size as the nominal cover.
Spacers, chairs and other supports detailed on drawings, together with such other supports as may be necessary, should be used to maintain the specified nominal cover to the steel reinforcement. Spacers or chairs should be placed at a maximum spacing of 1 m and closer spacing may sometimes be necessary.
Spacers, cover blocks should be of concrete of same strength or PVC.

### 12.4 Welded Joints or Mechanical Connections

Welded joints or mechanical connections in reinforcement may be used but in all cases of important connections, tests shall be made to prove that the joints are of the full strength of bars connected. Welding of reinforcements shall be done in accordance with the recommendations of IS 2751 and IS 9417.
12.5 Where reinforcement bars upto 12 mm for high strength deformed steel bars and up to 16 mm for mild
steel bars are bent aside at construction joints and afterwards bent back into their original positions, care should be taken to ensure that at no time is the radius of the bend less than 4 bar diameters for plain mild steel or 6 bar diameters for deformed bars. Care shall also be taken when bending back bars, to ensure that the concrete around the bar is not damaged beyond the band.
12.6 Reinforcement should be placed and tied in such a way that concrete placement be possible without segregation of the mix. Reinforcement placing should allow compaction by immersion vibrator. Within the concrete mass, different types of metal in contact should be avoided to ensure that bimetal corrosion does not take place.

## 13 TRANSPORTING, PLACING, COMPACTION AND CURING

### 13.1 Transporting and Handling

After mixing, concrete shall be transported to the formwork as rapidly as possible by methods which will prevent the segregation or loss of any of the ingredients or ingress of foreign matter or water and maintaining the required workability.
13.1.1 During hot or cold weather, concrete shall be transported in deep containers. Other suitable methods to reduce the loss of water by evaporation in hot weather and heat loss in cold weather may also be adopted.

### 13.2 Placing

The concrete shall be deposited as nearly as practicable in its final position to avoid rehandling. The concrete shall be placed and compacted before initial setting of concrete commences and should not be subsequently disturbed. Methods of placing should be such as to preclude segregation. Care should be taken to avoid displacement of reinforcement or movement of formwork. As a general guidance, the maximum permissible free fall of concrete may be taken as 1.5 m .

### 13.3 Compaction

Concrete should be thoroughly compacted and fully worked around the reinforcement, around embedded fixtures and into corners of the formwork.
13.3.1 Concrete shall be compacted using mechanical vibrators complying with IS 2505, IS 2506, IS 2514 and IS 4656 . Over vibration and under vibration of concrete are harmful and should be avoided. Vibration of very wet mixes should also be avoided.
Whenever vibration has to be applied externally, the design of formwork and the disposition of vibrators should receive special consideration to ensure efficient compaction and to avoid surface blemishes.

### 13.4 Construction Joints and Cold Joints

Joints are a common source of weakness and, therefore, it is desirable to avoid them. If this is not possible, their number shall be minimized. Concreting shall be carried out continuously up to construction joints, the position and arrangement of which shall be indicated by the designer. Construction joints should comply with IS 11817.
Construction joints shall be placed at accessible locations to permit cleaning out of laitance, cement slurry and unsound concrete, in order to create rough/ uneven surface. It is recommended to clean out laitance and cement slurry by using wire brush on the surface of joint immediately after initial setting of concrete and to clean out the same immediately thereafter. The prepared surface should be in a clean saturated surface dry condition when fresh concrete is placed, against it.
In the case of construction joints at locations where the previous pour has been cast against shuttering the recommended method of obtaining a rough surface for the previously poured concrete is to expose the aggregate with a high pressure water jet or any other appropriate means.
Fresh concrete should be thoroughly vibrated near construction joints so that mortar from the new concrete flows between large aggregates and develop proper bond with old toncrete.
Where high shear resistance is required at the construction joints, shear keys may be provided.
Sprayed curing membranes and release agents should be thoroughly removed from joint surfaces.

### 13.5 Curing

Curing is the process of preventing the loss of moisture from the concrete whilst maintaining a satisfactory temperature regime. The prevention of moisture loss from the concrete is particularly important if the watercement ratio is low, if the cement has a high rate of strength development, if the concrete contains granulated blast furnace slag or pulverised fuel ash. The curing regime should also prevent the development of high temperature gradients within the concrete.
The rate of strength development at early ages of concrete made with supersulphated cement is significantly reduced at lower temperatures. Supersulphated cement concrete is seriously affected by inadequate curing and the surface has to be kept moist for at least seven days.

### 13.5.1 Moist Curing

Exposed surfaces of concrete shall be kept continuously in a damp or wet condition by ponding or by covering with a layer of sacking, canvas, hessian or similar materials and kept constantly wet for at least seven days from the date of placing concrete in case
of ordinary Portland Cement and at least 10 days where mineral admixtures or blended cements are used. The period of curing shall not be less than 10 days for concrete exposed to dry and hot weather conditions. In the case of concrete where mineral admixtures or blended cements are used, it is recommended that above minimum periods may be extended to 14 days.

### 13.5.2 Membrane Curing

Approved curing compounds may be used in lieu of moist curing with the permission of the engineer-incharge. Such compounds shall be applied to all exposed surfaces of the concrete as soon as possible after the concrete has set. Impermeable membranes such as polyethylene sheeting covering closely the concrete surface may also be used to provide effective barrier against evaporation.
13.5.3 For the concrete containing Portland pozzolana cement, Portland slag cement or mineral admixture, period of curing may be increased.

### 13.6 Supervision

It is exceedingly difficult and costly to alter concrete once placed. Hence, constant and strict supervision of all the items of the construction is necessary during the progress of the work, including the proportioning and mixing of the concrete. Supervision is also of extreme importance to check the reinforcement and its placing before being covered.
13.6.1 Before any important operation, such as concreting or stripping of the formwork is started, adequate notice shall be given to the construction supervisor.

## 14 CONCRETING UNDER SPECIAL CONDITIONS

### 14.1 Work in Extreme Weather Conditions

During hot or cold weather, the concreting should be done as per the procedure set out in IS 7861 (Part 1) or IS 7861 (Part 2).

### 14.2 Under-Water Concreting

14.2.1 When it is necessary to deposit concrete under water, the methods, equipment, materials and proportions of the mix to be used shall be submitted to and approved by the engineer-in-charge before the work is started.
14.2.2 Under-water concrete should have a slump recommended in 7.1. The water-cement ratio shall not exceed 0.6 and may need to be smaller, depending on the grade of concrete or the type of chemical attack. For aggregates of 40 mm maximum particle size, the cement content shall be at least $350 \mathrm{~kg} / \mathrm{m}^{3}$ of concrete.
14.2.3 Coffer-dams or forms shall be sufficiently tight

to ensure still water if practicable, and in any case to reduce the flow of water to less than $3 \mathrm{~m} / \mathrm{min}$ through the space into which concrete is to be deposited. Coffer-dams or forms in still water shall be sufficiently tight to prevent loss of mortar through the walls. De-watering by pumping shall not be done while concrete is being placed or until 24 h thereafter.
14.2.4 Concrete cast under water should not fall freely through the water. Otherwise it may be leached and become segregated. Concrete shall be deposited continuously until it is brought to the required height. While depositing, the top surface shall be kept as nearly level as possible and the formation of seams avoided. The methods to be used for depositing concrete under water shall be one of the following:
a) Tremie-The concrete is placed through vertical pipes the lower end of which is always inserted sufficiently deep into the concrete which has been placed previously but has not set. The concrete emerging from the pipe pushes the material that has already been placed to the side and upwards and thus does not come into direct contact with water.
When concrete is to be deposited under water by means of tremie, the top section of the tremie shall be a hopper large enough to hold one entire batch of the mix or the entire contents the transporting bucket, if any. The tremie pipe shall be not less than 200 mm in diameter and shall be large enough to allow a free flow of concrete and strong enough to withstand the external pressure of the water in which it is suspended, even if a partial vacuum develops inside the pipe. Preferably, flanged steel pipe of adequate strength for the job should be used. A separate lifting device shall be provided for each tremie pipe with its hopper at the upper end. Unless the lower end of the pipe is equipped with an approved automatic check valve, the upper end of the pipe shall be plugged with a wadding of the gunny sacking or other approved material before delivering the concrete to the tremie pipe through the hopper, so that when the concrete is forced down from the hopper to the pipe, it will force the plug (and along with it any water in the pipe) down the pipe and out of the bottom end, thus establishing a continuous stream of concrete. It will be necessary to raise slowly the tremie in order to cause a uniform flow of the concrete, but the tremie shall not be emptied so that water enters the pipe. At all times after the placing of concrete is started and until all the concrete is placed, the lower end of the tremie pipe shall be below the top surface of the plastic concrete. This will cause the concrete to build up from below instead of flowing out over the
surface, and thus avoid formation of laitance layers. If the charge in the tremie is lost while depositing, the tremie shall be raised above the concrete surface, and unless sealed by a check valve, it shall be re-plugged at the top end, as at the beginning, before refilling for depositing concrete.
b) Direct placement with pumps-As in the case of the tremie method, the vertical end piece of the pipeline is always inserted sufficiently deep into the previously cast concrete and should not move to the side during pumping.
c) Drop bottom bucket - The top of the bucket shall be covered with a canvas flap. The bottom doors shall open freely downward and outward when tripped. The bucket shall be filled completely and lowered slowly to avoid backwash. The bottom doors shall not be opened until the bucket rests on the surface upon which the concrete is to be deposited and when discharged, shall be withdrawn slowly until well above the concrete.
d) Bags - Bags of at least $0.028 \mathrm{~m}^{3}$ capacity of jute or other coarse cloth shall be filled about two-thirds full of concrete, the spare end turned under so that bag is square ended and securely tied. They shall be placed carefully in header and stretcher courses so that the whole mass is interlocked. Bags used for this purpose shall be free from deleterious materials.
e) Grouting-A series of round cages made from 50 mm mesh of 6 mm steel and extending over the full height to be concreted shall be prepared and laid vertically over the area to be concreted so that the distance between centres of the cages and also to the faces of the concrete shall not exceed one metre. Stone aggregate of not less than 50 mm nor more than 200 mm size shall be deposited outside the steel cages over the full area and height to be concreted with due care to prevent displacement of the cages.
A stable 1:2 cement-sand grout with a watercement ratio of not less than 0.6 and not more than 0.8 shall be prepared in a mechanical mixer and sent down under pressure (about $0.2 \mathrm{~N} / \mathrm{mm}^{2}$ ) through 38 to 50 mm diameter pipes terminating into steel cages, about 50 mm above the bottom of the concrete. As the grouting proceeds, the pipe shall be raised gradually up to a height of not more than 6000 mm above its starting level after which it may be withdrawn and placed into the next cage for further grouting by the same procedure.
After grouting the whole area for a height of about 600 mm , the same operation shall be repeated, if necessary, for the next layer of

600 mm and so on.
The amount of grout to be sent down shall be sufficient to fill all the voids which may be either ascertained or assumed as 55 percent of the volume to be concreted.
14.2.5 To minimize the formulation of laitance, great care shall be exercised not to disturb the concrete as far as possible while it is being deposited.

## 15 SAMPLING AND STRENGTH OF DESIGNED CONCRETE MIX

### 15.1 General

Samples from fresh concrete shall be taken as per IS 1199 and cubes shall be made, cured and tested at 28 days in accordance with IS 516.
15.1.1 In order to get a relatively quicker idea of the quality of concrete, optional tests on beams for modulus of rupture at $72 \pm 2 \mathrm{~h}$ or at 7 days, or compressive strength tests at 7 days may be carried out in addition to 28 days compressive strength test. For this purpose the values should be arrived at based on actual testing. In all cases, the 28 days compressive strength specified in Table 2 shall alone be the criterion for acceptance or rejection of the concrete.

### 15.2 Frequency of Sampling

### 15.2.1 Sampling Procedure

A random sampling procedure shall be adopted to ensure that each concrete batch shall have a reasonable chance of being tested that is, the sampling should be spread over the entire period of concreting and cover all mixing units.

### 15.2.2 Frequency

The minimum frequency of sampling of concrete of each grade shall be in accordance with the following:

| Quantity of Concrete in the | Number of Samples |
| :--: | :--: |
| Work, $\mathrm{m}^{3}$ |  |
| $1-5$ | 1 |
| $6-15$ | 2 |
| $16-30$ | 3 |
| $31-50$ | 4 |
| 51 and above | 4 plus one |
|  | additional sample for each additional $50 \mathrm{~m}^{3}$ or part thereof |

NOTE-At least one sample shall be taken from each shift. Where concrete is produced at continuous production unit, such as ready-mixed concrete plant, frequency of sampling may be agreed upon mutually by suppliers and purchasers.

### 15.3 Test Specimen

Three test specimens shall be made for each sample
for testing at 28 days. Additional samples may be required for various purposes such as to determine the strength of concrete at 7 days or at the time of striking the formwork, or to determine the duration of curing, or to check the testing error. Additional samples may also be required for testing samples cured by accelerated methods as described in IS 9103. The specimen shall be tested as described in IS 516.

### 15.4 Test Results of Sample

The test results of the sample shall be the average of the strength of three specimens. The individual variation should not be more than $\pm 15$ percent of the average. If more, the test results of the sample are invalid.

## 16 ACCEPTANCE CRITERIA

### 16.1 Compressive Strength

The concrete shall be deemed to comply with the strength requirements when both the following condition are met:
a) The mean strength determined from any group of four consecutive test results compiles with the appropriate limits in col 2 of Table 11.
b) Any individual test result complies with the appropriate limits in col 3 of Table 11.

### 16.2 Flexural Strength

When both the following conditions are met, me concrete complies with the specified flexural strength.
a) The mean strength determined from any group of four consecutive test results exceeds the specified characteristic strength by at least 0.3 $\mathrm{N} / \mathrm{mm}^{2}$.
b) The strength determined from any test result is not less than the specified characteristic strength less $0.3 \mathrm{~N} / \mathrm{mm}^{2}$.

### 16.3 Quantity of Concrete Represented by Strength Test Results

The quantity of concrete represented by a group of four consecutive test results shall include the batches from which the first and last samples were taken together with all intervening batches.
For the individual test result requirements given in col 2 of Table 11 or in item (b) of 16.2, only the particular batch from which the sample was taken shall be at risk.
Where the mean rate of sampling is not specified the maximum quantity of concrete that four consecutive test results represent shall be limited to $60 \mathrm{~m}^{3}$.
16.4 If the concrete is deemed not to comply persuant to 16.3 , the structural adequacy of the parts affected shall be investigated (see 17) and any consequential action as needed shall be taken.

16.5 Concrete of each grade shall be assessed separately.
16.6 Concrete is liable to be rejected if it is porous or honey-combed, its placing has been interrupted without providing a proper construction joint, the reinforcement has been displaced beyond the tolerances specified, or construction tolerances have not been met. However, the hardened concrete may be accepted after carrying out suitable remedial measures to the satisfaction of the engineer-in-charge.

## 17 INSPECTION AND TESTING OF STRUCTURES

### 17.1 Inspection

To ensure that the construction complies with the design an inspection procedure should be set up covering materials, records, workmanship and construction.
17.1.1 Tests should be made on reinforcement and the constituent materials of concrete in accordance with the relevant standards. Where applicable, use should be made of suitable quality assurance schemes.
17.1.2 Care should be taken to see that:
a) design and detail are capable of being executed to a suitable standard, with due allowance for dimensional tolerances;
b) there are clear instructions on inspection standards;
c) there are clear instructions on permissible deviations;
d) elements critical to workmanship, structural performance, durability and appearance are identified; and
e) there is a system to verify that the quality is satisfactory in individual parts of the structure, especially the critical ones.
17.2 Immediately after stripping the formwork, all concrete shall be carefully inspected and any defective work or small defects either removed or made good before concrete has thoroughly hardened.

### 17.3 Testing

In case of doubt regarding the grade of concrete used, either due to poor workmanship or based on results of cube strength tests, compressive strength tests of concrete on the basis of 17.4 and/or load test (see 17.6) may be carried out.

### 17.4 Core Test

17.4.1 The points from which cores are to be taken and the number of cores required shall be at the discretion of the engineer-in-charge and shall be representative of the whole of concrete concerned. In no case, however, shall fewer than three cores be tested.
17.4.2 Cores shall be prepared and tested as described in IS 516.
17.4.3 Concrete in the member represented by a core test shall be considered acceptable if the average equivalent cube strength of the cores is equal to at least 85 percent of the cube strength of the grade of concrete specified for the corresponding age and no individual core has a strength less than 75 percent.
17.5 In case the core test results do not satisfy the requirements of 17.4 .3 or where such tests have not been done, load test (17.6) may be resorted to.

### 17.6 Load Tests for Flexural Member

17.6.1 Load tests should be carried out as soon as

Table 11 Characteristic Compressive Strength Compliance Requirement
(Clauses 16.1 and 16.3)

| Specified <br> Grade | Mean of the Group of <br> 4 Non-Overlapping <br> Consecutive <br> Test Results in $\mathrm{N} / \mathrm{mm}^{2}$ | Individual Test <br> Results in $\mathrm{N} / \mathrm{mm}^{2}$ |
| :--: | :--: | :--: |
| (1) | (2) | (3) |
| M 15 | $\geq f_{c k}+0.825 \times$ established <br> standard deviation (rounded <br> off to nearest $0.5 \mathrm{~N} / \mathrm{mm}^{2}$ ) | $\geq f_{c k}{ }^{-4} \mathrm{~N} / \mathrm{mm}^{2}$ |
|  | or <br> $f_{c k}+3 \mathrm{~N} / \mathrm{mm}^{2}$, <br> whichever is greater |  |
| M 20 <br> or <br> above | $\geq f_{c k}+0.825 \times$ established <br> standard deviation (rounded <br> off to nearest $0.5 \mathrm{~N} / \mathrm{mm}^{2}$ ) <br> or <br> $f_{c k}+4 \mathrm{~N} / \mathrm{mm}^{2}$, whichever <br> is greater | $\geq f_{c k}{ }^{-4} \mathrm{~N} / \mathrm{mm}^{2}$ |

NOTE-In the absence of established value of standard deviation, the values given in Table 8 may be assumed, and attempt should be made to obtain results of 30 samples as early as possible to establish the value of standard deviation.

possible after expiry of 28 days from the time of placing of concrete.
17.6.2 The structure should be subjected to a load equal to full dead load of the structure plus 1.25 times the imposed load for a period of 24 h and then the imposed load shall be removed.

NOTE-Dead load includes self weight of the structural members plus weight of finishes and walls or partitions, if any, as considered in the design.
17.6.3 The deflection due to imposed load only shall be recorded. If within 24 h of removal of the imposed load, the structure does not recover at least 75 percent of the deflection under superimposed load, the test may be repeated after a lapse of 72 h . If the recovery is less than 80 percent, the structure shall be deemed to be unacceptable.
17.6.3.1 If the maximum deflection in mm, shown during 24 h under load is less than $40 l^{2} / D$, where $l$ is the effective span in $m$; and $D$, the overall depth of the section in mm, it is not necessary for the recovery to be measured and the recovery provisions of 17.6 .3 shall
not apply.

### 17.7 Members Other Than Flexural Members

Members other than flexural members should be. preferably investigated by analysis.

### 17.8 Non-destructive Tests

Non-destructive tests are used to obtain estimation of the properties of concrete in the structure. The methods adopted include ultrasonic pulse velocity [see IS 13311 (Part 1)] and rebound hammer [IS 13311 (Part 2)], probe penetration, pullout and maturity. Nondestructive tests provide alternatives to core tests for estimating the strength of concrete in a structure, or can supplement the data obtained from a limited number of cores. These methods are based on measuring a concrete property that bears some relationship to strength. The accuracy of these methods, in part, is determined by the degree of correlation between strength and the physical quality measured by the non-destructive tests.
Any of these methods may be adopted, in which case the acceptance criteria shall be agreed upon prior to testing.

# SECTION 3 GENERAL DESIGN CONSIDERATION 

## 18 BASES FOR DESIGN

### 18.1 Aim of Design

The aim of design is the achievement of an acceptable probability that structures being designed will perform satisfactorily during their intended life. With an appropriate degree of safety, they should sustain all the loads and deformations of normal construction and use and have adequate durability and adequate resistance to the effects of misuse and fire.

### 18.2 Methods of Design

18.2.1 Structure and structural elements shall normally be designed by Limit State Method. Account should be taken of accepted theories, experiment and experience and the need to design for durability. Calculations alone do not produce safe, serviceable and durable structures. Suitable materials, quality control, adequate detailing and good supervision are equally important.
18.2.2 Where the Limit State Method can not be conveniently adopted, Working Stress Method (see Annex B) may be used.

### 18.2.3 Design Based on Experimental Basis

Designs based on experimental investigations on models or full size structure or element may be accepted if they satisfy the primary requirements of 18.1 and subject to experimental details and the analysis connected therewith being approved by the engineer-in-charge.
18.2.3.1 Where the design is based on experimental investigation on full size structure or element, load tests shall be carried out to ensure the following:
a) The structure shall satisfy the requirements for deflection (see 23.2) and cracking (see 35.3.2) when subjected to a load for 24 h equal to the characteristic load multiplied by $1.33 \gamma_{i}$, where $\gamma_{i}$ shall be taken from Table 18 , for the limit state of serviceability. If within 24 h of the removal of the load, the structure does not show a recovery of at least 75 percent of the maximum deflection shown during the 24 h under the load, the test loading should be repeated after a lapse of 72 h . The recovery after the second test should be at least 75 percent of the maximum deflection shown during the second test.
NOTE-If the maximum deflection in mm, shown during 24 h under load is less than $40 \mathrm{~J} / \mathrm{J}$ where $I$ is the effective span in $m$; and $D$ is the overall depth of the section in mm , it is not necessary for the recovery to be measured.
b) The structure shall have adequate strength to sustain for 24 h , a total load equal to the characteristic load multiplied by $1.33 \gamma_{i}$ where $\gamma_{i}$ shall
be taken from Table 18 for the limit state of collapse.

### 18.3 Durability, Workmanship and Materials

It is assumed that the quality of concrete, steel and other materials and of the workmanship, as verified by inspections, is adequate for safety, serviceability and durability.

### 18.4 Design Process

Design, including design for durability, construction and use in service should be considered as a whole. The realization of design objectives requires compliance with clearly defined standards for materials, production, workmanship and also maintenance and use of structure in service.

## 19 LOADS AND FORCES

### 19.1 General

In structural design, account shall be taken of the dead, imposed and wind loads and forces such as those caused by earthquake, and effects due to shrinkage, creep, temperature, etc, where applicable.

### 19.2 Dead Loads

Dead loads shall be calculated on the basis of unit weights which shall be established taking into consideration the materials specified for construction.
19.2.1 Alternatively, the dead loads may be calculated on the basis of unit weights of materials given in IS 875 (Part 1). Unless more accurate calculations are warranted, the unit weights of plain concrete and reinforced concrete made with sand and gravel or crushed natural stone aggregate may be taken as $24 \mathrm{kN} / \mathrm{m}^{3}$ and $25 \mathrm{kN} / \mathrm{m}^{3}$ respectively.

### 19.3 Imposed Loads, Wind Loads and Snow Loads

Imposed loads, wind loads and snow loads shall be assumed in accordance with IS 875 (Part 2), IS 875 (Part 3) and IS 875 (Part 4) respectively.

### 19.4 Earthquake Forces

The earthquake forces shall be calculated in accordance with IS 1893.

### 19.5 Shrinkage, Creep and Temperature Effects

If the effects of shrinkage, creep and temperature are liable to affect materially the safety and serviceability of the structure, these shall be taken into account in the calculations (see 6.2.4, 6.2.5 and 6.2.6) and IS 875 (Part 5).
19.5.1 In ordinary buildings, such as low rise dwellings whose lateral dimension do not exceed 45 m , the

effects due to temperature fluctuations and shrinkage and creep can be ignored in design calculations.

### 19.6 Other Forces and Effects

In addition, account shall be taken of the following forces and effects if they are liable to affect materially the safety and serviceability of the structure:
a) Foundation movement (see IS 1904),
b) Elastic axial shortening,
c) Soil and fluid pressures [see IS 875 (Part 5)],
d) Vibration,
e) Fatigue,
f) Impact [see IS 875 (Part 5)],
g) Erection loads [see IS 875 (Part 2)], and
h) Stress concentration effect due to point load and the like.

### 19.7 Combination of Loads

The combination of loads shall be as given in IS 875 (Part 5).

### 19.8 Dead Load Counteracting Other Loads and Forces

When dead load counteracts the effects due to other loads and forces in structural member or joint, special care shall be exercised by the designer to ensure adequate safety for possible stress reversal.

### 19.9 Design Load

Design load is the load to be taken for use in the appropriate method of design; it is the characteristic load in case of working stress method and characteristic load with appropriate partial safety factors for limit state design.

## 20 STABILITY OF THE STRUCTURE

### 20.1 Overturning

The stability of a structure as a whole against overturning shall be ensured so that the restoring moment shall be not less than the sum of 1.2 times the maximum overturning moment due to the characteristic dead load and 1.4 times the maximum overturning moment due to the characteristic imposed loads. In cases where dead load provides the restoring moment, only 0.9 times the characteristic dead load shall be considered. Restoring moment due to imposed loads shall be ignored.
20.1.1 The anchorages or counterweights provided for overhanging members (during construction and service) should be such that static equilibrium should remain, even when overturning moment is doubled.

### 20.2 Sliding

The structure shall have a factor against sliding of not less than 1.4 under the most adverse combination of the applied characteristic forces. In this case only 0.9 times the characteristic dead load shall be taken into account.

### 20.3 Probable Variation in Dead Load

To ensure stability at all times, account shall be taken of probable variations in dead load during construction, repair or other temporary measures. Wind and seismic loading shall be treated as imposed loading.

### 20.4 Moment Connection

In designing the framework of a building provisions shall be made by adequate moment connections or by a system of bracings to effectively transmit all the horizontal forces to the foundations.

### 20.5 Lateral Sway

Under transient wind load the lateral sway at the top should not exceed $H / 500$, where $H$ is the total height of the building. For seismic loading, reference should be made to IS 1893.

## 21 FIRE RESISTANCE

21.1 A structure or structural element required to have fire resistance should be designed to possess an appropriate degree of resistance to flame penetration; heat transmission and failure. The fire resistance of a structural element is expressed in terms of time in hours in accordance with IS 1641. Fire resistance of concrete elements depends upon details of member size, cover to steel reinforcement detailing and type of aggregate (normal weight or light weight) used in concrete. General requirements for fire protection are given in IS 1642.
21.2 Minimum requirements of concrete cover and member dimensions for normal-weight aggregate concrete members so as to have the required fire resistance shall be in accordance with 26.4 .3 and Fig. 1 respectively.
21.3 The reinforcement detailing should reflect the changing pattern of the structural section and ensure that both individual elements and the structure as a whole contain adequate support, ties, bonds and anchorages for the required fire resistance.
21.3.1 Additional measures such as application of fire resistant finishes, provision of fire resistant false ceilings and sacrificial steel in tensile zone, should be adopted in case the nominal cover required exceeds 40 mm for beams and 35 mm for slabs, to give protection against spalling.
21.4 Specialist literature may be referred to for determining fire resistance of the structures which have not been covered in Fig. 1 or Table 16A.

![chunk-0-img-0.jpeg](chunk-0-img-0.jpeg)

COLUMNS

| Fire <br> Resistance $h$ | Minimum <br> Beam <br> Width <br> $b$ | Rib <br> Width <br> of Slabs <br> $b_{w}$ | Minimum <br> Thickness <br> of Floors <br> $D$ | Column Dimension (b or D) |  |  | Minimum Wall Thickness |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  |  | Fully <br> Exposed | $50 \%$ <br> Exposed | One <br> Face <br> Exposed | $p<0.4 \%$ | $0.4 \% \leq p \leq 1 \%$ | $p>1 \%$ |
|  | mm | mm | mm | mm | mm | mm | mm | mm | mm |
| 0.5 | 200 | 125 | 75 | 150 | 125 | 100 | 150 | 100 | 100 |
| 1 | 200 | 125 | 95 | 200 | 160 | 120 | 150 | 120 | 100 |
| 1.5 | 200 | 125 | 110 | 250 | 200 | 140 | 175 | 140 | 100 |
| 2 | 200 | 125 | 125 | 300 | 200 | 160 | - | 160 | 100 |
| 3 | 240 | 150 | 150 | 400 | 300 | 200 | - | 200 | 150 |
| 4 | 280 | 175 | 170 | 450 | 350 | 240 | - | 240 | 180 |

NOTES
1 These minimum dimensions relate specifically to the covers given in Table 16A.
$2 p$ is the percentage of steel reinforcement.
Fig. 1 Minimum Dimensions of Reinforced Concrete Members for Fire Resistance.

## 22 ANALYSIS

### 22.1 General

All structures may be analyzed by the linear elastic theory to calculate internal actions produced by design loads. In lieu of rigorous elastic analysis, a simplified analysis as given in 22.4 for frames and as given in 22.5 for continuous beams may be adopted.

### 22.2 Effective Span

Unless otherwise specified, the effective span of a member shall be as follows:
a) Simply Supported Beam or Slab-The effective span of a member that is not built integrally with its supports shall be taken as clear span plus the effective depth of slab or beam or centre to centre of supports, whichever is less.

b) Continuous Beam or Slab - In the case of continuous beam or slab, if the width of the support is less than $1 / 12$ of the clear span, the effective span shall be as in 22.2 (a). If the supports are wider than $1 / 12$ of the clear span or 600 mm whichever is less, the effective span shall be taken as under:

1) For end span with one end fixed and the other continuous or for intermediate spans, the effective span shall be the clear span between supports;
2) For end span with one end free and the other continuous, the effective span shall be equal to the clear span plus half the effective depth of the beam or slab or the clear span plus half the width of the discontinuous support, whichever is less;
3) In the case of spans with roller or rocket bearings, the effective span shall always be the distance between the centres of bearings.
c) Cantilever - The effective length of a cantilever shall be taken as its length to the face of the support plus half the effective depth except where it forms the end of a continuous beam where the length to the centre of support shall be taken.
d) Frames - In the analysis of a continuous frame, centre to centre distance shall be used.

### 22.3 Stiffness

### 22.3.1 Relative Stiffness

The relative stiffness of the members may be based on the moment of inertia of the section determined on the basis of any one of the following definitions:
a) Gross section - The cross-section of the member ignoring reinforcement;
b) Transformed section - The concrete crosssection plus the area of reinforcement transformed on the basis of modular ratio (see B-1.3); or
c) Cracked section - The area of concrete in compression plus the area of reinforcement transformed on the basis of modular ratio.

The assumptions made shall be consistent for all the members of the structure throughout any analysis.
22.3.2 For deflection calculations, appropriate values of moment of inertia as specified in Annex C should be used.

### 22.4 Structural Frames

The simplifying assumptions as given in 22.4.1 to 22.4 .3 may be used in the analysis of frames.

### 22.4.1 Arrangement of Imposed Load

a) Consideration may be limited to combinations of:

1) Design dead load on all spans with full design imposed load on two adjacent spans; and
2) Design dead load on all spans with full design imposed load on alternate spans.
b) When design imposed load does not exceed three-fourths of the design dead load, the load arrangement may be design dead load and design imposed load on all the spans.
NOTE - For beams and slabs continuous over support 22.4.1(a) may be assumed.

### 22.4.2 Substitute Frame

For determining the moments and shears at any floor or roof level due to gravity loads, the beams at that level together with columns above and below with their far ends fixed may be considered to constitute the frame.
22.4.2.1 Where side sway consideration becomes critical due to unsymmetry in geometry or loading, rigorous analysis may be required.
22.4.3 For lateral loads, simplified methods may be used to obtain the moments and shears for structures that are symmetrical: For unsymmetrical or very tall structures, more rigorous methods should be used.

### 22.5 Moment and Shear Coefficients for Continuous Beams

22.5.1 Unless more exact estimates are made, for beams of uniform cross-section which support substantially uniformly distributed loads over three or more spans which do not differ by more than 15 percent of the longest, the bending moments and shear forces used in design may be obtained using the coefficients given in Table 12 and Table 13 respectively.
For moments at supports where two unequal spans meet or in case where the spans are not equally loaded, the average of the two values for the negative moment at the support may be taken for design.
Where coefficients given in Table 12 are used for calculation of bending moments, redistribution referred to in 22.7 shall not be permitted.

### 22.5.2 Beams and Slabs Over Free End Supports

Where a member is built into a masonry wall which develops only partial restraint, the member shall be designed to resist a negative moment at the face of the support of WI/24 where $W$ is the total design load and $l$ is the effective span, or such other restraining moment as may be shown to be applicable. For such a condition shear coefficient given in Table 13 at the end support may be increased by 0.05 .

Table 12 Bending Moment Coefficients
(Clause 22.5.1)

| Type of Load | Span Moments |  | Support Moments |  |
| :--: | :--: | :--: | :--: | :--: |
|  | Near Middle of End Span | At Middle of Interior Span | At Support Next to the End Support | At Other Interior Supports |
| (1) | (2) | (3) | (4) | (5) |
| Dead load and imposed load (fixed) | $+\frac{1}{12}$ | $+\frac{1}{16}$ | $-\frac{1}{10}$ | $-\frac{1}{12}$ |
| Imposed load (not fixed) | $+\frac{1}{10}$ | $+\frac{1}{12}$ | $-\frac{1}{9}$ | $-\frac{1}{9}$ |

NOTE - For obtaining the bending moment, the coefficient shall be multiplied by the total design load and effective span.

Table 13 Shear for Coefficients
(Clauses 22.5.1 and 22.5.2)

| Type of Load | At End Support | At Support Next to the End Support |  | At All Other Interior Supports |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Outer Side | Inner Side |  |
| (1) | (2) | (3) | (4) | (5) |
| Dead load and imposed load (fixed) | 0.4 | 0.6 | 0.55 | 0.5 |
| Imposed load (not fixed) | 0.45 | 0.6 | 0.6 | 0.6 |

NOTE - For obtaining the shear force, the coefficient shall be multiplied by the total design load.

### 22.6 Critical Sections for Moment and Shear

22.6.1 For monolithic construction, the moments computed at the face of the supports shall be used in the design of the members at those sections. For nonmonolithic construction the design of the member shall be done keeping in view 22.2.

### 22.6.2 Critical Section for Shear

The shears computed at the face of the support shall be used in the design of the member at that section except as in 22.6.2.1.
22.6.2.1 When the reaction in the direction of the applied shear introduces compression into the end region of the member, sections located at a distance less than $d$ from the face of the support may be designed for the same shear as that computed at distance $d$ (see Fig. 2).

NOTE-The above clauses are applicable for beams generally carrying uniformly distributed load or where the principal load is located farther than $2 d$ from the face of the support.

### 22.7 Redistribution of Moments

Redistribution of moments may be done in accordance with 37.1 .1 for limit state method and in accordance with B-1.2 for working stress method. However, where simplified analysis using coefficients is adopted, redistribution of moments shall not be done.

## 23 BEAMS

### 23.0 Effective Depth

Effective depth of a beam is the distance between the centroid of the area of tension reinforcement and the maximum compression fibre, excluding the thickness of finishing material not placed monolithically with the member and the thickness of any concrete provided to allow for wear. This will not apply to deep beams.

### 23.1 T-Beams and L-Beams

### 23.1.1 General

A slab which is assumed to act as a compression flange of a T-beam or L-beam shall satisfy the following:
a) The slab shall be cast integrally with the web, or the web and the slab shall be effectively bonded together in any other manner; and
b) If the main reinforcement of the slab is parallel to the beam, transverse reinforcement shall be provided as in Fig. 3; such reinforcement shall not be less than 60 percent of the main reinforcement at mid span of the slab.

### 23.1.2 Effective Width of Flange

In the absence of more accurate determination, the effective width of flange may be taken as the following

![chunk-0-img-1.jpeg](chunk-0-img-1.jpeg)

Fig. 2 Typical Support Conditions for Locating Factoried Shear Force
but in no case greater than the breadth of the web plus half the sum of the clear distances to the adjacent beams on either side.
a) For T-beams, $b_{\mathrm{f}}=\frac{l_{0}}{6}+b_{\mathrm{w}}+6 D_{\mathrm{f}}$
b) For L-beams, $b_{\mathrm{f}}=\frac{l_{0}}{12}+b_{\mathrm{w}}+3 D_{\mathrm{f}}$
c) For isolated beams, the effective flange width shall be obtained as below but in no case greater than the actual width:

$$
\begin{aligned}
& \mathrm{T}-\text { beam, } \mathrm{b}_{\mathrm{f}}=\frac{1_{\mathrm{o}}}{\left(\frac{1_{\mathrm{o}}}{\mathrm{~b}}\right)+4}+\mathrm{b}_{\mathrm{w}} \\
& \mathrm{~L}-\text { beam, } \mathrm{b}_{\mathrm{f}}=\frac{0.5 \mathrm{l}_{\mathrm{o}}}{\left(\frac{1_{\mathrm{o}}}{\mathrm{~b}}\right)+4}+\mathrm{b}_{\mathrm{w}}
\end{aligned}
$$

where
$b_{\mathrm{f}}=$ effective width of flange,
$l_{0}=$ distance between points of zero moments in the beam,
$b_{\mathrm{w}}=$ breadth of the web,
$D_{\mathrm{i}}=$ thickness of flange, and
$b=$ actual width of the flange.
NOTE - For continuous beams and frames, ' $l_{0}$ ' may be assumed as 0.7 times the effective span.

### 23.2 Control of Deflection

The deflection of a structure or part thereof shall not adversely affect the appearance or efficiency of the
structure or finishes or partitions. The deflection shall generally be limited to the following:
a) The final deflection due to all loads including the effects of temperature, creep and shrinkage and measured from the as-cast level of the supports of floors, roofs and all other horizontal members, should not normally exceed span/250.
b) The deflection including the effects of temperature, creep and shrinkage occurring after erection of partitions and the application of finishes should not normally exceed span/350 or 20 mm whichever is less.
23.2.1 The vertical deflection limits may generally be assumed to be satisfied provided that the span to depth ratios are not greater than the values obtained as below:
a) Basic values of span to effective depth ratios for spans up to 10 m :

Cantilever
7
Simply supported
20
Continuous
26
b) For spans above 10 m , the values in (a) may be multiplied by $10 /$ span in metres, except for cantilever in which case deflection calculations should be made.
c) Depending on the area and the stress of steel for tension reinforcement, the values in (a) or (b) shall be modified by multiplying with the modification factor obtained as per Fig. 4.
d) Depending on the area of compression reinforcement, the value of span to depth ratio be further modified by multiplying with the modification factor obtained as per Fig. 5.

![chunk-0-img-2.jpeg](chunk-0-img-2.jpeg)

# SECTION XX 

Fig. 3 Transverse Reinforcement in Flange of T-Beam When Main Reinforcement of Slab is Parallel to the Beam
e) For flanged beams, the values of (a) or (b) be modified as per Fig. 6 and the reinforcement percentage for use in Fig. 4 and 5 should be based
on area of section equal to $b_{1} d$.
NOTE-When deflections are required to be calculated, the method given in Annex C may be used.
![chunk-0-img-3.jpeg](chunk-0-img-3.jpeg)

$$
f_{c}=0.58 f_{r} \frac{\text { Areaof cross-section of steel required }}{\text { Areaof cross-section of steel provided }}
$$

Fig. 4 Modification Factor for Tension Reinforcement

![chunk-0-img-4.jpeg](chunk-0-img-4.jpeg)

Fig. 5 Modification Factor for Compression Reinforcement
![chunk-0-img-5.jpeg](chunk-0-img-5.jpeg)

Fig. 6 Reduction Factors for Ratios of Span to Effective Depth for Flanged Beams

### 23.3 Slenderness Limits for Beams to Ensure Lateral Stability

A simply supported or continuous beam shall be so proportioned that the clear distance between the lateral
restraints does not exceed $60 b$ or $\frac{250 b^{2}}{d}$ whichever is less, where $d$ is the effective depth of the beam and $b$ the breadth of the compression face midway between the lateral restraints.
For a cantilever, the clear distance from the free end of the cantilever to the lateral restraint shall not exceed $25 b$ or $\frac{100 b^{2}}{d}$ whichever is less.

## 24 SOLID SLABS

### 24.1 General

The provisions of 23.2 for beams apply to slabs also.

## NOTES

1 For slabs spanning in two directions, the shorter of the two spans should be used for calculating the span to effective depth ratios.
2 For two-way slabs of shorter spans (up to 3.5 m ) with mild steel reinforcement, the span to overall depth ratios given below may generally be assumed to satisfy vertical deflection limits for loading class up to $3 \mathrm{kN} / \mathrm{m}^{2}$.
Simply supported slabs 35
Continuous slabs 40
For high strength deformed bars of grade Fe 415 , the values given above should be multiplied by 0.8 .

### 24.2 Slabs Continuous Over Supports

Slabs spanning in one direction and continuous over supports shall be designed according to the provisions applicable to continuous beams.

### 24.3 Slabs Monolithic with Supports

Bending moments in slabs (except flat slabs) constructed monolithically with the supports shall be calculated by taking such slabs either as continuous over supports and



