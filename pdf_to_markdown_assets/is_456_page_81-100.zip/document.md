# ANNEX B 

(Clauses 18.2.2, 22.3.1, 22.7, 26.2.1 and 32.1)

## STRUCTURAL DESIGN (WORKING STRESS METHOD)

## B-I GENERAL

## B-1.1 General Design Requirements

The general design requirements of Section 3 shall apply to this Annex.

## B-1.2 Redistribution of Moments

Except where the simplified analysis using coefficients (see 22.5) is used, the moments over the supports for any assumed arrangement of loading, including the dead load moments may each be increased or decreased by not more than 15 percent, provided that these modified moments over the supports are used for the calculation of the corresponding moments in the spans.

## B-1.3 Assumptions for Design of Members

In the methods based on elastic theory, the following assumptions shall be made:
a) At any cross-section, plane sections before bending remain plain after bending.
b) All tensile stresses are taken up by reinforcement and none by concrete, except as otherwise specifically permitted.

| Grade of <br> Concrete | M 10 | M 15 | M 20 | M 25 | M 25 | M 30 | M 35 | M 40 | M 45 | M 50 |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Tensile Stress, <br> $\mathrm{N} / \mathrm{mm}^{2}$ | 1.2 | 2.0 | 2.8 | 3.2 | 3.6 | 4.0 | 4.4 | 4.8 | 5.2 |  |

The tensile stress shall be calculated as $\frac{F_{1}}{A_{c}+m A_{M}}$ where
$F_{1}=$ total tension on the member minus pretension in steel, if any, before concreting;
$A_{c}=$ cross-sectional area of concrete excluding any finishing material and reinforcing steel;
$m=$ modular ratio; and
$A_{\mathrm{st}}=$ cross-sectional area of reinforcing steel in tension.

## B-2.1.2 Bond Stress for Deformed Bars

In the case of deformed bars conforming to IS 1786, the bond stresses given in Table 21 may be increased by 60 percent.

## B-2.2 Permissible Stresses in Steel Reinforcement

Permissible stresses in steel reinforcement shall not exceed the values specified in Table 22.
B-2.2.1 In flexural members the value of $\sigma_{x t}$ given in Table 22 is applicable at the centroid of the tensile reinforcement subject to the condition that when more than one layer of tensile reinforcement is provided, the stress at the centroid of the outermost layer shall not exceed by more than 10 percent the value given in Table 22.

## B-2.3 Increase in Permissible Stresses

Where stresses due to wind (or earthquake) temperature and shrinkage effects are combined with those due to dead, live and impact load, the stresses specified in Tables 21, 22 and 23 may be exceeded upto a limit of $33 \frac{1}{3}$ percent. Wind and seismic forces need not be considered as acting simultaneously.

Table 21 Permissible Stresses in Concrete
(Clauses B-1.3, B-2.1, B-2.1.2, B-2.3 and B-4.2)
All values in N/mm².

| Grade of <br> Concre | Permissible Stress in Compression |  | Permissible Stress in Bond (Average) for Plain Bars in Tension |
| :--: | :--: | :--: | :--: |
|  | Bending | Direct |  |
| (1) | (2) | (3) | (4) |
|  | $\sigma_{\mathrm{ctc}}$ | $\sigma_{\mathrm{cc}}$ | $\tau_{\mathrm{cc}}$ |
|  | 3.0 | 2.5 | - |
| M 10 | 5.0 | 4.0 | 0.6 |
| M 15 | 7.0 | 5.0 | 0.8 |
| M 20 | 8.5 | 6.0 | 0.9 |
| M 25 | 10.0 | 8.0 | 1.0 |
| M 30 | 11.5 | 9.0 | 1.1 |
| M 35 | 13.0 | 10.0 | 1.2 |
| M 40 | 14.5 | 11.0 | 1.3 |
| M 45 | 16.0 | 12.0 | 1.4 |
| M 50 |  |  |  |

NOTES
1 The values of permissible shear stress in concrete are given in Table 23.
2 The bond stress given in col 4 shall be increased by 25 percent for bars in compression.

## B-3 PERMISSIBLE LOADS IN COMPRESSION MEMBERS

## B-3.1 Pedestals and Short Columns with Lateral

Ties
The axial load $P$ permissible on a pedestal or short column reinforced with longitudinal bars and lateral ties shall not exceed that given by the following equation:

$$
P=\sigma_{c c} A_{c}+\sigma_{s c} A_{s c}
$$

where
$\sigma_{c c}=$ permissible stress in concrete in direct compression,
$A_{c}=$ cross-sectional area of concrete excluding any finishing material and reinforcing steel,
$\sigma_{s c}=$ permissible compressive stress for column bars, and
$A_{s c}=$ cross-sectional area of the longitudinal steel.
NOTE - The minimum eccentricity mentioned in 25.4 may be deemed to be incorporated in the above equation.

## B-3.2 Short Columns with Helical Reinforcement

The permissible load for columns with helical reinforcement satisfying the requirement of 39.4 .1 shall be 1.05 times the permissible load for similar member with lateral ties or rings..

## B-3.3 Long Columns

The maximum permissible stress in a reinforced concrete column or part thereof having a ratio of effective column length to least lateral dimension above 12 shall not exceed that which results from the
multiplication of the appropriate maximum permissible stress as specified under B-2.1 and B-2.2 by the coefficient $C_{t}$ given by the following formula:

$$
C_{\mathrm{r}}=1.25-\frac{i_{\mathrm{ef}}}{48 b}
$$

where
$C_{t}=$ reduction coefficient;
$i_{\text {ef }}=$ effective length of column; and
$b=$ least lateral dimension of column; for column with helical reinforcement, $b$ is the diameter of the core.
For more exact calculations, the maximum permissible stresses in a reinforced concrete column or part thereof having a ratio of effective column length to least lateral radius of gyration above 40 shall not exceed those which result from the multiplication of the appropriate maximum permissible stresses specified under B-2.1 and B-2.2 by the coefficient $C_{t}$ given by the following formula:

$$
C_{\mathrm{r}}=1.25-\frac{i_{\mathrm{ef}}}{160 i_{\min }}
$$

where $i_{\text {min }}$ is the least radius of gyration.

## B-3.4 Composite Columns

a) Allowable load - The allowable axial load $P$ on a composite column consisting of structural steel or cast-iron column thoroughly encased in concrete reinforced with both longitudinal and spiral reinforcement, shall not exceed that given by the following formula:

$$
P=\sigma_{c c} A_{c}+\sigma_{s c} A_{s c}+\sigma_{m c} A_{m}
$$

Table 22 Permissible Stresses in Steel Reinforcement

|  | (Clauses B-2.2, B-2.2.1, B-2.3 and B-4.2) |  |  |
| :--: | :--: | :--: | :--: |
| Sl <br> No. | Type of Stress in Steel Reinforcement | Permissibls Stresses in N/mm ${ }^{2}$ |  |
|  |  | Mild Steel Bars Conforming to Grade 1 of IS 432 (Part 1) | Medium Tensile Steel Conforming to IS 432 (Part 1) |
| (1) | (2) | (3) | (4) |
| i) | Tension $\left(\sigma_{w}\right.$ or $\left.\sigma_{w}\right)$ <br> a) Up to and including $\geq 0 \mathrm{~mm}$ <br> b) Over 20 mm <br> c) Compression in column bars $\left(\sigma_{w}\right)$ | 140 <br> 130 | Half the guaranteed yield stress subject to a maximum of 190 |
| ii) | Compression in bars in a beam or slab when the compressive resistance of the concrete is taken into account | 130 | 130 |

The calculated compressive stress in the surrounding concrete multiplied by 1.5 times the modular ratio or $\sigma_{w}$ whichever is lower
iv) Compression in bars in a beam or slab where the compressive resistance of the concrete is not taken into account:
a) Up to and including 20 mm
b) Over 20 mm

| 140 | Half the guaranteed <br> yield stress subject <br> to a maximum of 190 |
| :-- | :-- |

NOTES
1 For high yield strength deformed bars of Grade Fe 500 the permissible stress in direct tension and flexural tension shall be $0.55 f_{y}$. The permissible stresses for shear and compression reinforcement shall be as for Grade Fe 415.
2 For welded wire fabric conforming to IS 1566, the permissible value in tension $\sigma_{w}$ is $230 \mathrm{~N} / \mathrm{mm}^{2}$.
3 For the purpose of this standard, the yield stress of steels for which there is no clearly defined yield point should be taken to be 0.2 percent proof stress.

4 When mild steel conforming to Grade II of IS 432 (Part 1) is used, the permissible stresses shall be 90 percent of the permissible stresses in col 3, or if the design details have already been worked out on the basis of mild steel conforming to Grade I of IS 432 (Part 1); the area of reinforcement shall be increased by 10 percent of that required for Grade I steel.
where
$\sigma_{c c}=$ permissible stress in concrete in direct compression;
$A_{c}=$ net area of concrete section; which is equal to the gross area of the concrete section $-A_{c c}-A_{w}$;
$\sigma_{w}=$ permissible compressive stress for column bars;
$A_{w}=$ cross-sectional area of longitudinal bar reinforcement;
$\sigma_{n c}=$ allowable unit stress in metal core, not to exceed $125 \mathrm{~N} / \mathrm{mm}^{2}$ for a steel core, or $70 \mathrm{~N} / \mathrm{mm}^{2}$ for a cast iron core; and
$A_{m}=$ the cross-sectional area of the steel or cast iron core.
b) Metal core and reinforcement - The crosssectional area of the metal core shall not exceed

20 percent of the gross area of the column. If a hollow metal core is used, it shall be filled with concrete. The amount of longitudinal and spiral reinforcement and the requirements as to spacing of bars, details of splices and thickness of protective shell outside the spiral, shall conform to require- ments of 26.5.3. A clearance of at least 75 mm shall be maintained between the spiral and the metal core at all points, except that when the core consists of a structural steel H -column, the minimum clearance may be reduced to 50 mm .
c) Splices and connections of metal cores - Metal cores in composite columns shall be accurately milled at splices and positive provisions shall be made for alignment of one core above another. At the column base, provisions shall be

made to transfer the load to the footing at safe unit stresses in accordance with 34. The base of the metal section shall be designed to transfer the load from the entire composite columns to the footing, or it may be designed to transfer the load from the metal section only, provided it is placed in the pier or pedestal as to leave ample section of concrete above the base for the transfer of load from the reinforced concrete section of the column by means of bond on the vertical reinforcement and by direct compression on the concrete. Transfer of loads to the metal core shall be provided for by the use of bearing members, such as billets, brackets or other positive connections, these shall be provided at the top of the metal core and at intermediate floor levels where required. The column as a whole shall satisfy the requirements of formula given under (a) at any point; in addition to this, the reinforced concrete portion shall be designed to carry, according to B-3.1 or B-3.2 as the case may be, all floor loads brought into the column at levels between the metal brackets or connections. In applying the formulae under B-3.1 or B-3.2 the gross area of column shall be taken to be the area of the concrete section outside the metal core, and the allowable load on the reinforced concrete section shall be further limited to $0.28 f_{\mathrm{ck}}$ times gross sectional area of the column.
d) Allowable Load on Metal Core Only - The metal core of composite columns shall be designed to carry safely any construction or other loads to be placed upon them prior to their encasement in concrete.

## B-4 MEMBERS SUBJECTED TO COMBINED AXIAL LOAD AND BENDING

## B-4.1 Design Based on Uncracked Section

A member subjected to axial load and bending (due to eccentricity of load, monolithic construction, lateral forces, etc) shall be considered safe provided the following conditions are satisfied:
a) $\frac{\sigma_{\mathrm{cc}, \text { col }}}{\sigma_{\mathrm{cc}}}+\frac{\sigma_{\mathrm{cbc}, \mathrm{cal}}}{\sigma_{\mathrm{cbc}}} \leq 1$
where
$\sigma_{\mathrm{cc}, \mathrm{ml}} \quad=$ calculated direct compressive stress in concrete,
$\sigma_{\mathrm{cc}} \quad=$ permissible axial compressive stress in concrete,
$\sigma_{\mathrm{cbc}, \mathrm{cal}}=$ calculated bending compressive stress in concrete, and
$\sigma_{\mathrm{cbc}} \quad=$ permissible bending compressive stress in concrete.
b) The resultant tension in concrete is not greater than 35 percent and 25 percent of the resultant compression for biaxial and uniaxial bending respectively, or does not exceed three-fourths, the 7 day modulus of rupture of concrete.

## NOTES

$1 \sigma_{\text {cocol }}=\frac{P}{A_{c}+1.5 m A_{m}}$ for columns with ties where $P, A_{c}$ and $A_{m}$ defined in B-3.1 and $m$ is the modular ratio.
$2 \sigma_{\mathrm{cc}, \mathrm{col}}=\frac{M}{Z}$ where $M$ equals the moment and $Z$ equals modulus of section. In the case of sections subject to moments in two directions, the stress shall be calculated separately and added algebraically.

## B-4.2 Design Based on Cracked Section

If the requirements specified in B-4.1 are not satisfied, the stresses in concrete and steel shall be calculated by the theory of cracked section in which the tensile resistance of concrete is ignored. If the calculated stresses are within the permissible stress specified in Tables 21, 22 and 23 the section may be assumed to be safe.

NOTE - The maximum stress in concrete and steel may be found from tables and charts based on the cracked section theory or directly by determining the no-stress line which should satisfy the following requirements:
a) The direct load should be equal to the algebraic sum of the forces on concrete and steel,
b) The moment of the external loads about any reference line should be equal to the algebraic sum of the moment of the forces in concrete (ignoring the tensile force in concrete) and steel about the same line, and
c) The moment of the external loads about any other reference lines should be equal to the algebraic sum of the moment of the forces in concrete (ignoring the tensile force in concrete) and steel about the same line.

## B-4.3 Members Subjected to Combined Direct Load and Flexure

Members subjected to combined direct load and flexure and shall be designed by limit state method as in 39.5 after applying appropriate load factors as given in Table 18.

## B-5 SHEAR

## B-5.1 Nominal Shear Stress

The nominal shear stress $\tau_{v}$ in beams or slabs of uniform depth shall be calculated by the following equation:

$$
\tau_{v}=\frac{V}{b d}
$$

where
$V=$ shear force due to design loads,

$b=$ breadth of the member, which for flanged sections shall be taken as the breadth of the web, and
$d=$ effective depth.

## B-5.1.1 Beams of Varying Depth

In the case of beams of varying depth, the equation shall be modified as:

$$
\tau_{v}=\frac{V \pm \frac{M \tan \beta}{d}}{b d}
$$

where
$\tau_{v}, V, b$ and $d$ are the same as in B-5.1,
$M=$ bending moment at the section, and
$\beta=$ angle between the top and the bottom edges of the beam.

The negative sign in the formula applies when the bending moment $M$ increases numerically in the same direction as the effective depth $d$ increases, and the positive sign when the moment decreases numerically in this direction.

## B-5.2 Design Shear Strength of Concrete

B-5.2.1 The permissible shear stress in concrete in beams without shear reinforcement is given in Table 23.

B-5.2.1.1 For solid slabs the permissible shear stress in concrete shall be $k \tau_{c}$ where $k$ has the value given below:

| Overall depth 300 or 275 |  |  |  |  |  |  | 250225200175150 or |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| of slab, mm | more |  |  |  |  |  | less |
| k |  |  |  |  |  | 1.001.05 | 1.101.151.201.251.30 |

NOTE - This does not apply to flat slabs for which 31.6 shall apply.

## B-5.2.2 Shear Strength of Members Under Axial Compression

For members subjected to axial compression $P$, the permissible shear stress in concrete $\tau_{c}$ given in Table 23, shall be multiplied by the following factor:

$$
\delta=1+\frac{5 P}{A_{\mathrm{g}} f_{\mathrm{ck}}}, \text { but not exceeding } 1.5
$$

where

$$
\begin{aligned}
& P=\text { axial compressive force in } \mathrm{N} \text {, } \\
& A_{\mathrm{g}}=\text { gross area of the concrete section in } \mathrm{mm}^{2} \text {, } \\
& f_{\mathrm{ck}}=\text { characteristic compressive strength of } \\
& \text { concrete. }
\end{aligned}
$$

## B-5.2.3 With Shear Reinforcement

When shear reinforcement is provided the nominal shear stress $\tau_{c}$ in beams shall not exceed $\tau_{c \text { max }}$ given in Table 24.

Table 23 Permissible Shear Stress in Concrete
(Clauses B-2.1, B-2.3, B-4.2, B-5.2.1, B-5.2.2, B-5.3, B-5.4, B-5.5.1, B.5.5.3, B-6.3.2,B-6.3.3 and B-6.4.3 and Table 21)

| $100 \frac{A_{g}}{b d}$ | Permissible Shear Stress in Concrete, $\tau_{c}, \mathrm{~N} / \mathrm{mm}^{2}$ |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Grade of Concrete |  |  |  |  |  |
|  | M 15 | M 20 | M 25 | M 30 | M 35 | M 40 <br> and above |
| (1) | (2) | (3) | (4) | (5) | (6) | (7) |
| $\leq 0.15$ | 0.18 | 0.18 | 0.19 | 0.20 | 0.20 | 0.20 |
| 0.25 | 0.22 | 0.22 | 0.23 | 0.23 | 0.23 | 0.23 |
| 0.50 | 0.29 | 0.30 | 0.31 | 0.31 | 0.31 | 0.32 |
| 0.75 | 0.34 | 0.35 | 0.36 | 0.37 | 0.37 | 0.38 |
| 1.00 | 0.37 | 0.39 | 0.40 | 0.41 | 0.42 | 0.42 |
| 1.25 | 0.40 | 0.42 | 0.44 | 0.45 | 0.45 | 0.46 |
| 1.50 | 0.42 | 0.45 | 0.46 | 0.48 | 0.49 | 0.49 |
| 1.75 | 0.44 | 0.47 | 0.49 | 0.50 | 0.52 | 0.52 |
| 2.00 | 0.44 | 0.49 | 0.51 | 0.53 | 0.54 | 0.55 |
| 2.25 | 0.44 | 0.51 | 0.53 | 0.55 | 0.56 | 0.57 |
| 2.50 | 0.44 | 0.51 | 0.55 | 0.57 | 0.58 | 0.60 |
| 2.75 | 0.44 | 0.51 | 0.56 | 0.58 | 0.60 | 0.62 |
| 3.00 and above | 0.44 | 0.51 | 0.57 | 0.60 | 0.62 | 0.63 |

NOTE- $A_{g}$ is that area of longitudinal tension reinforcement which continues at least one effective depth beyond the section being considered except at supports where the full area of tension reinforcement may be used provided the detailing conforms to 26.2 .2 and 26.2.3.

B-5.2.3.1 For slabs, $\tau_{c}$ shall not exceed half the value of $\tau_{c \text { max }}$ given in Table 24.

## B-5.3 Minimum Shear Reinforcement

When $\tau_{c}$ is less than $\tau_{c}$ given in Table 23, minimum shear reinforcement shall be provided in accordance with 26.5.1.6.

## B-5.4 Design of Shear Reinforcement

When $\tau_{c}$ exceeds $\tau_{c}$ given in Table 23, shear reinforcement shall be provided in any of the following forms:
a) Vertical stirrups,
b) Bent-up bars along with stirrups, and
c) Inclined stirrups.

Where bent-up bars are provided, their contribution towards shear resistance shall not be more than half that of the total shear reinforcement.
Shear reinforcement shall be provided to carry a shear equal to $V-\tau_{c} b d$. The strength of shear reinforcement $V_{s}$ shall be calculated as below:
a) For vertical stirrups

$$
V_{s}=\frac{\sigma_{x v} A_{v v} d}{s_{v}}
$$

b) For inclined stirrups or a series of bars bent-up at different cross-sections:

$$
V_{s}=\frac{\sigma_{x v} A_{v v} d}{s_{v}}(\sin \alpha+\cos \alpha)
$$

c) For single bar or single group of parallel bars, all bent-up at the same cross-section:

$$
V_{s}=\sigma_{x v} A_{v v} \sin \alpha
$$

where
$A_{v v}=$ total cross-sectional area of stirrup legs or bent-up bars within a distance,
$s_{v}=$ spacing of the stirrups or bent-up bars along the length of the member,
$\tau_{c}=$ design shear strength of the concrete,
$b=$ breadth of the member which for flanged beams, shall be taken as the breadth of the web $b_{w}$,
$\sigma_{x v}=$ permissible tensile stress in shear reinforcement which shall not be taken
greater than $230 \mathrm{~N} / \mathrm{mm}^{2}$,
$\alpha=$ angle between the inclined stirrup or bent-up bar and the axis of the member, not less than $45^{\circ}$, and
$d=$ effective depth.
NOTE - Where more than one type of shear reinforcement is used to reinforce the same portion of the beam, the total shear resistance shall be computed as the sum of the resistance for the various types separately. The area of the stirrups shall not be less than the minimum specified in 26.5.1.6.

## B-5.5 Enhanced Shear Strength of Sections Close to Supports

## B-5.5.1 General

Shear failure at sections of beams and cantilevers without shear reinforcement will normally occur on plane inclined at an angle $30^{\circ}$ to the horizontal. If the angle of failure plane is forced to be inclined more steeply than this [because the section considered $(X-X)$ in Fig. 24 is close to a support or for other reasons], the shear force required to produce failure is increased.
The enhancement of shear strength may be taken into account in the design of sections near a support by increasing design shear strength of concrete, $\tau_{c}$ to $2 d \tau_{c} / a_{v}$ provided that the design shear stress at the face of support remains less than the values given in Table 23. Account may be taken of the enhancement in any situation where the section considered is closer to the face of a support of concentrated load than twice the effective depth, $d$. To be effective, tension reinforcement should extend on each side of the point where it is intersected by a possible failure plane for a distance at least equal to the effective depth, or be provided with an equivalent anchorage.

B-5.5.2 Shear Reinforcement for Sections Close to Supports
If shear reinforcement is required, the total area of this is given by:

$$
A_{s}=a_{c} b\left(\tau_{c}-2 d \tau_{c} / a_{v}\right) / 0.87 f_{y} \geq 0.4 a_{c} b / 0.87 f_{y}
$$

This reinforcement should be provided within the middle three quarters of $a_{c}$. Where $a_{c}$ is less than $d_{s}$ horizontal shear reinforcement will be more effective than vertical.

Table 24 Maximum Shear Stress, $\tau_{c \text { max }}, \mathbf{N} / \mathbf{m m}^{2}$
(Clauses B-5.2.3, B-5.2.3.1, B-5.5.1 and B-6.3.1)

| Concrete Grade | M 15 | M 20 | M 25 | M 30 | M 35 | M 40 and above |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| $\tau_{c \text { max }}, \mathbf{N} / \mathbf{m m}^{2}$ | 1.6 | 1.8 | 1.9 | 2.2 | 2.3 | 2.5 |

## B-5.5.3 Enhanced Shear Strength Near Supports (Simplified Approach)

The procedure given in B-5.5.1 and B-5.5.2 may be used for all beams. However for beams carrying generally uniform load or where the principal load is located further than $2 d$ from the face of support, the shear stress may be calculated at a section a distance $d$ from the face of support. The value of $\tau_{c}$ is calculated in accordance with Table 23 and appropriate shear reinforcement is provided at sections closer to the support, no further check for such section is required.

## B-6 TORSION

## B-6.1 General

In structures where torsion is required to maintain equilibrium, members shall be designed for torsion in accordance with B-6.2, B-6.3 and B-6.4. However, for such indeterminate structures where torsion can be eliminated by releasing redundant restraints, no specific design for torsion is necessary provided torsional stiffness is neglected in the calculation of internal forces. Adequate control of any torsional cracking is provided by the shear reinforcement as per B-5.

NOTE - The approach to design in this clause for torsion is as follows:

Torsional reinforcement is not calculated separately from that required for bending and shear. Instead the total longitudinal reinforcement is determined for a fictitious bending moment which is a function of actual bending moment and torsion; similarly web reinforcement is determined for a fictitious shear which is a function of actual shear and torsion.
B-6.1.1 The design rules laid down in B-6.3 and B-6.4 shall apply to beams of solid rectangular cross-section. However, these clauses may also be applied to flanged beams by substituting $b_{w}$ for $b$, in which case they are generally conservative; therefore specialist literature may be referred to.

## B-6.2 Critical Section

Sections located less than a distance $d$, from the face of the support may be designed for the same torsion as computed at a distance $d$, where $d$ is the effective depth.

## B-6.3 Shear and Torsion

## B-6.3.1 Equivalent Shear

Equivalent shear, $V_{x}$ shall be calculated from the formula:

$$
V_{x}=V+1.6 \frac{T}{b}
$$

where
$V_{x}=$ equivalent shear,
$V=$ shear,
$T=$ torsional moment, and
$b=$ breadth of beam.
The equivalent nominal shear stress, $\tau_{e n}$, in this case shall be calculated as given in B-5.1, except for substituting $V$ by $V_{x}$. The values of $\tau_{e n}$ shall not exceed the values of $\tau_{c \text { max }}$ given in Table 24.
B-6.3.2 If the equivalent nominal shear stress $\tau_{e n}$ does not exceed $\tau_{c}$, given in Table 23, minimum shear reinforcement shall be provided as specified in 26.5.1.6.
B-6.3.3 If $\tau_{e n}$ exceeds $\tau_{c}$ given in Table 23, both longitudinal and transverse reinforcement shall be provided in accordance with B-6.4.

## B-6.4 Reinforcement in Members Subjected to Torsion

B-6.4.1 Reinforcement for torsion, when required, shall consist of longitudinal and transverse reinforcement.

## B-6.4.2 Longitudinal Reinforcement

The longitudinal reinforcement shall be designed to resist an equivalent bending moment, $M_{e l}$, given by

$$
M_{e l}=M+M_{t}
$$

where
$M=$ bending moment at the cross-section, and
$M_{t}=T \frac{(1+D / b)}{1.7}$, where $T$ is the torsional moment, $D$ is the overall depth of the beam and $b$ is the breadth of the beam.
B-6.4.2.1 If the numerical value of $M_{t}$ as defined in B-6.4.2 exceeds the numerical value of the moment $M$, longitudinal reinforcement shall be provided on the flexural compression face, such that the beam can also withstand an equivalent moment $M_{e 2}$ given by $M_{e l}=M_{t}-M$, the moment $M_{e l}$ being taken as acting in the opposite sense to the moment $M$.

## B-6.4.3 Transverse Reinforcement

Two legged closed hoops enclosing the corner longitudinal bars shall have an area of cross-section $A_{v v}$, given by

$$
A_{v v}=\frac{T . s_{v}}{b_{1} d_{1} \sigma_{v v}}+\frac{V . s_{v}}{2.5 d_{1} \sigma_{v v}}, \text { but the total }
$$

transverse reinforcement shall not be less than

$$
\frac{\left(\tau_{v n}-\tau_{c}\right) b . s_{v}}{\sigma_{v v}}
$$

where
$T=$ torsional moment,
$V=$ shear force,

$s_{x}=$ spacing of the stirrup reinforcement,
$b_{1}=$ centre-to-centredistance between corner bars in the direction of the width,
$d_{1}=$ centre-to-centredistance between corner bars in the direction of the depth,
$b=$ breadth of the member,
$\sigma_{x x}=$ permissible tensile stress in shear reinforcement,
$\tau_{x x}=$ equivalent shear stress as specified in B-6.3.1, and
$\tau_{x}=$ shear strength of the concrete as specified in Table 23.

# ANNEX C 

(Clauses 22.3.2, 23.2.1 and 42.1)

## CALCULATION OF DEFLECTION

## C-1 TOTAL DEFLECTION

C-1.1 The total deflection shall be taken as the sum of the short-term deflection determined in accordance with C-2 and the long-term deflection, in accordance with C-3 and C-4.

## C-2 SHORT-TERM DEFLECTION

C-2.1 The short-term deflection may be calculated by the usual methods for elastic deflections using the short-term modulus of elasticity of concrete, $E_{c}$ and an effective moment of inertia $I_{\text {eff }}$ given by the following equation:

$$
\begin{aligned}
& I_{\text {eff }}=\frac{I_{t}}{1.2-\frac{M_{t}}{M} \frac{z}{d}\left(1-\frac{x}{d}\right) \frac{b_{w}}{b}} ; \text { but } \\
& I_{t} \leq I_{\text {eff }} \leq I_{g t}
\end{aligned}
$$

where
$I_{t}=$ moment of inertia of the cracked section,
$M_{t}=$ cracking moment, equal to $\frac{f_{c r} I_{g r}}{y_{t}}$ where $f_{c r}$ is the modulus of rupture of concrete, $I_{g r}$ is the moment of inertia of the gross section about the centroidal axis, neglecting the reinforcement, and $y_{t}$ is the distance from centroidal axis of gross section, neglecting the reinforcement, to extreme fibre in tension,
$M=$ maximum moment under service loads,
$z=$ lever arm,
$x=$ depth of neutral axis,
$d=$ effective depth,
$b_{w}=$ breadth of web, and
$b=$ breadth of compression face.

For continuous beams, deflection shall be calculated using the values of $I_{t}, I_{g t}$ and $M_{t}$ modified by the following equation:

$$
X_{0}=k_{1}\left[\frac{X_{1}+X_{2}}{2}\right]+\left(1-k_{1}\right) X_{0}
$$

where

$$
\begin{aligned}
X_{0} & =\text { modified value of } X \\
X_{1}, X_{2} & =\text { values of } X \text { at the supports, } \\
X_{0} & =\text { value of } X \text { at mid span, } \\
k_{1} & =\text { coefficient given in Table } 25, \text { and } \\
X & =\text { value of } I_{t}, I_{g t} \text { or } M_{t} \text { as appropriate. }
\end{aligned}
$$

## C-3 DEFLECTION DUE TO SHRINKAGE

C-3.1 The deflection due to shrinkage $a_{c s}$ may be computed from the following equation:

$$
a_{c s}=k_{3} \Psi_{c s} I^{2}
$$

where
$k_{3}$ is a constant depending upon the support conditions,
0.5 for cantilevers,
0.125 for simply supported members,
0.086 for members continuous at one end, and
0.063 for fully continuous members.
$\Psi_{c s}$ is shrinkage curvature equal to $k_{4} \frac{E_{c s}}{D}$
where $E_{c s}$ is the ultimate shrinkage strain of concrete (see 6.2.4),

$$
\begin{aligned}
k_{4} & =0.72 \times \frac{P_{1}-P_{0}}{\sqrt{P_{1}}} \leq 1.0 \text { for } 0.25 \leq P_{1}-P_{0}<1.0 \\
& =0.65 \times \frac{P_{1}-P_{0}}{\sqrt{P_{1}}} \leq 1.0 \text { for } P_{1}-P_{0} \geq 1.0
\end{aligned}
$$

Table 25 Values of Coefficient, $k_{1}$
(Clause C-2.1)

| $k_{2}$ | 0.5 or less | 0.6 | 0.7 | 0.8 | 0.9 | 1.0 | 1.1 | 1.2 | 1.3 | 1.4 |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| $k_{1}$ | 0 | 0.03 | 0.08 | 0.16 | 0.30 | 0.50 | 0.73 | 0.91 | 0.97 | 1.0 |

NOTE $-k_{1}$ is given by

$$
k_{2}=\frac{M_{1}+M_{2}}{M_{e 1}+M_{e 2}}
$$

where

$$
\begin{aligned}
M_{1}, M_{2} & =\text { support moments, and } \\
M_{e 1}, M_{e 2} & =\text { fixed end moments. }
\end{aligned}
$$

where $P_{1}=\frac{100 A_{\text {st }}}{b d}$ and $P_{2}=\frac{100 A_{\text {sc }}}{b d}$
and $D$ is the total depth of the section, and $l$ is the length of span.

## C-4 DEFLECTION DUE TO CREEP

C-4.1 The creep deflection due to permanent loads $a_{\text {sc (pemi) }}$ may be obtained from the following equation:

$$
a_{\mathrm{sc}(\text { perm }}=a_{\mathrm{sc}(\text { perm }}-a_{1(\text { perm })}
$$

where
$a_{\text {(sc (pemi) }}=$ initial plus creep deflection due to permanent loads obtained using an elastic analysis with an effective modulus of elasticity,
$E_{\mathrm{cc}}=\frac{E_{\mathrm{c}}}{1+\theta} ; \theta$ being the creep coefficient, and
$a_{1(\text { perm })}=$ short-term deflection due to permanent load using $E_{\mathrm{c}}$.

# ANNEX D 

(Clauses 24.4 and 37.1.2)

## SLABS SPANNING IN TWO DIRECTIONS

## D-1 RESTRAINED SLABS

D-1.0 When the corners of a slab are prevented from lifting, the slab may be designed as specified in D-1.1 to D-1.11.
D-1.1 The maximum bending moments per unit width in a slab are given by the following equations:

$$
\begin{aligned}
& M_{\mathrm{x}}=\alpha_{\mathrm{x}} w l_{\mathrm{x}}^{2} \\
& M_{\mathrm{y}}=\alpha_{\mathrm{y}} w l_{\mathrm{x}}^{2}
\end{aligned}
$$

where
$\alpha_{x}$ and $\alpha_{y}$ are coefficients given in Table 26, $w=$ total design load per unit area,
$M_{x}, M_{y}=$ moments on strips of unit width spanning $l_{x}$ and $l_{y}$ respectively, and
$l_{x}$ and $l_{y}=$ lengths of the shorter span and longer span respectively.
D-1.2 Slabs are considered as divided in each direction into middle strips and edge strips as shown in Fig. 25 the middle strip being three-quarters of the width and each edge strip one-eight of the width.
D-1.3 The maximum moments calculated as in D-1.1 apply only to the middle strips and no redistribution shall be made.
D-1.4 Tension reinforcement provided at mid-span in the middle strip shall extend in the lower part of the slab to within 0.251 of a continuous edge, or 0.151 of a discontinuous edge.
D-1.5 Over the continuous edges of a middle strip, the tension reinforcement shall extend in the upper part of the slab a distance of 0.151 from the support, and at least 50 perccent shall extend a distance of 0.31 .

D-1.6 At a discontinuous edge, negative moments may arise. They depend on the degree of fixity at the edge of the slab but, in general, tension reinforcement equal to 50 percent of that provided at mid-span extending 0.11 into the span will be sufficient.
D-1.7 Reinforcement in edge strip, parallel to that edge, shall comply with the minimum given in Section 3 and the requirements for torsion given in D-1.8 to D-1.10.
D-1.8 Torsion reinforcement shall be provided at any corner where the slab is simply supported on both edges meeting at that corner. It shall consist of top and bottom reinforcement, each with layers of bars placed parallel to the sides of the slab and extending from the edges a minimum distance of one-fifth of the shorter span. The area of reinforcement in each of these four layers shall be three-quarters of the area required for the maximum mid-span moment in the slab.
D-1.9 Torsion reinforcement equal to half that described in D-1.8 shall be provided at a corner contained by edges over only one of which the slab is continuous.
D-1.10 Torsion reinforcements need not be provided at any corner contained by edges over both of which the slab is continuous.
D-1.11 Torsion $l_{x} / l_{x}$ is greater than 2 , the slabs shall be designed as spanning one way.

## D-2 SIMPLY SUPPORTED SLABS

D-2.1 When simply supported slabs do not have adequate provision to resist torsion at corners and to prevent the corners from lifting, the maximum
![chunk-0-img-0.jpeg](chunk-0-img-0.jpeg)

Fig. 25 Division of Slab into Middle and Edge Strips

Table 26 Bending Moment Coefficients for Rectangular Panels Supported on Four Sides with Provision for Torsion at Corners
(Clauses D-1.1 and 24.4.1)

| Case <br> No. | Type of Panel and Moments Considered | Short Span Coefficients $\alpha_{s}$ (Values of $l_{y} / l_{x}$ ) |  |  |  |  |  |  | Long Span Coefficients $\alpha_{y}$ for All Values of |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  | 1.0 | 1.1 | 1.2 | 1.3 | 1.4 | 1.5 | 1.75 | 2.0 | $l_{y} / l_{x}$ |
| (1) | (2) | (3) | (4) | (5) | (6) | (7) | (8) | (9) | (10) | (11) |
| 1 | Interior Panels: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.032 | 0.037 | 0.043 | 0.047 | 0.051 | 0.053 | 0.060 | 0.065 | 0.032 |
|  | Positive moment at mid-span | 0.024 | 0.028 | 0.032 | 0.036 | 0.039 | 0.041 | 0.045 | 0.049 | 0.024 |
| 2 | One Short Edge Continuous: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.037 | 0.043 | 0.048 | 0.051 | 0.055 | 0.057 | 0.064 | 0.068 | 0.037 |
|  | Positive moment at mid-span | 0.028 | 0.032 | 0.036 | 0.039 | 0.041 | 0.044 | 0.048 | 0.052 | 0.028 |
| 3 | One Long Edge Discontinuous: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.037 | 0.044 | 0.052 | 0.057 | 0.063 | 0.067 | 0.077 | 0.085 | 0.037 |
|  | Positive moment at mid-span | 0.028 | 0.033 | 0.039 | 0.044 | 0.047 | 0.051 | 0.059 | 0.065 | 0.028 |
| 4 | Two Adjacent Edges Discontinuous: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.047 | 0.053 | 0.060 | 0.065 | 0.071 | 0.075 | 0.084 | 0.091 | 0.047 |
|  | Positive moment at mid-span | 0.035 | 0.040 | 0.045 | 0.049 | 0.053 | 0.056 | 0.063 | 0.069 | 0.035 |
| 5 | Two Short Edges Discontinuous: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.045 | 0.049 | 0.052 | 0.056 | 0.059 | 0.060 | 0.065 | 0.069 | - |
|  | Positive moment at mid-span | 0.035 | 0.037 | 0.040 | 0.043 | 0.044 | 0.045 | 0.049 | 0.052 | 0.035 |
| 6 | Two Long Edges Discontinuous: |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | - | - | - | - | - | - | - | - | 0.045 |
|  | Positive moment at mid-span | 0.035 | 0.043 | 0.051 | 0.057 | 0.063 | 0.068 | 0.080 | 0.088 | 0.035 |
| 7 | Three Edges Discontinuous <br> (One Long Edge Continuous): |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | 0.057 | 0.064 | 0.071 | 0.076 | 0.080 | 0.084 | 0.091 | 0.097 | - |
|  | Positive moment at mid-span | 0.043 | 0.048 | 0.053 | 0.057 | 0.060 | 0.064 | 0.069 | 0.073 | 0.043 |
| 8 | Three Edges Discontinuous <br> (One Short Edge Continuous) : |  |  |  |  |  |  |  |  |  |
|  | Negative moment at continuous edge | - | - | - | - | - | - | - | - | 0.057 |
|  | Positive moment at mid-span | 0.043 | 0.051 | 0.059 | 0.065 | 0.071 | 0.076 | 0.087 | 0.096 | 0.043 |
| 9 | Four Edges Discontinuous: |  |  |  |  |  |  |  |  |  |
|  | Positive moment at mid-span | 0.056 | 0.064 | 0.072 | 0.079 | 0.085 | 0.089 | 0.100 | 0.107 | 0.056 |

moments per unit width are given by the following equation:

$$
\begin{aligned}
& M_{x}=\alpha_{x} w l_{x}^{2} \\
& M_{y}=\alpha_{y} w l_{x}^{2}
\end{aligned}
$$

where
$M_{x}, M_{y}, w, l_{x}, l_{y}$ are same as those in D-1.1,
and $\alpha_{x}$ and $\alpha_{y}$ are moment coefficients given in Table 27
D-2.1.1 At least 50 percent of the tension reinforcement provided at mid-span should extend to the supports. The remaining 50 percent should extend to within $0.1 l_{x}$ or $0.1 l_{y}$ of the support, as appropriate.

Table 27 Bending Moment Coefficients for Slabs Spanning in Two Directions at Right Angles, Simply Supported on Four Sides
(Clause D-2.1)

| $l_{y} / l_{x}$ | 1.0 | 1.1 | 1.2 | 1.3 | 1.4 | 1.5 | 1.75 | 2.0 | 2.5 | 3.0 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| $\alpha_{x}$ | 0.062 | 0.074 | 0.084 | 0.093 | 0.099 | 0.104 | 0.113 | 0.118 | 0.122 | 0.124 |
| $\alpha_{y}$ | 0.062 | 0.061 | 0.059 | 0.055 | 0.051 | 0.046 | 0.037 | 0.029 | 0.020 | 0.014 |

# ANNEX E 

(Clause 25.2)

## EFFECTIVE LENGTH OF COLUMNS

E-1 In the absence of more exact analysis, the effective length of columns in framed structures may be obtained from the ratio of effective length to unsupported length $l_{a f} / /$ given in Fig. 26 when relative displacement of the ends of the column is prevented and in Fig. 26 when relative lateral displacement of the ends is not prevented. In the latter case, it is recommended that the effective length ratio $l_{a f} / /$ may not be taken to be less than 1.2 .

## NOTES

1 Figures 26 and 27 are reproduced from 'The Structural Engineer' No. 7, Volume 52, July 1974 by the permission of the Council of the Institution of Structural Engineers, U.K.

2 In Figs. 26 and $27, \beta_{1}$ and $\beta_{2}$ are equal to $\frac{\Sigma K_{0}}{\Sigma K_{0}+\Sigma K_{\mathrm{b}}}$ where the summation is to be done for the members framing into a joint at top and bottom respectively; and $K_{0}$ and $K_{\mathrm{b}}$ being the flexural stiffness for column and beam respectively.

E-2 To determine whether a column is a no sway or a sway column, stability index $Q$ may be computed as given below:

$$
Q=\frac{\sum P_{0}}{H_{0}} \frac{\Delta_{\mathrm{B}}}{h_{\mathrm{s}}}
$$

where

$$
\begin{aligned}
& \sum P_{0}=\text { sum of axial loads on all column in the } \\
& \text { storey, } \\
& \Delta_{\mathrm{B}}=\begin{array}{l}
\text { elastically computed first order lateral } \\
\text { deflection, } \\
H_{0}=\text { total lateral force acting within the storey, } \\
\text { and } \\
h_{\mathrm{s}}=\text { height of the storey. }
\end{array}
\end{aligned}
$$

If $Q \leq 0.04$, then the column in the frame may be taken as no sway column, otherwise the column will be considered as sway columnn.
E-3 For normal usage assuming idealized conditions, the effective length $l_{a f}$ of in a given plane may be assessed on the basis of Table 28.
![chunk-0-img-1.jpeg](chunk-0-img-1.jpeg)

Fig. 26 Effective Lendth Ratios for a Column in a Frame with no Sway

![chunk-0-img-2.jpeg](chunk-0-img-2.jpeg)

Fig. 27 Effective Lenoth Ratios for a Column in a Frame Withou' Restraint Against Sway

Table 28 Effective Length of Compression Members
(Claase E-3)

| Degree of End <br> Restraint of Compre- <br> ssiom Members | Symbol | Theoretical <br> Vaine of <br> Effective <br> Length | Recommended <br> Vaine of <br> Effective <br> Length |
| :--: | :--: | :--: | :--: |
| (1) | (2) | (3) | (4) |
| Effectively held in <br> position and restrained <br> against rotation in <br> both ends | ![chunk-0-img-3.jpeg](chunk-0-img-3.jpeg) | 0.501 | 0.651 |
| Effectively held in <br> position at both ends, <br> restrained against <br> rotation at one end | ![chunk-0-img-4.jpeg](chunk-0-img-4.jpeg) | 0.701 | 0.801 |
| Effectively held in <br> position at both ends, <br> but not restrained <br> against rotation | ![chunk-0-img-5.jpeg](chunk-0-img-5.jpeg) | 1.001 | 1.001 |
| Effectively held in <br> position and restrained <br> against rotation at one <br> end, and at the other <br> restrained against <br> rotation but not held <br> in position | ![chunk-0-img-6.jpeg](chunk-0-img-6.jpeg) | 1.001 | 1.20 |
| Effectively held in <br> position and restrained <br> against rotation in <br> one end, and at the <br> other partially restr- <br> ained against rotation <br> but not held in position | ![chunk-0-img-7.jpeg](chunk-0-img-7.jpeg) |  | 1.501 |
| Effectively held in <br> position at one end <br> but not restrained <br> against rotation, and <br> at the other end restrained <br> against rotation <br> but not held in position | ![chunk-0-img-8.jpeg](chunk-0-img-8.jpeg) | 2.001 | 2.001 |
| Effectively held in <br> position and restrained <br> against rotation at one <br> end but not held in <br> position nor restrained <br> agninst rotation at the <br> other end | ![chunk-0-img-9.jpeg](chunk-0-img-9.jpeg) | 2.001 | 2.001 |

NOTE-1 is the unsupported length of compression member.

# ANNEX F 

(Clauses 35.3.2 and 43.1)

## CALCULATION OF CRACK WIDTH

Provided that the strain in the tension reinforcement is limited to $0.8 F_{s} / E_{s}$, the design surface crack width, which should not exceed the appropriate value given in 35.3 .2 may be calculated from the following equation:
Design surface crack width

$$
W_{\mathrm{cr}}=\frac{3 a_{\mathrm{cr}} \varepsilon_{\mathrm{m}}}{1+\frac{2\left(a_{\mathrm{cr}}-C_{\mathrm{mis}}\right)}{h-x}}
$$

where
$a_{\mathrm{cr}}=$ distance from the point considered to the surface of the nearest longitudinal bar,
$C_{\text {min }}=$ minimum cover to the longitudinal bar;
$\varepsilon_{\mathrm{m}}=$ average steel strain at the level considered,
$h=$ overall depth of the member, and
$x=$ depth of the neutral axis.
The average steel strain $\varepsilon_{\mathrm{m}}$ may be calculated on the basis of the following assumption:
The concrete and the steel are both considered to be fully elastic in tension and in compression. The elastic modulus of the steel may be taken as $200 \mathrm{kN} / \mathrm{mm}^{2}$ and the elastic modulus of the concrete is as derived from the equation given in 6.2.3.1 both in compression and in tension.
These assumptions are illustrated in Fig. 28, where
$h=$ the overall depth of the section,
$x=$ the depth from the compression face to the neutral axis,
$f_{c}=$ the maximum compressive stress in the concrete,
$f_{s}=$ the tensile stress in the reinforcement, and
$E_{s}=$ the modulus of elasticity of the reinforcement.
Alternatively, as an approximation, it will normally be satisfactory to calculate the steel stress on the basis of a cracked section and then reduce this by an amount equal to the tensile force generated by the triangular distributions, having a value of zero at the neutral axis and a value at the centroid of the tension steel of $1 \mathrm{~N} / \mathrm{mm}^{2}$ instantaneously, reducing to $0.55 \mathrm{~N} / \mathrm{mm}^{2}$ in the long-term, acting over the tension zone divided by the steel area. For a rectangular tension zone, this gives

$$
\varepsilon_{\mathrm{m}}=\varepsilon_{1}-\frac{b(h-x)(a-x)}{3 E_{s} A_{s}(d-x)}
$$

where
$A_{s}=$ area of tension reinforcement,
$b=$ width of the section at the centroid of the tension steel,
$\varepsilon_{1}=$ strain at the level considered, calculated ignoring the stiffening of the concrete in the tension zone,
$a=$ distance from the campression face to the point at which the crack width is being calculated, and
$d=$ effective depth.
![chunk-0-img-10.jpeg](chunk-0-img-10.jpeg)

Fig. 28

# ANNEX G 

(Clause 38.1)

## MOMENTS OF RESISTANCE FOR RECTANGULAR AND T-SECTIONS

G-0 The moments of resistance of rectangular and T-sections based on the assumptions of 38.1 are given in this annex.

## G-1 RECTANGULAR SECTIONS

## G-1.1 Sections Without Compression Reinforcement

The moment of resistance of rectangular sections without compression reinforcement should be obtained as follows. :
a) Determine the depth of netutral axis from the following equation:

$$
\frac{x_{\mathrm{u}}}{d}=\frac{0.87 f_{\mathrm{y}}}{0.36} \frac{A_{\mathrm{st}}}{f_{\mathrm{ck}} b, d}
$$

b) If the value of $x_{s} / d$ is less than the limiting value (see Note below 38.1), calculate the moment of resistance by the following expression :

$$
M_{\mathrm{u}}=0.87 f_{\mathrm{y}} A_{\mathrm{st}} d\left(1-\frac{A_{\mathrm{st}} f_{\mathrm{y}}}{b d f_{\mathrm{ck}}}\right)
$$

c) If the value of $x_{s} / d$ is equal to the limiting value, the moment of resistance of the section is given by the following expression :
$M_{\mathrm{u} \text {, lim }}=0.36 \frac{x_{\mathrm{u}, \text { max }}}{d}\left(1-0.42 \frac{x_{\mathrm{u}, \text { max }}}{d}\right) b d^{2} f_{\mathrm{ck}}$
d) If $x_{s} / d$ is greater than the limiting value, the section should be redesigned.
In the above equations,

$$
\begin{aligned}
x_{\mathrm{s}} & =\text { depth of neutral axis, } \\
d & =\text { effective depth, } \\
f_{y} & =\text { characteristic strength of reinforcement, } \\
A_{\mathrm{st}} & =\text { area of tension reinforcement, } \\
f_{\mathrm{ck}} & =\text { characteristic compressive strength of concrete, } \\
b & =\text { width of the compression face, } \\
M_{\mathrm{u}, \text { lim }} & =\text { limiting moment of resistance of } \\
& \text { a section without compression } \\
& \text { reinforcement, and }
\end{aligned}
$$

$$
x_{\mathrm{u}, \text { max }}=\text { limiting value of } x_{\mathrm{u}} \text { from } 39.1
$$

## G-1.2 Section with Compression Reinforcement

Where the ultimate moment of resistance of section
exceeds the limiting value, $M_{u, \text { lim }}$ compression reinforcement may be obtained from the following equation :

$$
M_{\mathrm{u}}-M_{\mathrm{u}, \text { lim }}=f_{\mathrm{sc}} A_{\mathrm{sc}}\left(d-d^{\prime}\right)
$$

where
$M_{\mathrm{u}}, M_{\mathrm{u}, \text { lim }} d$ are same as in G-1.1,
$f_{\mathrm{sc}}=$ design stress in compression reinforcement corresponding to a strain of

$$
0.0035 \frac{\left(x_{\mathrm{u}, \max }-d^{\prime}\right)}{x_{\mathrm{u}, \max }}
$$

where
$x_{\mathrm{s}, \text { max }}=$ the limiting value of $x_{\mathrm{s}}$ from 38.1,
$A_{\mathrm{sc}}=$ area of compression reinforcement, and
$d^{\prime}=$ depth of compression reinforcement from compression face.
The total area of tension reinforcement shall be obtained from the following equation :

$$
A_{\mathrm{st}} \approx A_{\mathrm{st} 1}+A_{\mathrm{st} 2}
$$

where
$A_{\mathrm{st}}=$ area of the total tensile reinforcement,
$A_{\text {st1 }}=$ area of the tensile reinforcement for a singly reinforced section for $M_{\mathrm{u}, \text { lim }}$,
and
$A_{\text {st } 2}=A_{\mathrm{sc}} f_{\mathrm{sc}} / 0.87 f_{\mathrm{y}}$.

## G-2 FLANGED SECTION

G-2.1 For $x_{s}<D_{f}$, the moment of resistance may be calculated from the equation given in G-1.1.
G-2.2 The limiting value of the moment of resistance of the section may be obtained by the following equation when the ratio $D_{f} / d$ does not exceed 0.2 :

$$
\begin{aligned}
M_{\mathrm{u}}= & 0.36 \frac{x_{\mathrm{u}, \max }}{d}\left(1-0.42 \frac{x_{\mathrm{u}, \max }}{d}\right) f_{\mathrm{ck}} b_{\mathrm{sc}} d^{2} \\
& +0.45 f_{\mathrm{ck}}\left(b_{\mathrm{f}}-b_{\mathrm{st}}\right) D_{\mathrm{f}}\left(d-\frac{D_{\mathrm{f}}}{2}\right)
\end{aligned}
$$

where
$M_{\mathrm{u}}, x_{\mathrm{u}, \text { max }}, d$ and $f_{\text {ck }}$ are same as in G-1.1,
$b_{f}=$ breadth of the compression face/flange,
$b_{\mathrm{st}}=$ breadth of the web, and
$D_{\mathrm{f}}=$ thickness of the flange.

G-2.2.1 When the ratio $D_{f} / d$ exceeds 0.2 , the moment of resistance of the section may be calculated by the following equation :

$$
\begin{aligned}
M_{\mathrm{n}}= & 0.36 \frac{x_{\mathrm{u}, \max }}{d}\left(1-0.42 \frac{x_{\mathrm{u}, \max }}{d}\right) f_{\mathrm{ck}} b_{\mathrm{w}} d^{2} \\
& +0.45 f_{\mathrm{ck}}\left(b_{\mathrm{f}}-b_{\mathrm{w}}\right) y_{\mathrm{f}}\left(d-\frac{y_{\mathrm{f}}}{2}\right)
\end{aligned}
$$

where $y_{f}=\left(0.15 x_{\mathrm{u}}+0.65 D_{\mathrm{f}}\right)$, but not greater than $D_{\mathrm{f}}$, and the other symbols are same as in G-1.1 and G-2.2.
G-2.3 For $x_{\mathrm{n} \max }>x_{\mathrm{u}}>D_{\mathrm{f}}$, the moment of resistance may be calculated by the equations given in G-2.2 when $D_{\mathrm{f}} / x_{\mathrm{n}}$ does not exceed 0.43 and G-2.2.1 when $D_{\mathrm{f}} / x_{\mathrm{n}}$ exceeds 0.43 ; in both cases substituting $x_{\mathrm{n}}$ by $x_{\mathrm{u}}$.

# ANNEX H 

## (Foreword)

## COMMITTEE COMPOSITION

## Cement and Concrete Sectional Committee, CED 2

## Chairman

Dr H. C. Vievesvarya
'Chandrika', at 15th Cess, 63-64, Malleswaram, Bangalore 560003

Members
Dr S. C. Ahluwalia

Shri G. R. Bhartikar
Shri T. N. Tiwari
Dr D. Ghosh (Alternate)
Chief Enginier (Design)
Superintendind Engineer (S\&S) (Alternate)
Chief Enginier, Nandam Dam
Superintendind Eniginer (QCC) (Alternate)
Chief Enginier (Research-cum-Director)
Research Oprices (Concrete Technology) (Alternate)
Director
Joint Director (Alternate)
Director (CMDD) (N\&W)
Deputy Director (CMDD) (NW\&S) (Alternate)
Shri K. H. Ganowal
Shri V. Pattabhi (Alternate)
Shri V. K. Ghanskar

Shri S. Gopinath
Shri R. Tambakaran (Alternate)
Shri S. K. Guna Thakurta
Shri S. P. Sankaranarayanan (Alternate)
Shri N. S. Bhal
Dr. Ieshad Masood (Alternate)
Shri N. C. Jain
Joint Director Standards (B\&S) (CB-I)
Joint Director Standards (B\&S) (CB-II) (Alternate)
Shri N. G. Joshi
Shri P. D. Kelkar (Alternate)
Shri D. K. Kanungo
Shri B.R. Mesna (Alternate)
Shri P. Krushiamurthy
Shri S. Chakravarthy (Alternate)
Dr. A. G. Madhawa Rao
Shri K. Mani (Alternate)
Shri J. Sakur

Shri Pranulla Kumar
Shri P. P. Nair (Alternate)

Representing
OCL India, New Delhi
B. G. Shirke \& Construction Technology Ltd, Pune The Associated Cement Companies Ltd, Mumbai

Central Public Works Department, New Delhi
Sardar Sarovar Narman Nigam Ltd, Gandhinagar

Irrigation and Power Research Institute, Amritsar
A.P. Engineering Research Laboratories, Hyderabad

Central Water Commission, New Delhi

Hyderabad Industries Ltd, Hyderabad

Structural Engineering Research Centre (CSIR), Ghaziabad

The India Cements Ltd, Chennai

Gannon Dunkerley \& Co Ltd, Mumbai

Central Building Research Institute (CSIR), Roorkee

Cement Corporation of India, New Delhi
Research, Designs \& Standards Organization (Ministry of Railway), Lucknow

Indian Hume Pipes Co Ltd, Mumbai

National Test House, Calcutta

Larsen and Toubro Limited, Mumbai

Structural Engineering Research Centre (CSIR), Chennai

Hospital Services Consultancy Corporation (India) Ltd, New Delhi

Ministry of Surface Transport, Department of Surface Transport (Roads Wing), New Delhi
(Continued on page 99)

## Members

Member Secretary
Director (Civic) (Alternate)
Shri S. K. Naymani, SO I
Dr A. S. Goel, BE (Alternate)
Shri S. S. Seshra
Shri Satander Kumar (Alternate)
Shri Y. R. PhuL
Shri A. K. Sharma (Alternate)
Dr C. Rajkumar
Dr K. Mohan (Alternate)
Shri G. Ramdas
Shri R. C. Sharma (Alternate)
Shri S. A. Reddi
Shri J. S. Sanganeria
Shri L. N. Agarwal (Alternate)
Shri Vindatschalam
Shri N. Chandrasekaran (Alternate)
Superintending Engineer (Design)
Executive Engineer (S.M.R.Division) (Alternate)
Shri A. K. Chadda
Shri J. R. St. (Alternate)
Dr H. C. Visvesvaraya
Shri D. C. Chaturved (Alternate)
Shri Vinod Kumar
Director (Civ Engg)

## Representing

Central Board of Irrigation and Power, New Delhi
Engineer-in-Chief's Branch, Army Headquarters, New Delhi
Central Road Research Institute (CSIR), New Delhi
Indian Roads Congress, New Delhi
National Council for Cement and Building Materials, New Delhi
Directorate General of Supplies and Disposals, New Delhi
Gammon India Ltd, Mumbai
Geological Survey of India, Calcutta
Central Soil and Materials Research Station, New Delhi
Public Works Department, Government of Tamil Nadu, Chennai
Hindustan Prefab Ltd, New Delhi
The Institution of Engineers (India), Calcutta
Director General, BIS (Ex-officio Member)

## Member-Secretaries

Shri J. K. Prasad
Addl Director (Civ Engg), BIS
Shri Saniay Pant
Deputy Director (Civ Engg), BIS

Panel for Revision of Design Codes

## Convener

Dr C. Rajkumar

## Members

Shri V. K. Ghazekar
Shri S. A. Reddi
Shri Jose Kubian
Dr A. K. Mittal
Dr S. C. Maiti
Dr Ahe. Kumar (Alternate)
Prof A.K. Jain
Dr V. Thiruvengbam

National Council for Cement and Building Materials, Ballabgarh

Structural Engineering Research Centre, Ghaziabad
Gammon India Ltd, Mumbai
Central Public Works Department, New Delhi
Central Public Works Department, New Delhi
National Council for Cement and Building Materials, Ballabgarh
University of Roorkee, Roorkee
School of Planning and Architecture, New Delhi
(Continued on page 100)



